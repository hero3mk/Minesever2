package app.minesaver

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material3.Typography
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

val LocalDark = compositionLocalOf { true }

val Green = Color(0xFF5EEAA8)
val Blue = Color(0xFF6AA9FF)
val Violet = Color(0xFFB79CFF)
val Amber = Color(0xFFFFC857)
val Rose = Color(0xFFFF7A9A)

data class Look(
    @StringRes val nameRes: Int,
    val dark: Boolean,
    val bg: List<Color>,
    val card: Color,
    val cardBorder: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val stars: Boolean = false
)

val Looks = listOf(
    Look(R.string.lk_obsidian, true, listOf(Color(0xFF0E1013), Color(0xFF12161B), Color(0xFF0E1013)), Color(0xFF1A1F26), Color(0xFF2A313B),
        Color(0xFFF2F5F8), Color(0xFF9AA5B1), Color(0xFF34D399), Color(0xFF38BDF8), Color(0xFF04201A)),
    Look(R.string.lk_ocean, true, listOf(Color(0xFF07131F), Color(0xFF0A1B2C), Color(0xFF07131F)), Color(0xFF112538), Color(0xFF1C3A55),
        Color(0xFFEAF4FF), Color(0xFF94AEC7), Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFF04202E)),
    Look(R.string.lk_forest, true, listOf(Color(0xFF08140E), Color(0xFF0C1D14), Color(0xFF08140E)), Color(0xFF13281C), Color(0xFF1F3D2C),
        Color(0xFFEAF7EF), Color(0xFF9CB8A8), Color(0xFF4ADE80), Color(0xFFA3E635), Color(0xFF052212)),
    Look(R.string.lk_nether, true, listOf(Color(0xFF140808), Color(0xFF1E0D0D), Color(0xFF140808)), Color(0xFF2A1313), Color(0xFF452020),
        Color(0xFFFFEFEA), Color(0xFFC4A39B), Color(0xFFFB923C), Color(0xFFF43F5E), Color(0xFF2B1000)),
    Look(R.string.lk_amethyst, true, listOf(Color(0xFF100B1C), Color(0xFF171028), Color(0xFF100B1C)), Color(0xFF221A38), Color(0xFF392C5C),
        Color(0xFFF3EEFF), Color(0xFFB4A8D6), Color(0xFFA78BFA), Color(0xFFF472B6), Color(0xFF1E0F3D)),
    Look(R.string.lk_paper, false, listOf(Color(0xFFF6F7F9), Color(0xFFEFF2F6), Color(0xFFF6F7F9)), Color(0xFFFFFFFF), Color(0xFFDDE2E8),
        Color(0xFF14181D), Color(0xFF5B6673), Color(0xFF059669), Color(0xFF0284C7), Color.White),
    Look(R.string.lk_cosmic, true, listOf(Color(0xFF060514), Color(0xFF0C1030), Color(0xFF0A2630)), Color(0x331A2146), Color(0x44FFFFFF),
        Color(0xFFEDEBFF), Color(0xFFB9B6DD), Color(0xFF5EEAA8), Color(0xFF6AA9FF), Color(0xFF00382A), stars = true)
)

val AccentChoices = listOf(
    Color(0xFF34D399), Color(0xFF38BDF8), Color(0xFFA78BFA), Color(0xFFF472B6), Color(0xFFFB923C), Color(0xFFFACC15)
)

val LocalLook = compositionLocalOf { Looks[0] }

fun Look.scheme(): ColorScheme {
    val solid = if (card.alpha < 0.95f) bg[1] else card
    return if (dark) darkColorScheme(
        primary = accent, onPrimary = onAccent, secondary = accent2, onSecondary = onAccent, tertiary = accent2,
        background = bg[0], onBackground = text, surface = solid, onSurface = text, onSurfaceVariant = textDim,
        surfaceContainer = solid, surfaceContainerHigh = solid, error = Color(0xFFFF6B7A), outline = cardBorder
    ) else lightColorScheme(
        primary = accent, onPrimary = onAccent, secondary = accent2, onSecondary = onAccent, tertiary = accent2,
        background = bg[0], onBackground = text, surface = solid, onSurface = text, onSurfaceVariant = textDim,
        surfaceContainer = solid, surfaceContainerHigh = solid, error = Color(0xFFD7263D), outline = cardBorder
    )
}

val DarkScheme = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF00382A), secondary = Blue, tertiary = Violet,
    background = Color(0xFF0B0A1F), surface = Color(0xFF14123A),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFB9B6DD), error = Color(0xFFFF8A9B)
)
val LightScheme = lightColorScheme(
    primary = Color(0xFF0B8F63), onPrimary = Color.White, secondary = Color(0xFF2563EB), tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF1F4FF), surface = Color.White,
    onSurface = Color(0xFF15133A), onSurfaceVariant = Color(0xFF5B5984), error = Color(0xFFD7263D)
)

private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val k: Int)

@Composable
fun AppBackground(look: Look, animate: Boolean = true, show: Boolean = true) {
    val cosmic = look.stars && show
    var tick by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animate, cosmic) {
        while (animate && cosmic) {
            delay(80)
            tick = (tick + 0.004f) % 1f
        }
    }
    val stars = remember {
        val r = Random(7)
        List(70) { Star(r.nextFloat(), r.nextFloat(), 0.7f + r.nextFloat() * 1.5f, r.nextFloat() * 6.283f, 1 + r.nextInt(3)) }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(Brush.verticalGradient(look.bg))
            if (!show) return@Canvas
            fun blob(cx: Float, cy: Float, r: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
            if (look.stars) {
                blob(w * 0.2f, h * 0.16f, w * 0.8f, Color(0x558B5CF6))
                blob(w * 0.95f, h * 0.58f, w * 0.9f, Color(0x4410B981))
                blob(w * 0.1f, h * 0.92f, w * 0.9f, Color(0x443B82F6))
            } else {
                blob(w * 0.5f, 0f, w * 0.95f, look.accent.copy(alpha = if (look.dark) 0.13f else 0.10f))
                blob(w, h, w * 0.8f, look.accent2.copy(alpha = if (look.dark) 0.07f else 0.06f))
            }
        }
        if (cosmic) Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val a = tick * 6.2832f
            stars.forEach { s ->
                val tw = 0.5f + 0.5f * sin(a * s.k + s.ph)
                drawCircle(Color.White.copy(alpha = 0.25f + 0.75f * tw), s.r * density, Offset(s.x * w, s.y * h))
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(look.card).border(1.dp, look.cardBorder, shape).padding(18.dp),
        content = content
    )
}

@Composable
fun Appear(i: Int, content: @Composable () -> Unit) {
    if (i > 7) { content(); return }
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(i * 60L); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(350)) + slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it / 8 }) { content() }
}

@Composable
fun Page(@StringRes title: Int?, onBack: (() -> Unit)? = null, content: LazyListScope.() -> Unit) =
    PageBase(title?.let { stringResource(it) }, onBack, content)

@Composable
fun PageBase(title: String?, onBack: (() -> Unit)?, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (title != null) item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                Text(title, style = MaterialTheme.typography.headlineMedium, maxLines = 2)
            }
        }
        content()
    }
}

@Composable
fun Act(@StringRes label: Int, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) =
    Act(stringResource(label), icon, tint, onClick)

@Composable
fun Act(label: String, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.16f))
            .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelLarge)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Acts(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
fun Badge(text: String, color: Color) {
    Text(
        text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun Segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).padding(4.dp)
    ) {
        options.forEachIndexed { i, o ->
            val bg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.primary else Color.Transparent, tween(300), label = "seg")
            val fg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(300), label = "segf")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg).clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = fg, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text) },
        confirmButton = { TextButton(onYes) { Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onNo) { Text(stringResource(R.string.cancel)) } }
    )
}


val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun GradientButton(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.secondary
    Row(
        modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(a, b))).clickable(onClick = onClick).padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimary)
        Spacer(Modifier.width(10.dp))
        Text(label, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun SectionTitle(text: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = .18f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
}
