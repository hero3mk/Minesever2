# MineSaver — Your Worlds. Always Safe.

Android app (Kotlin + Jetpack Compose) that backs up, verifies and restores Minecraft Bedrock worlds.
تطبيق أندرويد (Kotlin + Jetpack Compose) بيحفظ عوالم Minecraft Bedrock وبيتأكد منها وبيستعيدها.

## Build the APK / بناء الـ APK

**Option A — Android Studio (easiest / الأسهل)**
1. Install Android Studio (Koala or newer). / نزّل Android Studio.
2. File → Open → choose the `MineSaver` folder, wait for Gradle sync. / افتح فولدر المشروع واستنى الـ Sync.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and install. / انقله للموبايل وثبّته.

**Option B — GitHub Actions (no PC needed / من غير كمبيوتر قوي)**
1. Upload this folder to a new GitHub repository. / ارفع المشروع على GitHub.
2. Open the Actions tab → "Build APK" → Run workflow. / من Actions شغّل Build APK.
3. Download the `MineSaver-APK` artifact. / نزّل الملف من Artifacts.

## First run / أول تشغيل
1. Settings → choose a **Safe backup folder** (e.g. Documents/MineSaver). Backups are copied there too, so they survive uninstalling apps.
   الإعدادات ← اختار **فولدر النسخ الآمن**؛ كل نسخة بتتنسخ هناك كمان.
2. Settings → choose the **Minecraft worlds folder** (works when Android allows it, Android 10 or lower). On Android 11+, use Minecraft's *Export World* and share/open the file with MineSaver, or Transfer → Import.
   على أندرويد 11 وما فوق: من ماين كرافت اعمل Export World وابعته لـ MineSaver، أو من نقل ← استيراد.
3. Tap **Back up**. MineSaver re-opens the zip, checks every file and stores a SHA-256 before it says "done".
4. After reinstalling Minecraft: Restore → choose a backup → **Open in Minecraft** (works everywhere) or **Restore into Minecraft folder**.

## Test checklist (do this on a real phone) / اختبار حقيقي
1. Create a world in Minecraft, back it up in MineSaver (Backups shows "Verified").
2. Delete the world (or uninstall Minecraft), reinstall Minecraft.
3. MineSaver → Restore → Open in Minecraft → confirm the world and its builds are back.
4. Uninstall MineSaver, reinstall, Transfer → Import from safe folder → backups are back.

## Features / المميزات
- Backup, restore, import/export `.mcworld`, multiple copies, no automatic deletion, restore never overwrites.
- Auto-backup of changed worlds when MineSaver opens (needs the Minecraft folder).
- **Constellation**: every world is a star (green protected, amber changed, pink not backed up). / كل عالم نجمة.
- **Safety ring**: % of worlds backed up in the last 7 days.
- Integrity badges (SHA-256), "Send to MineSaver" from Minecraft's export, Arabic RTL + English, Light/Dark, animated space background and screen transitions.

## Shizuku (Android 11+, no computer) / شيزوكو من غير كمبيوتر
1. Install **Shizuku** from Google Play. / نزّل Shizuku من Google Play.
2. Settings → Developer options → turn on **Wireless debugging** (needs Wi-Fi). / فعّل Wireless debugging من خيارات المطور (محتاج واي فاي).
3. In Shizuku: **Pairing** → follow the notification and type the pairing code → then **Start via Wireless debugging**. / في Shizuku اعمل Pairing واكتب الكود من الإشعار وبعدين Start.
4. In MineSaver → Settings → **Shizuku** card → **Grant permission** → turn on "Use Shizuku". / في MineSaver من الإعدادات اضغط إعطاء الصلاحية وفعّل الاستخدام.
5. After every phone restart, start Shizuku again (step 3). / بعد كل إعادة تشغيل شغّل Shizuku تاني.

## Selection / التحديد
Worlds and Backups pages have **Select** → Select all, Back up selected, Delete selected, Delete all (always asks to confirm).
صفحتي عوالمي والنسخ فيهم **تحديد**: تحديد الكل، نسخ المحدد، حذف المحدد، حذف الكل (دايمًا بتأكيد).

## Known limits / حدود معروفة
- Shizuku access is new code and has not been tested on a real device yet.
- Without Shizuku, Android 11+ blocks apps from `Android/data`; use Import / Send to MineSaver instead.
- Not compiled or tested on a device by the author of this scaffold: build it, run the checklist above, and report any error.

## 1.2.0 — Cosmic Edition (first part) / النسخة الفضائية (الجزء الأول)
Included / موجود: 5 tabs (Home, Worlds, Backups, Tools, Settings); dashboard with stats, recent worlds and activity; world search, sort, favorites, details and size; Activity Center; Storage page (sizes, free space, old-copy and temp-file cleanup); Tools (coordinates, command generator, world info); PIN lock; animation, background and accent-color settings; Shizuku test.

Not built yet / لسه مش موجود: scheduled backups, backup encryption, fingerprint, Download Manager, Add-ons hub, Seed Explorer, version tracker, resource-pack manager, cloud sync, notifications, world categories, settings import/export.

## 1.3.0
Smoother (cached static background, fewer animated dots), refreshed look (cards, pills, gradient button, bottom bar, typography), Modern Standard Arabic UI, clear notes that Minecraft must use External storage, setup checklist on Home.

## 2.0.0 — redesign
New default look (Obsidian) with 7 themes, accent colors, text size, readable text colors; Home rebuilt (hero card, world cards, setup checklist); Help center and welcome guide; World details (analyzer, age, statistics, tags, notes, timeline), world comparison, Seed Library, Coordinates book; About and Help easy to reach. Add-on tools and discovery guides are planned for the next release.

## 3.0.0
Atlas (explored chunk map read from the latest backup, inspector, nearby places, route planner, exploration tracker), Add-on Center (library, dependency/conflict inspector, compatibility, safety scan), World identity card with health check, evolution chart, screenshots and journal, Studio (manifest builder, file inspector), local assistant and recommendations, Privacy center, Recovery center, fingerprint unlock and auto-lock, duplicate detection and file-type space breakdown, protected restore confirmation, favorite commands, server profiles.
Not included: seed maps, structure/biome finders (need a verified Bedrock generation engine), online services (reviews, update watch, cloud sync), external AI.
