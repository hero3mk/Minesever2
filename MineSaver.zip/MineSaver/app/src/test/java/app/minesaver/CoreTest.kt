package app.minesaver

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File

class CoreTest {
    @Test fun safeEntryNameBlocksTraversal() {
        assertNull(safeEntryName("../evil.txt"))
        assertNull(safeEntryName("a/../../b"))
        assertNull(safeEntryName("/abs/path"))
        assertEquals("db/000001.ldb", safeEntryName("db\\000001.ldb"))
    }

    @Test fun hexDumpFormatsRows() {
        val s = hexDump(byteArrayOf(0x41, 0x42, 0x00), 0)
        assertTrue(s.startsWith("00000000  41 42 00"))
        assertTrue(s.contains("AB."))
    }

    @Test fun slimeIsDeterministic() {
        for (x in -5..5) for (z in -5..5) assertEquals(Slime.isSlime(x, z), Slime.isSlime(x, z))
        val n = Slime.nearest(0, 0, 10, 5)
        assertTrue(n.size <= 5)
    }

    @Test fun encryptDecryptRoundTrip() {
        val src = File.createTempFile("ms", ".bin")
        val enc = File.createTempFile("ms", ".mse")
        val dec = File.createTempFile("ms", ".out")
        try {
            val data = ByteArray(2_500_000) { (it * 31).toByte() }
            src.writeBytes(data)
            ByteArrayOutputStream().use { bo ->
                Crypto.encrypt(src, bo, "correct horse".toCharArray())
                enc.writeBytes(bo.toByteArray())
            }
            assertTrue(Crypto.isEncrypted(enc))
            Crypto.decrypt(enc, dec, "correct horse".toCharArray())
            assertTrue(data.contentEquals(dec.readBytes()))
        } finally { src.delete(); enc.delete(); dec.delete() }
    }

    @Test fun wrongPasswordIsRejected() {
        val src = File.createTempFile("ms", ".bin")
        val enc = File.createTempFile("ms", ".mse")
        val dec = File.createTempFile("ms", ".out")
        try {
            src.writeBytes(ByteArray(1000) { 7 })
            ByteArrayOutputStream().use { bo -> Crypto.encrypt(src, bo, "password1".toCharArray()); enc.writeBytes(bo.toByteArray()) }
            var failed = false
            try { Crypto.decrypt(enc, dec, "password2".toCharArray()) } catch (e: Exception) { failed = true }
            assertTrue(failed)
        } finally { src.delete(); enc.delete(); dec.delete() }
    }

    @Test fun hashOfKnownText() {
        val f = File.createTempFile("ms", ".txt")
        try {
            f.writeText("abc")
            assertEquals("a9993e364706816aba3e25717850c26c9cd0d89d", hashFile(f, "SHA-1"))
        } finally { f.delete() }
    }

    @Test fun signatureDetectsZip() {
        assertEquals(R.string.sig_zip, signatureRes(byteArrayOf(0x50, 0x4B, 0x03, 0x04)))
    }
}
