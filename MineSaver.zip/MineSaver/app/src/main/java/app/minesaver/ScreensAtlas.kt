package app.minesaver

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private class Mark(val x: Int, val z: Int, val color: Color)

fun DrawScope.drawAtlas(a: AtlasData, dim: Int, cx: Float, cz: Float, s: Float, dimColor: Color, blockColor: Color) {
    val w = size.width
    val h = size.height
    var step = 1
    while (16f * s * step < 3f && step < 4096) step *= 2
    val cell = 16f * s * step
    fun paint(cells: LongArray, color: Color) {
        for (v in cells) {
            val x = ((unpackX(v) * step * 16f) - cx) * s + w / 2f
            val y = ((unpackZ(v) * step * 16f) - cz) * s + h / 2f
            if (x + cell < 0f || y + cell < 0f || x > w || y > h) continue
            drawRect(color, Offset(x, y), Size(cell + 0.6f, cell + 0.6f))
        }
    }
    paint(a.cells(dim, step, false), dimColor)
    paint(a.cells(dim, step, true), blockColor)
}

fun dist2(ax: Int, az: Int, bx: Int, bz: Int): Double = Math.hypot((ax - bx).toDouble(), (az - bz).toDouble())

fun compassRes(dx: Int, dz: Int): Int {
    if (dx == 0 && dz == 0) return R.string.cp_here
    val ang = Math.toDegrees(Math.atan2(dx.toDouble(), -dz.toDouble()))
    val idx = (((ang + 360.0 + 22.5) % 360.0) / 45.0).toInt()
    return when (idx) {
        0 -> R.string.cp_n; 1 -> R.string.cp_ne; 2 -> R.string.cp_e; 3 -> R.string.cp_se
        4 -> R.string.cp_s; 5 -> R.string.cp_sw; 6 -> R.string.cp_w; else -> R.string.cp_nw
    }
}

private fun dimRes(d: Int) = when (d) { 1 -> R.string.dim_nether; 2 -> R.string.dim_end; else -> R.string.dim_over }

fun spawnXZ(info: WorldInfo?): Pair<Int, Int>? {
    val p = info?.spawn?.split(",")?.map { it.trim().toIntOrNull() } ?: return null
    if (p.size < 3) return null
    val x = p[0] ?: return null
    val z = p[2] ?: return null
    return x to z
}

private fun marksOf(vm: MainVm, world: String): List<Triple<SavedPlace, Int, Int>> =
    vm.places.mapNotNull { p ->
        val x = p.x.toDoubleOrNull()?.toInt()
        val z = p.z.toDoubleOrNull()?.toInt()
        if (x == null || z == null) null
        else if (p.world.isNotBlank() && !p.world.equals(world, true)) null
        else Triple(p, x, z)
    }

@Composable
fun MiniMap(a: AtlasData, dim: Int, modifier: Modifier) {
    val p = MaterialTheme.colorScheme.primary
    Canvas(modifier) {
        drawRect(Color(0x22000000))
        val b = a.bounds(dim) ?: return@Canvas
        val wB = (b[1] - b[0] + 1) * 16f
        val hB = (b[3] - b[2] + 1) * 16f
        val s = minOf(size.width / wB, size.height / hB) * 0.92f
        val cx = (b[0] + b[1] + 1) * 8f
        val cz = (b[2] + b[3] + 1) * 8f
        drawAtlas(a, dim, cx, cz, s, p.copy(alpha = .35f), p)
    }
}

@Composable
fun AtlasScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val worlds = vm.rows.filter { it.backups.isNotEmpty() }
    val r = worlds.find { it.id == vm.atlasWorld } ?: worlds.firstOrNull()
    val a = r?.let { vm.atlas[it.id] }
    val info = r?.let { vm.infos[it.id] }
    val mc = remember { installedMc(ctx) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val err = MaterialTheme.colorScheme.error
    val dash = stringResource(R.string.none_dash)
    LaunchedEffect(r?.id, vm.backups.size, vm.infos.size) {
        if (r != null) { vm.ensureInfo(listOf(r.id)); vm.ensurePacks() }
    }
    var ix by remember { mutableStateOf("") }
    var iy by remember { mutableStateOf("") }
    var iz by remember { mutableStateOf("") }
    var idim by remember { mutableStateOf(0) }
    var range by remember { mutableStateOf(1000) }
    var fx by remember { mutableStateOf("") }
    var fz by remember { mutableStateOf("") }
    var tx by remember { mutableStateOf("") }
    var tz by remember { mutableStateOf("") }
    var addAt by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var addName by remember { mutableStateOf("") }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    Page(R.string.nav_atlas) {
        if (r == null) {
            item { Glass { Text(stringResource(R.string.atlas_need_backup)) } }
            return@Page
        }
        item { Text(stringResource(R.string.atlas_intro), color = dim, style = MaterialTheme.typography.bodyMedium) }
        item { Acts { worlds.forEach { w -> TagChip(w.name, w.id == r.id) { vm.atlasWorld = w.id } } } }
        item {
            Glass {
                SectionTitle(stringResource(R.string.atlas_status), Icons.Rounded.Info)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow(R.string.ad_mc, mc ?: dash)
                    DetailRow(R.string.r_version, info?.version ?: dash)
                    DetailRow(R.string.atlas_source, stringResource(R.string.atlas_source_v))
                }
                if (a == null) {
                    Spacer(Modifier.height(12.dp))
                    if (vm.atlasLoading) {
                        LinearProgressIndicator(progress = { vm.atlasProgress }, modifier = Modifier.fillMaxWidth())
                        Text(stringResource(R.string.atlas_reading), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 6.dp))
                    } else {
                        Acts { Act(R.string.atlas_read, Icons.Rounded.Map) { vm.loadAtlas(r.id) } }
                    }
                    vm.atlasError?.let { Text(it, color = err, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)) }
                } else {
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DetailRow(R.string.atlas_files, a.files.toString())
                        DetailRow(R.string.atlas_keys, a.keys.toString())
                        DetailRow(R.string.atlas_chunks, a.chunks.sumOf { it.size }.toString())
                    }
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        Act(R.string.atlas_open, Icons.Rounded.Map) { vm.atlasWorld = r.id; nav.navigate("map") }
                        Act(R.string.atlas_reread, Icons.Rounded.Refresh) { vm.loadAtlas(r.id, true) }
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.atlas_accuracy), Icons.Rounded.Info)
                Spacer(Modifier.height(8.dp))
                val packs = vm.packRefs[r.id]?.size ?: 0
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailRow(R.string.r_seed, info?.seed?.toString() ?: dash)
                    DetailRow(R.string.atlas_packs, packs.toString())
                    DetailRow(R.string.atlas_seedmap, stringResource(R.string.atlas_unavailable))
                    DetailRow(R.string.atlas_structs, stringResource(R.string.atlas_unavailable))
                    DetailRow(R.string.atlas_biomes, stringResource(R.string.atlas_unavailable))
                    DetailRow(R.string.atlas_explored, if (a != null) stringResource(R.string.v_yes) else stringResource(R.string.v_no))
                }
                Text(stringResource(R.string.atlas_why), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        if (a != null) {
            val spawn = spawnXZ(info)
            val pl = a.player
            val marks = marksOf(vm, r.name)
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_preview), Icons.Rounded.Map)
                    Spacer(Modifier.height(10.dp))
                    Acts { (0..2).forEach { d -> TagChip(stringResource(dimRes(d)), d == idim) { idim = d } } }
                    Spacer(Modifier.height(10.dp))
                    MiniMap(a, idim, Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)))
                    Spacer(Modifier.height(10.dp))
                    Acts { Act(R.string.atlas_open, Icons.Rounded.Map) { vm.atlasWorld = r.id; nav.navigate("map") } }
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_positions), Icons.Rounded.Place)
                    Spacer(Modifier.height(8.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DetailRow(R.string.atlas_spawn, if (spawn != null) "X ${spawn.first}, Z ${spawn.second}" else dash)
                        DetailRow(
                            R.string.atlas_player,
                            if (pl != null) "X ${pl[0].toInt()}, Y ${pl[1].toInt()}, Z ${pl[2].toInt()} (" + stringResource(dimRes(a.playerDim)) + ")" else dash
                        )
                        DetailRow(R.string.atlas_markers, marks.size.toString())
                    }
                    Text(stringResource(R.string.atlas_player_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_tracker), Icons.Rounded.Map)
                    Spacer(Modifier.height(8.dp))
                    (0..2).forEach { d ->
                        val n = a.chunks[d].size
                        if (n > 0) {
                            val b = a.bounds(d)
                            val area = if (b == null) 0L else (b[1] - b[0] + 1).toLong() * (b[3] - b[2] + 1)
                            val pct = if (area > 0) n * 100.0 / area else 0.0
                            Column(Modifier.padding(top = 8.dp)) {
                                Text(stringResource(dimRes(d)), fontWeight = FontWeight.SemiBold)
                                Text(
                                    stringResource(R.string.atlas_track_row, n, a.blocks[d].size, "%.1f".format(pct)),
                                    style = MaterialTheme.typography.bodySmall, color = dim
                                )
                            }
                        }
                    }
                    Text(stringResource(R.string.atlas_track_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_inspector), Icons.Rounded.Info)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(ix, { ix = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                        OutlinedTextField(iy, { iy = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, keyboardOptions = numeric)
                        OutlinedTextField(iz, { iz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                    }
                    Spacer(Modifier.height(8.dp))
                    Acts { (0..2).forEach { d -> TagChip(stringResource(dimRes(d)), d == idim) { idim = d } } }
                    val xi = ix.toIntOrNull()
                    val zi = iz.toIntOrNull()
                    if (xi != null && zi != null) {
                        val kx = Math.floorDiv(xi, 16)
                        val kz = Math.floorDiv(zi, 16)
                        val has = a.chunks[idim].contains(packXZ(kx, kz))
                        val hasB = a.blocks[idim].contains(packXZ(kx, kz))
                        Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            DetailRow(R.string.atlas_chunk, "$kx, $kz")
                            iy.toIntOrNull()?.let { DetailRow(R.string.atlas_subchunk, Math.floorDiv(it, 16).toString()) }
                            DetailRow(
                                R.string.atlas_data,
                                stringResource(if (hasB) R.string.atlas_data_terrain else if (has) R.string.atlas_data_chunk else R.string.atlas_data_none)
                            )
                            DetailRow(R.string.atlas_biome, stringResource(R.string.atlas_unavailable))
                            val near = marks.minByOrNull { dist2(xi, zi, it.second, it.third) }
                            if (near != null) DetailRow(R.string.atlas_nearest, near.first.name + " · " + dist2(xi, zi, near.second, near.third).toInt() + " m")
                            if (spawn != null) DetailRow(R.string.atlas_spawn, dist2(xi, zi, spawn.first, spawn.second).toInt().toString())
                            if (pl != null) DetailRow(R.string.atlas_player, dist2(xi, zi, pl[0].toInt(), pl[2].toInt()).toInt().toString())
                        }
                        Spacer(Modifier.height(10.dp))
                        Acts {
                            Act(R.string.atlas_show, Icons.Rounded.Map) { vm.atlasWorld = r.id; vm.mapFocus = xi to zi; nav.navigate("map") }
                            Act(R.string.atlas_add_marker, Icons.Rounded.Add) { addName = ""; addAt = xi to zi }
                        }
                    }
                    Text(stringResource(R.string.atlas_inspect_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_nearby), Icons.Rounded.Place)
                    Spacer(Modifier.height(10.dp))
                    Acts { listOf(500, 1000, 5000, 10000).forEach { n -> TagChip("$n", range == n) { range = n } } }
                    val ref = if (pl != null) pl[0].toInt() to pl[2].toInt() else spawn
                    if (ref == null) {
                        Text(stringResource(R.string.atlas_no_ref), color = dim, modifier = Modifier.padding(top = 10.dp))
                    } else {
                        val list = marks.map { it to dist2(ref.first, ref.second, it.second, it.third) }.filter { it.second <= range }.sortedBy { it.second }
                        if (list.isEmpty()) Text(stringResource(R.string.atlas_none_in_range), color = dim, modifier = Modifier.padding(top = 10.dp))
                        list.forEach { e ->
                            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(e.first.first.name, Modifier.weight(1f))
                                Text(e.second.toInt().toString() + " m", color = dim)
                            }
                        }
                    }
                    Text(stringResource(R.string.atlas_nearby_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.atlas_route), Icons.Rounded.Place)
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.atlas_from), color = dim)
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(fx, { fx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                        OutlinedTextField(fz, { fz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                    }
                    Acts {
                        if (spawn != null) TagChip(stringResource(R.string.atlas_spawn), false) { fx = spawn.first.toString(); fz = spawn.second.toString() }
                        if (pl != null) TagChip(stringResource(R.string.atlas_player), false) { fx = pl[0].toInt().toString(); fz = pl[2].toInt().toString() }
                        marks.take(6).forEach { m -> TagChip(m.first.name, false) { fx = m.second.toString(); fz = m.third.toString() } }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(stringResource(R.string.atlas_to), color = dim)
                    Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(tx, { tx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                        OutlinedTextField(tz, { tz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                    }
                    Acts {
                        if (spawn != null) TagChip(stringResource(R.string.atlas_spawn), false) { tx = spawn.first.toString(); tz = spawn.second.toString() }
                        if (pl != null) TagChip(stringResource(R.string.atlas_player), false) { tx = pl[0].toInt().toString(); tz = pl[2].toInt().toString() }
                        marks.take(6).forEach { m -> TagChip(m.first.name, false) { tx = m.second.toString(); tz = m.third.toString() } }
                    }
                    val x1 = fx.toIntOrNull(); val z1 = fz.toIntOrNull(); val x2 = tx.toIntOrNull(); val z2 = tz.toIntOrNull()
                    if (x1 != null && z1 != null && x2 != null && z2 != null) {
                        val d = dist2(x1, z1, x2, z2)
                        Column(Modifier.padding(top = 12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            DetailRow(R.string.atlas_distance, d.toInt().toString() + " m")
                            DetailRow(R.string.atlas_delta, "ΔX ${x2 - x1}, ΔZ ${z2 - z1}")
                            DetailRow(R.string.atlas_direction, stringResource(compassRes(x2 - x1, z2 - z1)))
                            DetailRow(R.string.atlas_nether_eq, (d / 8.0).toInt().toString() + " m")
                        }
                        Spacer(Modifier.height(10.dp))
                        Acts {
                            Act(R.string.atlas_show, Icons.Rounded.Map) {
                                vm.routeA = x1 to z1; vm.routeB = x2 to z2; vm.atlasWorld = r.id; vm.mapFocus = (x1 + x2) / 2 to (z1 + z2) / 2
                                nav.navigate("map")
                            }
                        }
                    }
                    Text(stringResource(R.string.atlas_route_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }
    addAt?.let { p ->
        AlertDialog(
            onDismissRequest = { addAt = null },
            title = { Text(stringResource(R.string.atlas_add_marker)) },
            text = { OutlinedTextField(addName, { addName = it }, singleLine = true, label = { Text(stringResource(R.string.sd_name)) }) },
            confirmButton = {
                TextButton({
                    if (addName.isNotBlank()) { vm.addPlace(addName.trim(), 5, p.first.toString(), "~", p.second.toString(), r?.name ?: ""); addAt = null }
                }) { Text(stringResource(R.string.a_done)) }
            },
            dismissButton = { TextButton({ addAt = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

@Composable
fun MapScreen(vm: MainVm, nav: NavController) {
    val r = vm.rows.find { it.id == vm.atlasWorld }
    val a = r?.let { vm.atlas[it.id] }
    val look = LocalLook.current
    val prim = MaterialTheme.colorScheme.primary
    val sec = MaterialTheme.colorScheme.secondary
    if (a == null || r == null) {
        Page(R.string.nav_atlas, onBack = { nav.popBackStack() }) { item { Glass { Text(stringResource(R.string.atlas_no_data)) } } }
        return
    }
    val info = vm.infos[r.id]
    var dim by remember { mutableStateOf(a.playerDim.coerceIn(0, 2)) }
    var scale by remember { mutableStateOf(0.4f) }
    var cx by remember { mutableStateOf(0f) }
    var cz by remember { mutableStateOf(0f) }
    var sel by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var gotoDlg by remember { mutableStateOf(false) }
    var modeDlg by remember { mutableStateOf(false) }
    var addDlg by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var gx by remember { mutableStateOf("") }
    var gz by remember { mutableStateOf("") }
    val spawn = spawnXZ(info)
    val marks = marksOf(vm, r.name)
    LaunchedEffect(r.id) {
        val f = vm.mapFocus
        val b = a.bounds(dim)
        if (f != null) {
            cx = f.first.toFloat(); cz = f.second.toFloat(); scale = 1f; vm.mapFocus = null
        } else if (b != null) {
            cx = (b[0] + b[1] + 1) * 8f; cz = (b[2] + b[3] + 1) * 8f
            val span = maxOf(b[1] - b[0] + 1, b[3] - b[2] + 1) * 16f
            scale = (900f / span).coerceIn(0.02f, 4f)
        }
    }
    val bg = look.bg[0]
    val ra = vm.routeA
    val rb = vm.routeB
    val player = a.player
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    Box(Modifier.fillMaxSize()) {
        Canvas(
            Modifier.fillMaxSize()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        cx -= pan.x / scale
                        cz -= pan.y / scale
                        scale = (scale * zoom).coerceIn(0.02f, 10f)
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { o ->
                        val bx = cx + (o.x - size.width / 2f) / scale
                        val bz = cz + (o.y - size.height / 2f) / scale
                        sel = Math.floor(bx.toDouble()).toInt() to Math.floor(bz.toDouble()).toInt()
                    }
                }
        ) {
            val w = size.width
            val h = size.height
            drawRect(bg)
            drawAtlas(a, dim, cx, cz, scale, prim.copy(alpha = .30f), prim)
            fun px(x: Float) = (x - cx) * scale + w / 2f
            fun pz(z: Float) = (z - cz) * scale + h / 2f
            drawLine(Color(0x33FFFFFF), Offset(px(0f), 0f), Offset(px(0f), h), 1f)
            drawLine(Color(0x33FFFFFF), Offset(0f, pz(0f)), Offset(w, pz(0f)), 1f)
            if (dim == 0) {
                if (spawn != null) drawCircle(Green, 9f, Offset(px(spawn.first.toFloat()), pz(spawn.second.toFloat())))
                marks.forEach { m -> drawCircle(Amber, 7f, Offset(px(m.second.toFloat()), pz(m.third.toFloat()))) }
            }
            if (player != null && a.playerDim == dim) {
                drawCircle(sec, 10f, Offset(px(player[0].toFloat()), pz(player[2].toFloat())))
                drawCircle(Color.White, 10f, Offset(px(player[0].toFloat()), pz(player[2].toFloat())), style = Stroke(2f))
            }
            if (ra != null && rb != null) {
                drawLine(Rose, Offset(px(ra.first.toFloat()), pz(ra.second.toFloat())), Offset(px(rb.first.toFloat()), pz(rb.second.toFloat())), 4f)
            }
            sel?.let { s -> drawCircle(Color.White, 14f, Offset(px(s.first + 0.5f), pz(s.second + 0.5f)), style = Stroke(3f)) }
        }
        Column(Modifier.statusBarsPadding().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC000000)).padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, tint = Color.White) }
                Text(
                    "X ${cx.toInt()}  Z ${cz.toInt()}  ·  ${"%.2f".format(scale)} px/m",
                    color = Color.White, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall
                )
                IconButton(onClick = { gx = cx.toInt().toString(); gz = cz.toInt().toString(); gotoDlg = true }) { Icon(Icons.Rounded.Place, null, tint = Color.White) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (0..2).forEach { d -> TagChip(stringResource(dimRes(d)), d == dim) { dim = d } }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TagChip(stringResource(R.string.map_seed), false) { modeDlg = true }
                TagChip(stringResource(R.string.map_explored), true) { }
                TagChip(stringResource(R.string.map_combined), false) { modeDlg = true }
            }
        }
        sel?.let { s ->
            val kx = Math.floorDiv(s.first, 16)
            val kz = Math.floorDiv(s.second, 16)
            val has = a.chunks[dim].contains(packXZ(kx, kz))
            val hasB = a.blocks[dim].contains(packXZ(kx, kz))
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(12.dp)) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("X ${s.first}  Z ${s.second}", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { sel = null }) { Icon(Icons.Rounded.Close, null) }
                    }
                    Text(
                        stringResource(R.string.atlas_chunk) + " $kx, $kz · " +
                            stringResource(if (hasB) R.string.atlas_data_terrain else if (has) R.string.atlas_data_chunk else R.string.atlas_data_none),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val near = marks.minByOrNull { dist2(s.first, s.second, it.second, it.third) }
                    if (near != null) Text(
                        stringResource(R.string.atlas_nearest) + ": " + near.first.name + " · " + dist2(s.first, s.second, near.second, near.third).toInt() + " m",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.atlas_add_marker, Icons.Rounded.Add) { name = ""; addDlg = true }
                        Act(R.string.atlas_set_from, Icons.Rounded.Place) { vm.routeA = s }
                        Act(R.string.atlas_set_to, Icons.Rounded.Place) { vm.routeB = s }
                    }
                }
            }
        }
    }
    if (gotoDlg) {
        AlertDialog(
            onDismissRequest = { gotoDlg = false },
            title = { Text(stringResource(R.string.atlas_goto)) },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(gx, { gx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                    OutlinedTextField(gz, { gz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                }
            },
            confirmButton = {
                TextButton({
                    val x = gx.toFloatOrNull()
                    val z = gz.toFloatOrNull()
                    if (x != null && z != null) { cx = x; cz = z; gotoDlg = false }
                }) { Text(stringResource(R.string.a_done)) }
            },
            dismissButton = { TextButton({ gotoDlg = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (modeDlg) {
        AlertDialog(
            onDismissRequest = { modeDlg = false },
            title = { Text(stringResource(R.string.map_modes)) },
            text = { Text(stringResource(R.string.map_mode_unavail)) },
            confirmButton = { TextButton({ modeDlg = false }) { Text(stringResource(R.string.a_done)) } }
        )
    }
    if (addDlg) {
        AlertDialog(
            onDismissRequest = { addDlg = false },
            title = { Text(stringResource(R.string.atlas_add_marker)) },
            text = { OutlinedTextField(name, { name = it }, singleLine = true, label = { Text(stringResource(R.string.sd_name)) }) },
            confirmButton = {
                TextButton({
                    val s = sel
                    if (name.isNotBlank() && s != null) { vm.addPlace(name.trim(), 5, s.first.toString(), "~", s.second.toString(), r.name); addDlg = false }
                }) { Text(stringResource(R.string.a_done)) }
            },
            dismissButton = { TextButton({ addDlg = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
