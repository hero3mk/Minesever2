package app.minesaver

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

private val SeedCats = listOf(R.string.sc_survival, R.string.sc_speedrun, R.string.sc_building, R.string.sc_adventure)
private val Editions = listOf("Bedrock", "Java")

// ---------- Seed library ----------
@Composable
fun SeedsScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var name by remember { mutableStateOf("") }
    var seed by remember { mutableStateOf("") }
    var ver by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var ed by remember { mutableStateOf(0) }
    var cat by remember { mutableStateOf(0) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(-1) }
    var del by remember { mutableStateOf<String?>(null) }
    var vSeed by remember { mutableStateOf("") }
    var vWorld by remember { mutableStateOf<String?>(null) }
    var cA by remember { mutableStateOf<String?>(null) }
    var cB by remember { mutableStateOf<String?>(null) }
    val worlds = vm.rows
    LaunchedEffect(vWorld) { vWorld?.let { vm.ensureInfo(listOf(it)) } }
    val list = vm.seeds.filter { s ->
        (query.isBlank() || s.name.contains(query, true) || s.seed.contains(query, true) || s.note.contains(query, true)) &&
            (filter == -1 || (filter == 100 && s.fav) || (filter in 0..3 && s.cat == filter))
    }.sortedByDescending { it.fav }
    Page(R.string.title_seeds, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(seed, { seed = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_seed)) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(ver, { ver = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.r_version)) })
                    OutlinedTextField(note, { note = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.sd_note)) })
                }
                Spacer(Modifier.height(8.dp))
                Acts { Editions.forEachIndexed { i, e -> TagChip(e, ed == i) { ed = i } } }
                Spacer(Modifier.height(6.dp))
                Acts { SeedCats.forEachIndexed { i, c -> TagChip(stringResource(c), cat == i) { cat = i } } }
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.sd_add, Icons.Rounded.Add) {
                        if (seed.isNotBlank()) {
                            vm.addSeed(name.ifBlank { seed }, seed.trim(), note, Editions[ed], ver.trim(), cat)
                            name = ""; seed = ""; ver = ""; note = ""
                        }
                    }
                }
            }
        }
        item {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.w_search)) })
        }
        item {
            Acts {
                TagChip(stringResource(R.string.tag_all), filter == -1) { filter = -1 }
                TagChip(stringResource(R.string.sd_favs), filter == 100) { filter = 100 }
                SeedCats.forEachIndexed { i, c -> TagChip(stringResource(c), filter == i) { filter = i } }
            }
        }
        if (list.isEmpty()) item { Text(stringResource(R.string.sd_empty), color = dim) }
        itemsIndexed(list, key = { _, s -> s.id }) { i, s ->
            Appear(i) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(s.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        IconButton(onClick = { vm.toggleSeedFav(s.id) }) { Icon(if (s.fav) Icons.Rounded.Star else Icons.Rounded.StarBorder, null, tint = Amber) }
                    }
                    Text(s.seed, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary)
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Badge(s.edition, MaterialTheme.colorScheme.secondary)
                        if (s.version.isNotBlank()) Badge(s.version, MaterialTheme.colorScheme.tertiary)
                        Badge(stringResource(SeedCats[s.cat.coerceIn(0, 3)]), Green)
                    }
                    if (s.note.isNotBlank()) Text(s.note, style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(s.seed)); vm.toast = Msg(R.string.copied, s.seed) }
                        Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = s.id }
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.sd_verify), Icons.Rounded.VerifiedUser)
                Text(stringResource(R.string.sd_verify_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                OutlinedTextField(vSeed, { vSeed = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_seed)) })
                Spacer(Modifier.height(8.dp))
                Acts { worlds.filter { it.backups.isNotEmpty() }.forEach { w -> TagChip(w.name, vWorld == w.id) { vWorld = w.id } } }
                val ws = vWorld?.let { vm.infos[it]?.seed }
                if (vWorld != null && vSeed.isNotBlank()) {
                    val res = if (ws == null) R.string.sd_v_unknown else if (ws.toString() == vSeed.trim()) R.string.sd_v_match else R.string.sd_v_diff
                    Text(stringResource(res), fontWeight = FontWeight.SemiBold, color = if (res == R.string.sd_v_match) Green else Amber, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.sd_compare), Icons.Rounded.Search)
                Spacer(Modifier.height(8.dp))
                Acts { vm.seeds.take(12).forEach { s -> TagChip(s.name, cA == s.id) { cA = s.id } } }
                Spacer(Modifier.height(6.dp))
                Acts { vm.seeds.take(12).forEach { s -> TagChip(s.name, cB == s.id) { cB = s.id } } }
                val a = vm.seeds.find { it.id == cA }
                val b = vm.seeds.find { it.id == cB }
                if (a != null && b != null) {
                    CompareRow(R.string.r_seed, a.seed, b.seed)
                    CompareRow(R.string.r_version, a.version.ifBlank { "—" }, b.version.ifBlank { "—" })
                    CompareRow(R.string.sd_edition, a.edition, b.edition)
                    Text(stringResource(if (a.seed == b.seed) R.string.sd_same else R.string.sd_different), color = dim, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.sd_exchange), Icons.Rounded.Share)
                Spacer(Modifier.height(8.dp))
                Acts {
                    Act(R.string.sd_export_all, Icons.Rounded.ContentCopy) {
                        val t = vm.seeds.joinToString("\n") { listOf(it.name, it.seed, it.edition, it.version, it.cat.toString(), it.note).joinToString("|") }
                        clip.setText(AnnotatedString(t)); vm.toast = Msg(R.string.copied, vm.seeds.size.toString())
                    }
                    Act(R.string.sd_import_clip, Icons.Rounded.FileUpload) {
                        val t = clip.getText()?.text ?: ""
                        var n = 0
                        t.lines().forEach { ln ->
                            val p = ln.split("|")
                            if (p.size >= 2 && p[1].isNotBlank()) {
                                vm.addSeed(p[0].ifBlank { p[1] }, p[1].trim(), p.getOrNull(5) ?: "", p.getOrNull(2)?.takeIf { it in Editions } ?: "Bedrock", p.getOrNull(3) ?: "", p.getOrNull(4)?.toIntOrNull()?.coerceIn(0, 3) ?: 0)
                                n++
                            }
                        }
                        vm.toast = Msg(R.string.sd_imported, n)
                    }
                }
                Text(stringResource(R.string.sd_engine_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
    }
    del?.let { sid -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deleteSeed(sid); del = null }, { del = null }) }
}

// ---------- Coordinates manager ----------
private val PlaceTypes2 = listOf(R.string.pl_home, R.string.pl_mine, R.string.pl_village, R.string.pl_portal, R.string.pl_base, R.string.pl_other)
private val DimNames = listOf(R.string.dim_over, R.string.dim_nether, R.string.dim_end)

@Composable
fun PlacesScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    var name by remember { mutableStateOf("") }
    var world by remember { mutableStateOf("") }
    var px by remember { mutableStateOf("") }
    var py by remember { mutableStateOf("") }
    var pz by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(0) }
    var pd by remember { mutableStateOf(0) }
    var del by remember { mutableStateOf<String?>(null) }
    var dA by remember { mutableStateOf<String?>(null) }
    var dB by remember { mutableStateOf<String?>(null) }
    val csv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { u: Uri? ->
        if (u != null) runCatching {
            val t = "name,type,dimension,x,y,z,world\n" + vm.places.joinToString("\n") { listOf(it.name, it.type, it.dim, it.x, it.y, it.z, it.world).joinToString(",") { c -> "\"" + c.toString().replace("\"", "\"\"") + "\"" } }
            ctx.contentResolver.openOutputStream(u)?.use { it.write(t.toByteArray()) }
        }
    }
    Page(R.string.title_places, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(world, { world = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.pl_world)) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(px, { px = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                    OutlinedTextField(py, { py = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, keyboardOptions = numeric)
                    OutlinedTextField(pz, { pz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                }
                Spacer(Modifier.height(10.dp))
                Acts { DimNames.forEachIndexed { i, r -> TagChip(stringResource(r), pd == i) { pd = i } } }
                Spacer(Modifier.height(6.dp))
                Acts { PlaceTypes2.forEachIndexed { i, r -> TagChip(stringResource(r), type == i) { type = i } } }
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.pl_add, Icons.Rounded.Add) {
                        if (name.isNotBlank() && px.isNotBlank() && pz.isNotBlank()) {
                            vm.addPlace(name.trim(), type, px.trim(), py.trim().ifEmpty { "~" }, pz.trim(), world.trim(), pd)
                            name = ""; px = ""; py = ""; pz = ""
                        }
                    }
                }
            }
        }
        if (vm.places.isNotEmpty()) item {
            Acts {
                Act(R.string.pl_share_all, Icons.Rounded.Share) {
                    val t = vm.places.joinToString("\n") { it.name + ": " + it.x + " " + it.y + " " + it.z + " (" + ctx.getString(DimNames[it.dim.coerceIn(0, 2)]) + ")" }
                    ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null))
                }
                Act(R.string.pl_export, Icons.Rounded.FileUpload) { csv.launch("minesaver-places.csv") }
            }
        }
        if (vm.places.isEmpty()) item { Text(stringResource(R.string.pl_empty), color = dim) }
        itemsIndexed(vm.places, key = { _, p -> p.id }) { i, p ->
            val coords = p.x + " " + p.y + " " + p.z
            Appear(i) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Badge(stringResource(PlaceTypes2[p.type.coerceIn(0, PlaceTypes2.lastIndex)]), MaterialTheme.colorScheme.secondary)
                    }
                    Text(coords, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    Text(stringResource(DimNames[p.dim.coerceIn(0, 2)]) + (if (p.world.isNotBlank()) " · " + p.world else ""), style = MaterialTheme.typography.bodySmall, color = dim)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(coords)); vm.toast = Msg(R.string.copied, coords) }
                        Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = p.id }
                    }
                }
            }
        }
        if (vm.places.size >= 2) item {
            Glass {
                SectionTitle(stringResource(R.string.pl_distance), Icons.Rounded.Map)
                Spacer(Modifier.height(8.dp))
                Acts { vm.places.take(12).forEach { p -> TagChip(p.name, dA == p.id) { dA = p.id } } }
                Spacer(Modifier.height(6.dp))
                Acts { vm.places.take(12).forEach { p -> TagChip(p.name, dB == p.id) { dB = p.id } } }
                val a = vm.places.find { it.id == dA }
                val b = vm.places.find { it.id == dB }
                val ax = a?.x?.toDoubleOrNull(); val az = a?.z?.toDoubleOrNull(); val bx = b?.x?.toDoubleOrNull(); val bz = b?.z?.toDoubleOrNull()
                if (ax != null && az != null && bx != null && bz != null) {
                    Text(Math.hypot(ax - bx, az - bz).toInt().toString() + " m", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 10.dp))
                    if (a?.dim != b?.dim) Text(stringResource(R.string.pl_diff_dim), style = MaterialTheme.typography.bodySmall, color = Amber)
                }
            }
        }
    }
    del?.let { pid -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deletePlace(pid); del = null }, { del = null }) }
}

// ---------- Slime chunk finder (experimental) ----------
@Composable
fun SlimeCard(spawn: Pair<Int, Int>?, player: Pair<Int, Int>?) {
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    var x by remember { mutableStateOf("") }
    var z by remember { mutableStateOf("") }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Glass {
        SectionTitle(stringResource(R.string.slime_title), Icons.Rounded.Search)
        Text(stringResource(R.string.slime_warn), style = MaterialTheme.typography.bodySmall, color = Amber, modifier = Modifier.padding(vertical = 8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(x, { x = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
            OutlinedTextField(z, { z = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
        }
        Acts {
            if (spawn != null) TagChip(stringResource(R.string.atlas_spawn), false) { x = spawn.first.toString(); z = spawn.second.toString() }
            if (player != null) TagChip(stringResource(R.string.atlas_player), false) { x = player.first.toString(); z = player.second.toString() }
        }
        val xi = x.toIntOrNull()
        val zi = z.toIntOrNull()
        if (xi != null && zi != null) {
            val kx = Math.floorDiv(xi, 16)
            val kz = Math.floorDiv(zi, 16)
            Text(
                stringResource(if (Slime.isSlime(kx, kz)) R.string.slime_here_yes else R.string.slime_here_no, kx, kz),
                fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp)
            )
            Slime.nearest(kx, kz, 14, 6).forEach { r ->
                Text(
                    stringResource(R.string.slime_row, r.first, r.second, r.first * 16, r.second * 16, (r.third * 16).toInt()),
                    style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
        Text(stringResource(R.string.slime_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
    }
}

// ---------- Global search ----------
@Composable
fun SearchScreen(vm: MainVm, nav: NavController) {
    var q by remember { mutableStateOf("") }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val nq = Assistant.norm(q.trim())
    fun m(s: String?) = s != null && nq.isNotEmpty() && Assistant.norm(s).contains(nq)
    val settingsIdx = listOf(
        R.string.set_theme to "settings", R.string.set_lang to "settings", R.string.set_lock to "settings", R.string.sz_title to "settings",
        R.string.set_auto to "automation", R.string.title_trash to "trash", R.string.title_encrypt to "encrypt", R.string.title_dataprot to "dataprot",
        R.string.title_privacy to "privacy", R.string.title_help to "help", R.string.title_about to "about", R.string.title_storage to "storage"
    )
    val setNames = settingsIdx.map { Triple(it.first, stringResource(it.first), it.second) }
    LaunchedEffect(nq) { if (nq.length >= 2) { delay(900); vm.rememberSearch(q) } }
    Page(R.string.title_search, onBack = { nav.popBackStack() }) {
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.search_hint)) },
                leadingIcon = { Icon(Icons.Rounded.Search, null) })
        }
        if (nq.isEmpty()) {
            if (vm.recent.isNotEmpty()) item {
                Glass {
                    SectionTitle(stringResource(R.string.search_recent), Icons.Rounded.History)
                    vm.recent.mapNotNull { id -> vm.rows.find { it.id == id } }.forEach { w ->
                        Text(w.name, Modifier.fillMaxWidth().clickable { vm.detailId = w.id; nav.navigate("world") }.padding(top = 10.dp))
                    }
                }
            }
            if (vm.searchHist.isNotEmpty()) item {
                Glass {
                    SectionTitle(stringResource(R.string.search_history), Icons.Rounded.History)
                    Spacer(Modifier.height(8.dp))
                    Acts { vm.searchHist.forEach { h -> TagChip(h, false) { q = h } } }
                    Spacer(Modifier.height(8.dp))
                    Acts { Act(R.string.a_clear_log, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.clearSearchHistory() } }
                }
            }
            return@Page
        }
        val worlds = vm.rows.filter { m(it.name) || m(vm.noteOf(it.id)) || vm.tagsOf(it.id).any { t -> m(t) } }
        val backs = vm.backups.filter { m(it.worldName) || m(vm.bnameOf(it.id)) || m(vm.bnoteOf(it.id)) }
        val seeds = vm.seeds.filter { m(it.name) || m(it.seed) || m(it.note) }
        val addons = vm.addons.filter { m(it.name) || m(it.uuid) || m(it.desc) }
        val places = vm.places.filter { m(it.name) || m(it.world) }
        val builds = vm.builds.filter { m(it.name) || m(it.notes) }
        val sets = setNames.filter { m(it.second) }
        if (worlds.isEmpty() && backs.isEmpty() && seeds.isEmpty() && addons.isEmpty() && places.isEmpty() && builds.isEmpty() && sets.isEmpty()) {
            item { Text(stringResource(R.string.search_none), color = dim) }
        }
        if (worlds.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.title_worlds), Icons.Rounded.Map)
                worlds.take(8).forEach { w -> Text(w.name, Modifier.fillMaxWidth().clickable { vm.detailId = w.id; vm.viewedWorld(w.id); nav.navigate("world") }.padding(top = 10.dp)) }
            }
        }
        if (backs.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.title_backups), Icons.Rounded.Storage)
                backs.take(8).forEach { b ->
                    Text(
                        b.worldName + " · " + fmtDate(b.time) + vm.bnameOf(b.id).let { if (it.isBlank()) "" else " · $it" },
                        Modifier.fillMaxWidth().clickable { vm.pick = b.id; nav.navigate("restore") }.padding(top = 10.dp)
                    )
                }
            }
        }
        if (seeds.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.title_seeds), Icons.Rounded.Star)
                seeds.take(8).forEach { s -> Text(s.name + " · " + s.seed, Modifier.fillMaxWidth().clickable { nav.navigate("seeds") }.padding(top = 10.dp), maxLines = 1, overflow = TextOverflow.Ellipsis) }
            }
        }
        if (addons.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.nav_addons), Icons.Rounded.Extension)
                addons.take(8).forEach { a -> Text(a.name + " · v" + a.version, Modifier.fillMaxWidth().clickable { vm.addonSel = a.id + "|" + a.file; nav.navigate("addon") }.padding(top = 10.dp)) }
            }
        }
        if (places.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.title_places), Icons.Rounded.Map)
                places.take(8).forEach { p -> Text(p.name + " · " + p.x + " " + p.z, Modifier.fillMaxWidth().clickable { nav.navigate("places") }.padding(top = 10.dp)) }
            }
        }
        if (builds.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.title_builds), Icons.Rounded.Build)
                builds.take(8).forEach { b -> Text(b.name, Modifier.fillMaxWidth().clickable { vm.buildSel = b.id; nav.navigate("build") }.padding(top = 10.dp)) }
            }
        }
        if (sets.isNotEmpty()) item {
            Glass {
                SectionTitle(stringResource(R.string.nav_settings), Icons.Rounded.Settings)
                sets.forEach { s -> Text(s.second, Modifier.fillMaxWidth().clickable { nav.navigate(s.third) }.padding(top = 10.dp)) }
            }
        }
    }
}

// ---------- Command center ----------
@Composable
fun CommandScreen(vm: MainVm, nav: NavController) {
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.import(it) }
    Page(R.string.title_command, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.cmd_intro), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.home_backup_all, Icons.Rounded.CloudUpload, Modifier.weight(1f)) { vm.backupAll() }
                    Tile(R.string.title_worlds, Icons.Rounded.Map, Modifier.weight(1f)) { nav.navigate("worlds") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_seeds, Icons.Rounded.Star, Modifier.weight(1f)) { nav.navigate("seeds") }
                    Tile(R.string.title_atlas_map, Icons.Rounded.Map, Modifier.weight(1f)) { nav.navigate("atlas") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.ad_inspector, Icons.Rounded.Extension, Modifier.weight(1f)) { nav.navigate("addon_check") }
                    Tile(R.string.a_storage, Icons.Rounded.Storage, Modifier.weight(1f)) { nav.navigate("storage") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.transfer_import, Icons.Rounded.FolderOpen, Modifier.weight(1f)) { imp.launch(arrayOf("*/*")) }
                    Tile(R.string.title_places, Icons.Rounded.Map, Modifier.weight(1f)) { nav.navigate("places") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_cmpb, Icons.Rounded.Refresh, Modifier.weight(1f)) { nav.navigate("cmpb") }
                    Tile(R.string.title_dataprot, Icons.Rounded.VerifiedUser, Modifier.weight(1f)) { nav.navigate("dataprot") }
                }
            }
        }
    }
}

// ---------- Game ----------
@Composable
fun GameScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val pkg = "com.mojang.minecraftpe"
    val pi = remember { runCatching { ctx.packageManager.getPackageInfo(pkg, 0) }.getOrNull() }
    var dataSize by remember { mutableStateOf<Long?>(null) }
    var launchAfter by remember { mutableStateOf(false) }
    LaunchedEffect(vm.szActive) {
        if (vm.szActive) dataSize = withContext(Dispatchers.IO) { runCatching { Sz.du("/storage/emulated/0/Android/data/$pkg") }.getOrNull() }
    }
    LaunchedEffect(vm.busy, launchAfter) {
        if (launchAfter && vm.busy == null) {
            launchAfter = false
            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { runCatching { ctx.startActivity(it) } }
        }
    }
    Page(R.string.title_game, onBack = { nav.popBackStack() }) {
        if (pi == null) {
            item { Glass { Text(stringResource(R.string.gm_missing)) } }
            item {
                Acts {
                    Act(R.string.a_get_sz, Icons.Rounded.Map) {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))) }
                    }
                }
            }
            return@Page
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.gm_status), Icons.Rounded.Info)
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow(R.string.gm_installed, stringResource(R.string.v_yes))
                    DetailRow(R.string.r_version, pi.versionName ?: "—")
                    DetailRow(R.string.gm_code, (if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode else 0L).toString())
                    DetailRow(R.string.gm_first, fmtDate(pi.firstInstallTime))
                    DetailRow(R.string.gm_updated, fmtDate(pi.lastUpdateTime))
                    DetailRow(R.string.gm_apk, fmtSize(runCatching { File(pi.applicationInfo?.sourceDir ?: "").length() }.getOrDefault(0L)))
                    DetailRow(R.string.gm_data, dataSize?.let { fmtSize(it) } ?: stringResource(R.string.gm_data_na))
                }
                Text(stringResource(R.string.gm_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.gm_actions), Icons.Rounded.Star)
                Spacer(Modifier.height(8.dp))
                Acts {
                    Act(R.string.gm_launch, Icons.Rounded.Map) { ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { runCatching { ctx.startActivity(it) } } }
                    Act(R.string.gm_backup_play, Icons.Rounded.CloudUpload) { vm.backupAll(); launchAfter = true }
                    Act(R.string.gm_appinfo, Icons.Rounded.Settings) {
                        runCatching { ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))) }
                    }
                }
            }
        }
    }
}

// ---------- Developer tools ----------
@Composable
fun DevToolsScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var tab by remember { mutableStateOf(0) }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var out by remember { mutableStateOf("") }
    var uuids by remember { mutableStateOf(listOf<String>()) }
    var uuidIn by remember { mutableStateOf("") }
    var fileInfo by remember { mutableStateOf("") }
    var tests by remember { mutableStateOf<List<Pair<Int, Boolean>>>(emptyList()) }
    val loadJson = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) runCatching { a = ctx.contentResolver.openInputStream(u)?.use { String(it.readNBytesCompat(1_000_000)) } ?: "" }
    }
    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u: Uri? ->
        if (u != null) runCatching { ctx.contentResolver.openOutputStream(u)?.use { it.write((if (out.isNotBlank()) out else a).toByteArray()) } }
    }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            fileInfo = ctx.getString(R.string.dv_working)
            scope.launch {
                fileInfo = withContext(Dispatchers.IO) {
                    val tmp = File(ctx.cacheDir, "hash_${System.nanoTime()}.tmp")
                    try {
                        var total = 0L
                        (ctx.contentResolver.openInputStream(u) ?: return@withContext "Cannot read file").use { i ->
                            tmp.outputStream().use { o ->
                                val buf = ByteArray(65536)
                                while (true) {
                                    val r = i.read(buf)
                                    if (r < 0) break
                                    total += r
                                    if (total > 2_000_000_000L) return@withContext "File is too large"
                                    o.write(buf, 0, r)
                                }
                            }
                        }
                        val head = tmp.inputStream().use { s -> val h = ByteArray(256); val n = s.read(h); if (n <= 0) ByteArray(0) else h.copyOf(n) }
                        ctx.getString(signatureRes(head)) + "\n" + total + " bytes\nSHA-256 " + hashFile(tmp, "SHA-256") + "\nSHA-1 " + hashFile(tmp, "SHA-1") + "\nMD5 " + hashFile(tmp, "MD5") + "\n\n" + hexDump(head, 0)
                    } catch (e: Exception) { e.message ?: "error" } finally { tmp.delete() }
                }
            }
        }
    }
    Page(R.string.title_devtools, onBack = { nav.popBackStack() }) {
        item {
            Acts {
                listOf(R.string.dv_json, R.string.dv_hash, R.string.dv_uuid, R.string.dv_perm).forEachIndexed { i, r -> TagChip(stringResource(r), tab == i) { tab = i } }
            }
        }
        if (tab == 0) {
            item {
                Glass {
                    OutlinedTextField(a, { a = it }, Modifier.fillMaxWidth(), minLines = 5, maxLines = 12, label = { Text("JSON A") }, textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(b, { b = it }, Modifier.fillMaxWidth(), minLines = 3, maxLines = 8, label = { Text("JSON B (" + stringResource(R.string.dv_compare) + ")") }, textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp))
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        Act(R.string.dv_validate, Icons.Rounded.VerifiedUser) {
                            out = try { if (a.trim().startsWith("[")) { JSONArray(a); ctx.getString(R.string.dv_valid) } else { JSONObject(a); ctx.getString(R.string.dv_valid) } } catch (e: Exception) { ctx.getString(R.string.dv_invalid) + ": " + (e.message ?: "") }
                        }
                        Act(R.string.dv_format, Icons.Rounded.Build) {
                            out = try { if (a.trim().startsWith("[")) JSONArray(a).toString(2) else JSONObject(a).toString(2) } catch (e: Exception) { ctx.getString(R.string.dv_invalid) + ": " + (e.message ?: "") }
                        }
                        Act(R.string.dv_minify, Icons.Rounded.Build) {
                            out = try { if (a.trim().startsWith("[")) JSONArray(a).toString() else JSONObject(a).toString() } catch (e: Exception) { ctx.getString(R.string.dv_invalid) + ": " + (e.message ?: "") }
                        }
                        Act(R.string.dv_clean, Icons.Rounded.Refresh) {
                            val r = cleanJson(a)
                            a = r.first
                            out = if (r.second.isEmpty()) ctx.getString(R.string.dv_nothing) else r.second.joinToString("\n") { ctx.getString(it) }
                        }
                        Act(R.string.dv_compare, Icons.Rounded.Search) {
                            out = try {
                                val x = JSONObject(a); val y = JSONObject(b)
                                val ks = (x.keys().asSequence().toSet() + y.keys().asSequence().toSet()).sorted()
                                val lines = ks.mapNotNull { k ->
                                    if (!x.has(k)) "+ $k" else if (!y.has(k)) "- $k" else if (x.get(k).toString() != y.get(k).toString()) "~ $k" else null
                                }
                                if (lines.isEmpty()) ctx.getString(R.string.dv_identical) else lines.joinToString("\n")
                            } catch (e: Exception) { ctx.getString(R.string.dv_invalid) + ": " + (e.message ?: "") }
                        }
                        Act(R.string.fi_pick, Icons.Rounded.FolderOpen) { loadJson.launch(arrayOf("*/*")) }
                        Act(R.string.mb_save, Icons.Rounded.FileUpload) { saveJson.launch("data.json") }
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(if (out.isNotBlank()) out else a)) }
                    }
                }
            }
            if (out.isNotBlank()) item { Glass { Text(out, fontFamily = FontFamily.Monospace, fontSize = 12.sp) } }
        }
        if (tab == 1) {
            item {
                Glass {
                    Text(stringResource(R.string.dv_hash_hint), style = MaterialTheme.typography.bodySmall, color = dim)
                    Spacer(Modifier.height(10.dp))
                    Acts { Act(R.string.fi_pick, Icons.Rounded.FolderOpen) { pickFile.launch(arrayOf("*/*")) } }
                    if (fileInfo.isNotBlank()) Text(fileInfo, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        if (tab == 2) {
            item {
                Glass {
                    Acts { Act(R.string.dv_gen, Icons.Rounded.Refresh) { uuids = List(5) { UUID.randomUUID().toString() } } }
                    uuids.forEach { u ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(u, Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                            IconButton(onClick = { clip.setText(AnnotatedString(u)) }) { Icon(Icons.Rounded.ContentCopy, null) }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(uuidIn, { uuidIn = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.dv_uuid_check)) })
                    if (uuidIn.isNotBlank()) {
                        val ok = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$").matches(uuidIn.trim())
                        Text(stringResource(if (ok) R.string.dv_valid else R.string.dv_invalid), color = if (ok) Green else MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                    }
                }
            }
        }
        if (tab == 3) {
            item {
                Glass {
                    Text(stringResource(R.string.dv_perm_hint), style = MaterialTheme.typography.bodySmall, color = dim)
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        Act(R.string.dv_run, Icons.Rounded.VerifiedUser) {
                            scope.launch {
                                tests = withContext(Dispatchers.IO) {
                                    val l = ArrayList<Pair<Int, Boolean>>()
                                    l.add(R.string.dp_a_shizuku to vm.szActive)
                                    l.add(R.string.dv_t_worlds to (vm.szActive && runCatching { Sz.worldDirs().isNotEmpty() }.getOrDefault(false)))
                                    l.add(R.string.dp_a_src to (vm.src != null && runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(vm.src!!))?.canRead() == true }.getOrDefault(false)))
                                    l.add(R.string.dp_a_safe to (vm.safe != null && runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(vm.safe!!))?.canWrite() == true }.getOrDefault(false)))
                                    l.add(R.string.dp_a_notif to Notifier.can(ctx))
                                    l.add(R.string.dp_a_battery to runCatching { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(false))
                                    l
                                }
                            }
                        }
                    }
                    tests.forEach { t ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                            Text(stringResource(t.first), Modifier.weight(1f))
                            Text(stringResource(if (t.second) R.string.v_yes else R.string.v_no), color = if (t.second) Green else Amber, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

private fun java.io.InputStream.readNBytesCompat(n: Int): ByteArray {
    val out = java.io.ByteArrayOutputStream()
    val buf = ByteArray(8192)
    var left = n
    while (left > 0) {
        val r = read(buf, 0, minOf(buf.size, left))
        if (r < 0) break
        out.write(buf, 0, r)
        left -= r
    }
    return out.toByteArray()
}
