package app.minesaver

import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.zip.ZipFile
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Chunked AES-256-GCM file encryption (password based). Each 1 MB chunk is authenticated. */
object Crypto {
    private val MAGIC = byteArrayOf(0x4D, 0x53, 0x45, 0x31)
    private const val CHUNK = 1 shl 20

    private fun key(pw: CharArray, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pw, salt, 120_000, 256)).encoded, "AES")
    }

    private fun nonce(base: ByteArray, c: Int): ByteArray {
        val n = ByteArray(12)
        System.arraycopy(base, 0, n, 0, 8)
        n[8] = (c shr 24).toByte(); n[9] = (c shr 16).toByte(); n[10] = (c shr 8).toByte(); n[11] = c.toByte()
        return n
    }

    private fun readFull(i: InputStream, b: ByteArray): Int {
        var o = 0
        while (o < b.size) {
            val r = i.read(b, o, b.size - o)
            if (r < 0) break
            o += r
        }
        return o
    }

    fun isEncrypted(f: File): Boolean = try {
        f.inputStream().use { val b = ByteArray(4); it.read(b) == 4 && b.contentEquals(MAGIC) }
    } catch (e: Exception) { false }

    fun encrypt(src: File, out: OutputStream, pw: CharArray) {
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val base = ByteArray(8).also { rnd.nextBytes(it) }
        val k = key(pw, salt)
        val o = DataOutputStream(out)
        o.write(MAGIC); o.write(salt); o.write(base)
        src.inputStream().use { i ->
            val buf = ByteArray(CHUNK)
            var counter = 0
            while (true) {
                val n = readFull(i, buf)
                if (n <= 0) break
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.ENCRYPT_MODE, k, GCMParameterSpec(128, nonce(base, counter++)))
                val enc = c.doFinal(buf, 0, n)
                o.writeInt(enc.size)
                o.write(enc)
            }
        }
        o.writeInt(0)
        o.flush()
    }

    fun decrypt(src: File, dst: File, pw: CharArray) {
        DataInputStream(BufferedInputStream(src.inputStream())).use { i ->
            val m = ByteArray(4)
            i.readFully(m)
            if (!m.contentEquals(MAGIC)) throw IOException("Not a MineSaver encrypted file")
            val salt = ByteArray(16); i.readFully(salt)
            val base = ByteArray(8); i.readFully(base)
            val k = key(pw, salt)
            dst.outputStream().use { o ->
                var counter = 0
                while (true) {
                    val len = try { i.readInt() } catch (e: EOFException) { throw IOException("Encrypted file is incomplete") }
                    if (len == 0) break
                    if (len < 16 || len > CHUNK + 64) throw IOException("Corrupted encrypted file")
                    val enc = ByteArray(len)
                    i.readFully(enc)
                    val c = Cipher.getInstance("AES/GCM/NoPadding")
                    c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, nonce(base, counter++)))
                    val plain = try { c.doFinal(enc) } catch (e: Exception) { throw IOException("Wrong password or corrupted file") }
                    o.write(plain)
                }
            }
        }
    }
}

/**
 * Bedrock slime chunks, using the community-documented (reverse-engineered) algorithm:
 * MT19937 seeded with (chunkX * 0x1F1F1F1F) xor chunkZ (32-bit); the first output modulo 10 equals 0.
 * It does not depend on the world seed. Status: experimental, not verified by the author against the game.
 */
object Slime {
    private val cache = HashMap<Long, Boolean>()

    @Synchronized
    fun isSlime(cx: Int, cz: Int): Boolean {
        val key = (cx.toLong() shl 32) or (cz.toLong() and 0xFFFFFFFFL)
        val hit = cache[key]
        if (hit != null) return hit
        val seed = (((cx.toLong() and 0xFFFFFFFFL) * 0x1f1f1f1fL) xor (cz.toLong() and 0xFFFFFFFFL)) and 0xFFFFFFFFL
        val mt = LongArray(398)
        mt[0] = seed
        for (i in 1 until 398) mt[i] = (1812433253L * (mt[i - 1] xor (mt[i - 1] shr 30)) + i) and 0xFFFFFFFFL
        val y = (mt[0] and 0x80000000L) or (mt[1] and 0x7fffffffL)
        var v = mt[397] xor (y shr 1)
        if ((y and 1L) != 0L) v = v xor 0x9908b0dfL
        v = v xor (v shr 11)
        v = v xor ((v shl 7) and 0x9d2c5680L)
        v = v xor ((v shl 15) and 0xefc60000L)
        v = v xor (v shr 18)
        val res = (v and 0xFFFFFFFFL) % 10L == 0L
        if (cache.size > 200_000) cache.clear()
        cache[key] = res
        return res
    }

    /** Nearest slime chunks around a chunk coordinate (square search). */
    fun nearest(cx: Int, cz: Int, radius: Int, max: Int): List<Triple<Int, Int, Double>> {
        val out = ArrayList<Triple<Int, Int, Double>>()
        for (dx in -radius..radius) for (dz in -radius..radius) {
            if (isSlime(cx + dx, cz + dz)) out.add(Triple(cx + dx, cz + dz, Math.hypot(dx.toDouble(), dz.toDouble())))
        }
        return out.sortedBy { it.third }.take(max)
    }
}

class FileDiff(val added: List<String>, val removed: List<String>, val changed: List<String>, val same: Int)

/** older -> newer comparison by entry name, size and CRC. */
fun compareZips(older: File, newer: File): FileDiff {
    fun load(f: File): Map<String, Pair<Long, Long>> = ZipFile(f).use { z ->
        z.entries().asSequence().filter { !it.isDirectory }.associate { it.name to (it.crc to it.size) }
    }
    val a = load(older)
    val b = load(newer)
    val added = b.keys.filter { it !in a }.sorted()
    val removed = a.keys.filter { it !in b }.sorted()
    val changed = b.keys.filter { a[it] != null && a[it] != b[it] }.sorted()
    return FileDiff(added, removed, changed, b.keys.count { a[it] != null && a[it] == b[it] })
}

fun safeEntryName(n: String): String? {
    val c = n.replace('\\', '/')
    if (c.startsWith("/") || c.split('/').any { it == ".." }) return null
    return c
}

/** (string resource, points, satisfied) */
fun readinessParts(vm: MainVm, r: WorldRow): List<Triple<Int, Int, Boolean>> {
    val l = r.last
    return listOf(
        Triple(R.string.rd_has, 30, r.backups.isNotEmpty()),
        Triple(R.string.rd_recent, 20, l != null && System.currentTimeMillis() - l < 7L * 24 * 3600 * 1000),
        Triple(R.string.rd_two, 15, r.backups.size >= 2),
        Triple(R.string.rd_copy, 20, vm.dl || vm.safe != null),
        Triple(R.string.rd_verified, 15, r.backups.isNotEmpty() && r.backups.first().id !in vm.bad)
    )
}

fun readinessScore(vm: MainVm, r: WorldRow): Int = readinessParts(vm, r).filter { it.third }.sumOf { it.second }

/** Linear estimate of the total backup size in [days] days; null when there is not enough history. */
fun forecastBytes(backups: List<Backup>, days: Int): Long? {
    if (backups.size < 3) return null
    val s = backups.sortedBy { it.time }
    val t0 = s.first().time
    val t1 = s.last().time
    if (t1 - t0 < 24L * 3600 * 1000) return null
    var run = 0L
    var firstCum = 0L
    s.forEachIndexed { i, b -> run += b.size; if (i == 0) firstCum = run }
    val slope = (run - firstCum).toDouble() / (t1 - t0)
    return run + (slope * days * 24.0 * 3600 * 1000).toLong()
}

/** Removes a BOM, comments and trailing commas. Returns the cleaned text and the string resources describing each change. */
fun cleanJson(src: String): Pair<String, List<Int>> {
    val changes = ArrayList<Int>()
    var s = src
    if (s.startsWith("\uFEFF")) { s = s.substring(1); changes.add(R.string.rj_bom) }
    val sb = StringBuilder()
    var i = 0
    var inStr = false
    var esc = false
    var removedComment = false
    while (i < s.length) {
        val c = s[i]
        if (inStr) {
            sb.append(c)
            if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false
            i++
            continue
        }
        if (c == '"') { inStr = true; sb.append(c); i++; continue }
        if (c == '/' && i + 1 < s.length && s[i + 1] == '/') {
            while (i < s.length && s[i] != '\n') i++
            removedComment = true
            continue
        }
        if (c == '/' && i + 1 < s.length && s[i + 1] == '*') {
            i += 2
            while (i + 1 < s.length && !(s[i] == '*' && s[i + 1] == '/')) i++
            i += 2
            removedComment = true
            continue
        }
        sb.append(c)
        i++
    }
    if (removedComment) changes.add(R.string.rj_comments)
    val t = sb.toString()
    val out = StringBuilder()
    inStr = false; esc = false
    var trailing = false
    i = 0
    while (i < t.length) {
        val c = t[i]
        if (inStr) {
            out.append(c)
            if (esc) esc = false else if (c == '\\') esc = true else if (c == '"') inStr = false
            i++
            continue
        }
        if (c == '"') { inStr = true; out.append(c); i++; continue }
        if (c == ',') {
            var j = i + 1
            while (j < t.length && t[j].isWhitespace()) j++
            if (j < t.length && (t[j] == '}' || t[j] == ']')) { trailing = true; i++; continue }
        }
        out.append(c)
        i++
    }
    if (trailing) changes.add(R.string.rj_commas)
    return out.toString() to changes
}

fun hashFile(f: File, algo: String): String {
    val md = MessageDigest.getInstance(algo)
    f.inputStream().use { i ->
        val b = ByteArray(65536)
        while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) }
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

fun hexDump(b: ByteArray, base: Long): String {
    val sb = StringBuilder()
    var i = 0
    while (i < b.size) {
        sb.append("%08x  ".format(base + i))
        val end = minOf(i + 16, b.size)
        for (k in i until i + 16) sb.append(if (k < end) "%02x ".format(b[k]) else "   ")
        sb.append(" ")
        for (k in i until end) { val c = b[k].toInt() and 255; sb.append(if (c in 32..126) c.toChar() else '.') }
        sb.append('\n')
        i += 16
    }
    return sb.toString()
}

fun signatureRes(b: ByteArray): Int {
    fun at(vararg v: Int) = b.size >= v.size && v.indices.all { (b[it].toInt() and 255) == v[it] }
    return when {
        at(0x50, 0x4B, 0x03, 0x04) -> R.string.sig_zip
        at(0x89, 0x50, 0x4E, 0x47) -> R.string.sig_png
        at(0xFF, 0xD8, 0xFF) -> R.string.sig_jpeg
        at(0x1F, 0x8B) -> R.string.sig_gzip
        at(0x7B) || at(0x5B) -> R.string.sig_json
        else -> R.string.sig_unknown
    }
}
