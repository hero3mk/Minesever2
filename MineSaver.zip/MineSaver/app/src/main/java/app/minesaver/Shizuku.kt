package app.minesaver

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.lang.reflect.InvocationTargetException
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Reads/writes Minecraft's private world folder through Shizuku (shell uid) using tar streams. */
object Sz {
    const val PKG = "moe.shizuku.privileged.api"
    const val WORLDS = "/storage/emulated/0/Android/data/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds"

    fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun ready(): Boolean = try { running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun request() { try { Shizuku.requestPermission(1001) } catch (e: Throwable) { } }

    private fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun spawn(script: String): Process {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            return m.invoke(null, arrayOf("sh", "-c", script), null, null) as Process
        } catch (e: InvocationTargetException) {
            throw IOException(e.cause?.message ?: "Shizuku error")
        } catch (e: IOException) {
            throw e
        } catch (e: Exception) {
            throw IOException(e.message ?: "Shizuku error")
        }
    }

    private fun out(script: String): ByteArray {
        val p = spawn("$script 2>/dev/null")
        val b = p.inputStream.readBytes()
        p.waitFor()
        return b
    }

    private fun yes(script: String) = String(out("$script && echo y")).trim() == "y"

    private fun outAll(script: String): ByteArray {
        val p = spawn("$script 2>&1")
        val b = p.inputStream.readBytes()
        p.waitFor()
        return b
    }

    // '@' stands for '$' so Kotlin does not treat it as a template
    private val findScript = """for u in /storage/emulated/*; do for p in "@u"/Android/data/*; do case "@p" in *mojang*|*minecraft*) d="@p/files/games/com.mojang/minecraftWorlds"; [ -d "@d" ] && echo "@d";; esac; done; done; for d in /storage/emulated/*/games/com.mojang/minecraftWorlds /data/user/*/com.mojang.minecraftpe/files/games/com.mojang/minecraftWorlds; do [ -d "@d" ] && echo "@d"; done""".replace('@', '$')

    fun worldDirs(): List<String> {
        val found = String(out(findScript)).lines().map { it.trim() }.filter { it.isNotEmpty() }
        return (found + WORLDS).distinct()
    }

    fun listWorlds(): List<LiveWorld> {
        val res = ArrayList<LiveWorld>()
        for (base in worldDirs()) {
            val names = String(out("ls -1 ${q(base)}")).lines().map { it.trim() }.filter { it.isNotEmpty() }
            for (n in names) {
                val dir = "$base/$n"
                val lvl = out("cat ${q("$dir/level.dat")}")
                if (lvl.isEmpty()) continue
                val nm = String(out("cat ${q("$dir/levelname.txt")}")).trim().ifEmpty { n }
                val mt = String(out("stat -c %Y ${q("$dir/level.dat")}")).trim().toLongOrNull() ?: 0L
                val sz = String(out("du -sk ${q(dir)}")).trim().split(Regex("\\s+")).firstOrNull()?.toLongOrNull()?.times(1024) ?: 0L
                res.add(LiveWorld(n, nm, gameMode(lvl), mt * 1000, null, dir, sz))
            }
        }
        return res.distinctBy { it.id }
    }

    fun diagnose(): String {
        val sb = StringBuilder()
        fun run(label: String, cmd: String) {
            sb.append("$ ").append(label).append('\n')
            sb.append(String(outAll(cmd)).trim().ifEmpty { "(empty)" }).append("\n\n")
        }
        try {
            run("id", "id")
            run("Android/data", "ls -ld /storage/emulated/0/Android/data; ls /storage/emulated/0/Android/data | grep -i -E 'mojang|minecraft'")
            run("default worlds folder", "ls -la ${q(WORLDS)}")
            run("found folders", findScript)
        } catch (e: Exception) {
            sb.append("ERROR: ").append(e.message)
        }
        return sb.toString()
    }

    // ---------- tar -> zip (backup) ----------
    fun tarToZip(dir: String, z: ZipOutputStream): Pair<Int, Boolean> {
        val p = spawn("tar -cf - -C ${q(dir)} . 2>/dev/null")
        var n = 0
        var level = false
        try {
            p.inputStream.buffered().use { ins ->
                readTar(ins) { name, size ->
                    z.putNextEntry(ZipEntry(name))
                    copyN(ins, z, size)
                    z.closeEntry()
                    n++
                    if (name == "level.dat") level = true
                }
            }
            p.waitFor()
        } finally {
            p.destroy()
        }
        if (n == 0) throw IOException("Could not read the world through Shizuku")
        return n to level
    }

    private fun readFully(i: InputStream, b: ByteArray, len: Int): Boolean {
        var o = 0
        while (o < len) {
            val r = i.read(b, o, len - o)
            if (r < 0) return false
            o += r
        }
        return true
    }

    private fun skipN(i: InputStream, n: Long) {
        var left = n
        val b = ByteArray(8192)
        while (left > 0) {
            val r = i.read(b, 0, minOf(left, 8192L).toInt())
            if (r < 0) throw IOException("Unexpected end of data")
            left -= r
        }
    }

    private fun copyN(i: InputStream, o: OutputStream, n: Long) {
        var left = n
        val b = ByteArray(65536)
        while (left > 0) {
            val r = i.read(b, 0, minOf(left, 65536L).toInt())
            if (r < 0) throw IOException("Unexpected end of data")
            o.write(b, 0, r)
            left -= r
        }
    }

    private fun cstr(h: ByteArray, off: Int, len: Int): String {
        var e = off
        while (e < off + len && h[e].toInt() != 0) e++
        return String(h, off, e - off, Charsets.UTF_8)
    }

    /** Calls onFile(name, size) for each regular file; the callback must consume exactly `size` bytes from [ins]. */
    private fun readTar(ins: InputStream, onFile: (String, Long) -> Unit) {
        val h = ByteArray(512)
        var longName: String? = null
        while (readFully(ins, h, 512)) {
            if (h[0].toInt() == 0) break
            var name = cstr(h, 0, 100)
            val size = cstr(h, 124, 12).trim().ifEmpty { "0" }.toLong(8)
            val type = h[156].toInt().toChar()
            val pad = (512 - size % 512) % 512
            if (type == 'L') {
                val b = ByteArray(size.toInt())
                readFully(ins, b, b.size)
                skipN(ins, pad)
                longName = String(b, Charsets.UTF_8).trimEnd('\u0000')
                continue
            }
            val pre = if (cstr(h, 257, 5) == "ustar") cstr(h, 345, 155) else ""
            if (pre.isNotEmpty()) name = "$pre/$name"
            val ln = longName
            if (ln != null) { name = ln; longName = null }
            name = name.removePrefix("./")
            if ((type == '0' || type == '\u0000') && name.isNotEmpty()) onFile(name, size) else skipN(ins, size)
            skipN(ins, pad)
        }
    }

    // ---------- zip -> tar (restore) ----------
    private fun tarHeader(full: String, size: Long): ByteArray {
        var nm = full
        var pre = ""
        if (nm.toByteArray().size > 100) {
            val i = nm.lastIndexOf('/')
            if (i <= 0 || nm.length - i - 1 > 100 || i > 155) throw IOException("Path too long: $full")
            pre = nm.substring(0, i)
            nm = nm.substring(i + 1)
        }
        val h = ByteArray(512)
        fun put(off: Int, s: String) { s.toByteArray().copyInto(h, off) }
        put(0, nm)
        put(100, "0000644\u0000")
        put(108, "0000000\u0000")
        put(116, "0000000\u0000")
        put(124, String.format(Locale.US, "%011o\u0000", size))
        put(136, String.format(Locale.US, "%011o\u0000", System.currentTimeMillis() / 1000))
        for (j in 148 until 156) h[j] = 32
        h[156] = '0'.code.toByte()
        put(257, "ustar\u0000")
        put(263, "00")
        put(345, pre)
        val sum = h.sumOf { it.toInt() and 255 }
        put(148, String.format(Locale.US, "%06o\u0000 ", sum))
        return h
    }

    /** Extracts [zip] into a NEW folder inside Minecraft's worlds folder. Returns the folder name. */
    fun restore(zip: File, base: String): String {
        val root = worldDirs().first()
        var name = base
        var k = 1
        while (yes("test -e ${q("$root/$name")}")) name = "${base}_restored_${k++}"
        val dest = "$root/$name"
        out("mkdir -p ${q(dest)}")
        val p = spawn("tar -xf - -C ${q(dest)} 2>/dev/null")
        var total = 0
        try {
            p.outputStream.buffered().use { o ->
                ZipFile(zip).use { z ->
                    for (e in z.entries().asSequence().filter { !it.isDirectory }) {
                        o.write(tarHeader(e.name, e.size))
                        z.getInputStream(e).use { it.copyTo(o) }
                        val pad = ((512 - e.size % 512) % 512).toInt()
                        if (pad > 0) o.write(ByteArray(pad))
                        total++
                    }
                }
                o.write(ByteArray(1024))
            }
            p.waitFor()
        } finally {
            p.destroy()
        }
        val count = String(out("find ${q(dest)} -type f | wc -l")).trim().toIntOrNull() ?: -1
        if (count != total || !yes("test -f ${q("$dest/level.dat")}")) {
            out("rm -rf ${q(dest)}")
            throw IOException("Restore through Shizuku was incomplete")
        }
        return name
    }
}
