package app.minesaver

import android.content.Context
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter

class AssistAnswer(val text: String, val source: String)
class Rec(val text: String, val route: String?)

/** A local, rule-based assistant. It only answers from data the app really has, and always names the source. */
object Assistant {
    private fun norm(s: String): String =
        s.lowercase().replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')
            .replace(Regex("[\\u064B-\\u065F]"), "")

    private fun has(q: String, vararg w: String) = w.any { q.contains(norm(it)) }

    fun freeBytes(): Long =
        runCatching { StatFs(Environment.getExternalStorageDirectory().path).availableBytes }.getOrDefault(0L)

    fun totalBytes(): Long =
        runCatching { StatFs(Environment.getExternalStorageDirectory().path).totalBytes }.getOrDefault(0L)

    fun answer(ctx: Context, raw: String, vm: MainVm): AssistAnswer {
        val q = norm(raw)
        val rows = vm.rows
        val srcWorlds = ctx.getString(R.string.as_src_worlds)
        val srcBackups = ctx.getString(R.string.as_src_backups)
        val srcAddons = ctx.getString(R.string.as_src_addons)
        val srcStorage = ctx.getString(R.string.as_src_storage)
        fun size(r: WorldRow): Long { val l = r.live?.size ?: 0L; return if (l > 0) l else r.size }
        fun fmt(n: Long) = Formatter.formatShortFileSize(ctx, n)

        // size filter, e.g. "worlds bigger than 500 MB"
        val m = Regex("(\\d+(?:[.,]\\d+)?)\\s*(gb|جيجا|mb|ميجا|ميغا)").find(q)
        val bigger = has(q, "اكبر", "اكثر", "larger", "bigger", "more than", "over", "above")
        val smaller = has(q, "اصغر", "اقل", "smaller", "less than", "under", "below")
        if (m != null && (bigger || smaller) && !has(q, "نسخه", "backup")) {
            val v = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 0.0
            val unit = if (m.groupValues[2] == "gb" || m.groupValues[2] == "جيجا") 1024.0 * 1024 * 1024 else 1024.0 * 1024
            val limit = (v * unit).toLong()
            val list = rows.filter { if (bigger) size(it) > limit else size(it) < limit }.sortedByDescending { size(it) }
            return if (list.isEmpty()) AssistAnswer(ctx.getString(R.string.as_none), srcWorlds)
            else AssistAnswer(ctx.getString(R.string.as_size_list, list.size) + "\n" + list.joinToString("\n") { "• " + it.name + " — " + fmt(size(it)) }, srcWorlds)
        }
        if (has(q, "اكبر نسخه", "largest backup", "biggest backup") || (has(q, "اكبر", "largest", "biggest") && has(q, "نسخ", "backup"))) {
            val b = vm.backups.maxByOrNull { it.size }
                ?: return AssistAnswer(ctx.getString(R.string.as_none), srcBackups)
            return AssistAnswer(ctx.getString(R.string.as_biggest, b.worldName, fmt(b.size)), srcBackups)
        }
        if (has(q, "بدون نسخ", "من غير نسخ", "without backup", "not backed up", "no backup", "غير محمي", "unprotected")) {
            val list = rows.filter { it.last == null }
            return if (list.isEmpty()) AssistAnswer(ctx.getString(R.string.as_all_have), srcWorlds)
            else AssistAnswer(ctx.getString(R.string.as_nobackup, list.size) + "\n" + list.joinToString("\n") { "• " + it.name }, srcWorlds)
        }
        if (has(q, "تغير", "changed", "modified")) {
            val list = rows.filter { it.changed }
            return if (list.isEmpty()) AssistAnswer(ctx.getString(R.string.as_none_changed), srcWorlds)
            else AssistAnswer(ctx.getString(R.string.as_changed, list.size) + "\n" + list.joinToString("\n") { "• " + it.name }, srcWorlds)
        }
        if (has(q, "اخر نسخ", "last backup", "latest backup", "اخر تغيير", "last change")) {
            val w = rows.firstOrNull { q.contains(norm(it.name)) }
            val t = if (w != null) w.last else vm.backups.maxOfOrNull { it.time }
            if (t == null) return AssistAnswer(ctx.getString(R.string.as_none), srcBackups)
            val d = java.text.DateFormat.getDateTimeInstance().format(java.util.Date(t))
            return AssistAnswer(ctx.getString(R.string.as_last, w?.name ?: ctx.getString(R.string.as_all_worlds), d), srcBackups)
        }
        if (has(q, "اضاف", "addon", "add-on", "pack", "حزم")) {
            if (has(q, "تحديث", "update")) return AssistAnswer(ctx.getString(R.string.as_no_updates), srcAddons)
            if (has(q, "ناقص", "missing", "dependen", "اعتماد", "تعارض", "conflict")) {
                val c = conflictsOf(vm.addons)
                return if (c.isEmpty()) AssistAnswer(ctx.getString(R.string.as_addons_ok), srcAddons)
                else AssistAnswer(ctx.getString(R.string.as_conflicts, c.size) + "\n" + c.take(10).joinToString("\n") { "• " + it.a }, srcAddons)
            }
            return AssistAnswer(ctx.getString(R.string.as_addons, vm.addons.size) + "\n" + vm.addons.take(15).joinToString("\n") { "• " + it.name + " " + it.version }, srcAddons)
        }
        if (has(q, "مساحه", "storage", "space", "free", "متاح")) {
            val total = vm.backups.sumOf { it.size }
            return AssistAnswer(ctx.getString(R.string.as_storage, fmt(total), fmt(freeBytes())), srcStorage)
        }
        if (has(q, "كم نسخ", "how many backups", "عدد النسخ", "count")) {
            return AssistAnswer(ctx.getString(R.string.as_count, vm.backups.size, rows.size), srcBackups)
        }
        if (has(q, "مشكل", "problem", "issue", "health", "صحه", "تالف", "damaged", "corrupt")) {
            val bad = vm.bad.size
            val ch = rows.count { it.changed }
            return AssistAnswer(ctx.getString(R.string.as_problems, bad, ch), srcBackups)
        }
        val w = rows.firstOrNull { q.contains(norm(it.name)) }
        if (w != null) {
            return AssistAnswer(ctx.getString(R.string.as_world, w.name, w.backups.size, fmt(size(w))), srcWorlds)
        }
        return AssistAnswer(ctx.getString(R.string.as_help), ctx.getString(R.string.as_src_none))
    }

    fun recommendations(ctx: Context, vm: MainVm): List<Rec> {
        val out = ArrayList<Rec>()
        val rows = vm.rows
        val changed = rows.filter { it.changed }
        if (changed.isNotEmpty()) out.add(Rec(ctx.getString(R.string.rc_changed, changed.size), "backup"))
        val none = rows.filter { it.live != null && it.last == null }
        if (none.isNotEmpty()) out.add(Rec(ctx.getString(R.string.rc_none, none.size), "backup"))
        val old = rows.filter { r -> val l = r.last; l != null && System.currentTimeMillis() - l > 30L * 24 * 3600 * 1000 && r.live == null }
        if (old.isNotEmpty()) out.add(Rec(ctx.getString(R.string.rc_old, old.size), "backups"))
        val free = freeBytes()
        val total = totalBytes()
        if (total > 0 && free * 100 / total < 10) out.add(Rec(ctx.getString(R.string.rc_space), "storage"))
        if (conflictsOf(vm.addons).isNotEmpty()) out.add(Rec(ctx.getString(R.string.rc_addons), "addon_check"))
        if (vm.safe == null && !vm.dl) out.add(Rec(ctx.getString(R.string.rc_safe), "settings"))
        if (!vm.pinSet) out.add(Rec(ctx.getString(R.string.rc_pin), "settings"))
        return out
    }

    /** Plain-language explanation of common errors. Returns null when there is no reliable explanation. */
    fun explain(ctx: Context, raw: String?): String? {
        val t = raw?.lowercase() ?: return null
        val id = when {
            t.contains("level.dat") -> R.string.ex_level
            t.contains("damaged") || t.contains("checksum") -> R.string.ex_damaged
            t.contains("worlds folder not found") -> R.string.ex_folder
            t.contains("read-only") || t.contains("permission") -> R.string.ex_perm
            t.contains("cannot read") -> R.string.ex_read
            t.contains("shizuku") -> R.string.ex_shizuku
            else -> return null
        }
        return ctx.getString(id)
    }
}
