package app.minesaver

import org.json.JSONArray
import java.io.File
import java.util.zip.ZipFile

class ZipStat(
    val entries: Int, val total: Long, val byExt: Map<String, Long>, val ldb: Int, val logs: Int, val dbBytes: Long,
    val hasLevel: Boolean, val hasName: Boolean, val hasCurrent: Boolean, val hasManifest: Boolean
)

class PackRef(val uuid: String, val version: String, val kind: String)

class Finding(val sev: Int, val title: Int, val detail: String, val fix: Int)

class WorldReport(val findings: List<Finding>, val stat: ZipStat?, val packs: List<PackRef>, val info: WorldInfo?, val worst: Int)

fun zipStat(f: File): ZipStat {
    ZipFile(f).use { z ->
        var n = 0; var total = 0L; var ldb = 0; var logs = 0; var dbBytes = 0L
        var level = false; var name = false; var current = false; var manifest = false
        val ext = HashMap<String, Long>()
        for (e in z.entries().asSequence()) {
            if (e.isDirectory) continue
            n++
            val sz = maxOf(e.size, 0L)
            total += sz
            val nm = e.name
            val x = nm.substringAfterLast('.', "").lowercase().ifEmpty { "other" }
            ext[x] = (ext[x] ?: 0L) + sz
            if (nm == "level.dat") level = true
            if (nm == "levelname.txt") name = true
            if (nm.contains("db/")) {
                dbBytes += sz
                if (nm.endsWith(".ldb")) ldb++
                if (nm.endsWith(".log")) logs++
                if (nm.endsWith("/CURRENT") || nm == "db/CURRENT") current = true
                if (nm.contains("MANIFEST-")) manifest = true
            }
        }
        return ZipStat(n, total, ext, ldb, logs, dbBytes, level, name, current, manifest)
    }
}

fun worldPacks(f: File): List<PackRef> {
    val out = ArrayList<PackRef>()
    ZipFile(f).use { z ->
        val files = listOf("world_behavior_packs.json" to "behavior", "world_resource_packs.json" to "resource")
        for (p in files) {
            val e = z.getEntry(p.first) ?: continue
            val b = z.getInputStream(e).use { readLimited(it, 500_000) } ?: continue
            try {
                val a = JSONArray(String(b, Charsets.UTF_8).removePrefix("\uFEFF"))
                for (i in 0 until a.length()) {
                    val o = a.optJSONObject(i) ?: continue
                    val id = o.optString("pack_id").lowercase()
                    if (id.isEmpty()) continue
                    val v = o.opt("version")
                    val vs = if (v is JSONArray) (0 until v.length()).joinToString(".") { v.optString(it) } else (v?.toString() ?: "")
                    out.add(PackRef(id, vs, p.second))
                }
            } catch (ex: Exception) {
            }
        }
    }
    return out
}

/** Read-only health check of a BACKUP of the world. The original world is never opened or changed. */
fun buildReport(repo: Repo, b: Backup, addons: List<Addon>, mc: String?): WorldReport {
    val f = repo.file(b)
    val list = ArrayList<Finding>()
    var ok = true
    try { repo.checkZip(f) } catch (e: Exception) {
        ok = false
        list.add(Finding(2, R.string.rp_bad_zip, e.message ?: "", R.string.rp_fix_other))
    }
    var stat: ZipStat? = null
    var info: WorldInfo? = null
    var packs: List<PackRef> = emptyList()
    if (ok) {
        if (sha256(f) != b.sha) list.add(Finding(2, R.string.rp_bad_sha, "", R.string.rp_fix_other))
        stat = zipStat(f)
        val lb = runCatching {
            ZipFile(f).use { z -> val e = z.getEntry("level.dat"); if (e == null) null else z.getInputStream(e).use { it.readBytes() } }
        }.getOrNull()
        info = if (lb == null) null else worldInfo(lb)
        packs = runCatching { worldPacks(f) }.getOrDefault(emptyList())
        if (!stat.hasLevel) list.add(Finding(2, R.string.rp_no_level, "", R.string.rp_fix_other))
        else if (info == null) list.add(Finding(1, R.string.rp_level_unread, "", R.string.rp_fix_none))
        if (!stat.hasName) list.add(Finding(0, R.string.rp_no_name, "", R.string.rp_fix_none))
        if (stat.ldb == 0 && stat.logs == 0) list.add(Finding(2, R.string.rp_db_empty, "", R.string.rp_fix_other))
        else if (!stat.hasCurrent || !stat.hasManifest) list.add(Finding(1, R.string.rp_db_partial, "", R.string.rp_fix_rebackup))
        if (stat.dbBytes > 500_000_000L) list.add(Finding(0, R.string.rp_db_big, "", R.string.rp_fix_none))
        val wv = verParts(info?.version)
        val mv = verParts(mc)
        if (wv != null && mv != null && verCmp(mv, wv) < 0) list.add(Finding(1, R.string.rp_newer_world, (info?.version ?: "") + " / " + (mc ?: ""), R.string.rp_fix_update_mc))
        for (p in packs) {
            val lib = addons.filter { it.uuid == p.uuid }
            if (lib.isEmpty()) list.add(Finding(0, R.string.rp_pack_unknown, p.uuid.take(8), R.string.rp_fix_import_packs))
            else {
                val missing = lib.first().deps.count { depState(it, addons) == 0 }
                if (missing > 0) list.add(Finding(1, R.string.rp_pack_dep, lib.first().name, R.string.rp_fix_import_packs))
            }
        }
    }
    if (list.isEmpty()) list.add(Finding(0, R.string.rp_ok, "", R.string.rp_fix_none))
    return WorldReport(list, stat, packs, info, list.maxOf { it.sev })
}
