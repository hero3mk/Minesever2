package app.minesaver

import androidx.annotation.StringRes
import androidx.compose.material.icons.rounded.Map
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private val TagPresets = listOf(
    "Survival" to R.string.t_survival, "Creative" to R.string.t_creative, "Hardcore" to R.string.t_hardcore,
    "Adventure" to R.string.t_adventure, "Redstone" to R.string.t_redstone, "Build" to R.string.t_build, "Server" to R.string.t_server,
    "Multiplayer" to R.string.t_multiplayer, "Archived" to R.string.t_archived
)

private val PlaceTypes = listOf(R.string.pl_home, R.string.pl_mine, R.string.pl_village, R.string.pl_portal, R.string.pl_base, R.string.pl_other)

@Composable
fun tagLabel(key: String): String {
    val p = TagPresets.find { it.first == key }
    return if (p != null) stringResource(p.second) else key
}

@Composable
fun diffName(i: Int): String = stringResource(
    when (i) { 0 -> R.string.diff_0; 1 -> R.string.diff_1; 2 -> R.string.diff_2; else -> R.string.diff_3 }
)

@Composable
fun yesNo(b: Boolean): String = stringResource(if (b) R.string.v_yes else R.string.v_no)

@Composable
fun sizeText(r: WorldRow): String {
    val d = r.live?.size ?: 0L
    return if (d > 0) fmtSize(d) else stringResource(R.string.none_dash)
}

// ---------- small building blocks ----------
@Composable
fun Tile(@StringRes label: Int, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier.clip(shape).background(look.card).border(1.dp, look.cardBorder, shape).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = .16f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.width(12.dp))
        Text(stringResource(label), style = MaterialTheme.typography.titleMedium, maxLines = 2)
    }
}

@Composable
fun TagChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme.primary
    Text(
        text,
        color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
        style = MaterialTheme.typography.labelLarge,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (selected) c else c.copy(alpha = .10f))
            .border(1.dp, c.copy(alpha = .35f), RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

@Composable
fun FaqItem(@StringRes q: Int, @StringRes a: Int) {
    var open by remember { mutableStateOf(false) }
    Glass(Modifier.clickable { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(q), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, null)
        }
        AnimatedVisibility(open) {
            Text(
                stringResource(a), color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 10.dp)
            )
        }
    }
}

@Composable
fun WorldMini(vm: MainVm, r: WorldRow, onClick: () -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(20.dp)
    val st = statusOf(r)
    Column(
        Modifier.width(170.dp).clip(shape).background(look.card).border(1.dp, look.cardBorder, shape)
            .clickable(onClick = onClick).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        WorldIcon(vm, r.id, r.last, 52.dp)
        Text(r.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Badge(st.first, st.second)
        Text(
            fmtSize(r.live?.size?.takeIf { it > 0 } ?: r.size),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
fun LookSwatch(l: Look, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier.width(104.dp).clip(shape).background(Brush.verticalGradient(l.bg))
            .border(if (selected) 2.dp else 1.dp, if (selected) l.accent else l.cardBorder, shape)
            .clickable(onClick = onClick).padding(10.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            Box(Modifier.size(14.dp).clip(CircleShape).background(l.accent))
            Box(Modifier.size(14.dp).clip(CircleShape).background(l.accent2))
            Box(Modifier.size(14.dp).clip(CircleShape).background(l.card).border(1.dp, l.cardBorder, CircleShape))
        }
        Spacer(Modifier.height(8.dp))
        Text(stringResource(l.nameRes), color = l.text, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun CompareRow(@StringRes label: Int, a: String, b: String) {
    Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.Top) {
        Text(stringResource(label), Modifier.weight(1.1f), color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
        Text(a, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
        Text(b, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
    }
}

// ---------- welcome ----------
@Composable
fun WelcomeDialog(vm: MainVm, nav: NavController) {
    AlertDialog(
        onDismissRequest = { vm.closeWelcome() },
        title = { Text(stringResource(R.string.welcome_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(stringResource(R.string.welcome_sub))
                listOf(R.string.guide_1, R.string.guide_2, R.string.guide_3, R.string.guide_4).forEach {
                    Text(stringResource(it), style = MaterialTheme.typography.bodyMedium)
                }
            }
        },
        confirmButton = { TextButton({ vm.closeWelcome() }) { Text(stringResource(R.string.a_start)) } },
        dismissButton = { TextButton({ vm.closeWelcome(); nav.navigate("help") }) { Text(stringResource(R.string.title_help)) } }
    )
}

// ---------- help center ----------
@Composable
fun HelpScreen(vm: MainVm, nav: NavController) {
    val faqs = listOf(
        R.string.faq_q1 to R.string.faq_a1, R.string.faq_q2 to R.string.faq_a2, R.string.faq_q3 to R.string.faq_a3,
        R.string.faq_q4 to R.string.faq_a4, R.string.faq_q5 to R.string.faq_a5, R.string.faq_q6 to R.string.faq_a6,
        R.string.faq_q7 to R.string.faq_a7, R.string.faq_q8 to R.string.faq_a8, R.string.faq_q9 to R.string.faq_a9,
        R.string.faq_q10 to R.string.faq_a10, R.string.faq_q11 to R.string.faq_a11, R.string.faq_q12 to R.string.faq_a12,
        R.string.faq_q13 to R.string.faq_a13, R.string.faq_q14 to R.string.faq_a14, R.string.faq_q15 to R.string.faq_a15
    )
    Page(R.string.title_help, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.help_intro), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(faqs) { i, f -> Appear(i) { FaqItem(f.first, f.second) } }
        item { Acts { Act(R.string.a_welcome, Icons.Rounded.Info) { vm.showWelcome() } } }
    }
}

// ---------- world details ----------
@Composable
fun WorldDetailScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    val export = rememberExporter(vm)
    val id = vm.detailId
    val r = vm.rows.find { it.id == id }
    LaunchedEffect(id, vm.live.size, vm.backups.size, vm.infos.size) { if (id != null) vm.ensureInfo(listOf(id)) }
    if (r == null) {
        Page(R.string.title_world, onBack = { nav.popBackStack() }) { item { Glass { Text(stringResource(R.string.world_gone)) } } }
        return
    }
    val info = vm.infos[r.id]
    val dash = stringResource(R.string.none_dash)
    var newTag by remember(r.id) { mutableStateOf("") }
    var note by remember(r.id) { mutableStateOf(vm.noteOf(r.id)) }
    val tags = vm.tagsOf(r.id)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    PageBase(r.name, { nav.popBackStack() }) {
        item {
            Appear(0) {
                Glass {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        WorldIcon(vm, r.id, r.last, 72.dp)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            val st = statusOf(r)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Badge(modeName(r.mode), MaterialTheme.colorScheme.secondary)
                                Badge(st.first, st.second)
                            }
                            Text(
                                stringResource(R.string.last_backup, r.last?.let { fmtDate(it) } ?: stringResource(R.string.never)),
                                style = MaterialTheme.typography.bodySmall, color = dim
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Acts {
                        r.live?.let { w -> Act(R.string.a_backup, Icons.Rounded.CloudUpload) { vm.backupNow(w) } }
                        if (r.backups.isNotEmpty()) {
                            Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = r.backups.first().id; nav.navigate("restore") }
                            Act(R.string.a_export, Icons.Rounded.FileUpload) { export(r.backups.first()) }
                        }
                    }
                }
            }
        }
        item {
            Appear(0) {
                Acts {
                    Act(R.string.a_dna, Icons.Rounded.Info) { nav.navigate("dna") }
                    Act(R.string.atlas_open_world, Icons.Rounded.Map) { vm.atlasWorld = r.id; nav.navigate("atlas") }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    SectionTitle(stringResource(R.string.wd_analyzer), Icons.Rounded.Info)
                    Spacer(Modifier.height(10.dp))
                    if (info == null) {
                        Text(stringResource(R.string.wd_loading), color = dim)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            DetailRow(R.string.d_mode, modeName(info.gameType ?: r.mode))
                            DetailRow(R.string.r_difficulty, info.difficulty?.let { diffName(it) } ?: dash)
                            DetailRow(R.string.r_hardcore, info.hardcore?.let { yesNo(it) } ?: dash)
                            DetailRow(R.string.r_type, info.generator?.let { stringResource(if (it == 2) R.string.gen_2 else R.string.gen_1) } ?: dash)
                            DetailRow(R.string.r_spawn, info.spawn ?: dash)
                            DetailRow(R.string.r_version, info.version ?: dash)
                            DetailRow(R.string.r_cheats, info.cheats?.let { yesNo(it) } ?: dash)
                            DetailRow(R.string.r_seed, info.seed?.toString() ?: dash)
                        }
                        val seedTxt = info.seed?.toString()
                        if (seedTxt != null) {
                            Spacer(Modifier.height(10.dp))
                            Acts {
                                Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(seedTxt)); vm.toast = Msg(R.string.copied, seedTxt) }
                                Act(R.string.a_save_seed, Icons.Rounded.Add) { vm.addSeed(r.name, seedTxt, ""); vm.toast = Msg(R.string.msg_seed_saved) }
                            }
                        }
                    }
                }
            }
        }
        item {
            Appear(2) {
                Glass {
                    SectionTitle(stringResource(R.string.wd_stats), Icons.Rounded.History)
                    Spacer(Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DetailRow(R.string.r_days, info?.ticks?.let { (it / 24000L).toString() } ?: dash)
                        DetailRow(R.string.r_hours, info?.ticks?.let { stringResource(R.string.hours_fmt, (it / 72000L).toInt()) } ?: dash)
                        DetailRow(R.string.r_played, info?.lastPlayed?.takeIf { it > 0 }?.let { fmtDate(it) } ?: dash)
                        DetailRow(R.string.d_size, sizeText(r))
                        DetailRow(R.string.r_backups, r.backups.size.toString())
                        DetailRow(R.string.r_backups_size, fmtSize(r.size))
                        DetailRow(R.string.r_sessions, (vm.sessions[r.id] ?: 0).toString())
                    }
                }
            }
        }
        item {
            Appear(3) {
                Glass {
                    SectionTitle(stringResource(R.string.wd_tags), Icons.Rounded.Star)
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        TagPresets.forEach { p -> TagChip(tagLabel(p.first), p.first in tags) { vm.toggleTag(r.id, p.first) } }
                        tags.filter { t -> TagPresets.none { it.first == t } }.forEach { t -> TagChip(t, true) { vm.toggleTag(r.id, t) } }
                    }
                    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(newTag, { newTag = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.wd_tag_add)) })
                        IconButton(onClick = {
                            val t = newTag.trim()
                            if (t.isNotEmpty()) { vm.toggleTag(r.id, t); newTag = "" }
                        }) { Icon(Icons.Rounded.Add, null) }
                    }
                }
            }
        }
        item {
            Appear(4) {
                Glass {
                    SectionTitle(stringResource(R.string.wd_notes), Icons.Rounded.Info)
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        note, { note = it; vm.setNote(r.id, it) }, Modifier.fillMaxWidth(), minLines = 3,
                        placeholder = { Text(stringResource(R.string.wd_notes_hint)) }
                    )
                }
            }
        }
        item { SectionTitle(stringResource(R.string.wd_timeline), Icons.Rounded.History) }
        if (r.backups.isEmpty()) item { Text(stringResource(R.string.backups_empty), color = dim) }
        itemsIndexed(r.backups) { i, b ->
            Appear(i) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(Modifier.width(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                        if (i < r.backups.lastIndex) Box(Modifier.width(2.dp).height(70.dp).background(MaterialTheme.colorScheme.primary.copy(alpha = .35f)))
                    }
                    Glass(Modifier.weight(1f)) {
                        Text(fmtDate(b.time), style = MaterialTheme.typography.titleMedium)
                        Text(fmtSize(b.size) + " · SHA-256 " + b.sha.take(8), style = MaterialTheme.typography.bodySmall, color = dim)
                        Spacer(Modifier.height(8.dp))
                        Acts { Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = b.id; nav.navigate("restore") } }
                    }
                }
            }
        }
    }
}

// ---------- compare ----------
@Composable
fun CompareScreen(vm: MainVm, nav: NavController) {
    val rows = vm.rows
    val a = rows.find { it.id == vm.cmpA }
    val b = rows.find { it.id == vm.cmpB }
    LaunchedEffect(vm.cmpA, vm.cmpB, vm.backups.size, vm.live.size, vm.infos.size) { vm.ensureInfo(listOfNotNull(vm.cmpA, vm.cmpB)) }
    val dash = stringResource(R.string.none_dash)
    Page(R.string.title_compare, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                Text(stringResource(R.string.cmp_pick_a), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Acts { rows.forEach { r -> TagChip(r.name, r.id == vm.cmpA) { vm.cmpA = r.id } } }
                Spacer(Modifier.height(14.dp))
                Text(stringResource(R.string.cmp_pick_b), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Acts { rows.forEach { r -> TagChip(r.name, r.id == vm.cmpB) { vm.cmpB = r.id } } }
            }
        }
        if (a == null || b == null) {
            item { Text(stringResource(R.string.cmp_hint), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            item {
                val ia = vm.infos[a.id]
                val ib = vm.infos[b.id]
                Glass {
                    Row(Modifier.fillMaxWidth()) {
                        Spacer(Modifier.weight(1.1f))
                        Text(a.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(b.name, Modifier.weight(1f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    CompareRow(R.string.d_mode, modeName(ia?.gameType ?: a.mode), modeName(ib?.gameType ?: b.mode))
                    CompareRow(R.string.r_difficulty, ia?.difficulty?.let { diffName(it) } ?: dash, ib?.difficulty?.let { diffName(it) } ?: dash)
                    CompareRow(R.string.d_size, sizeText(a), sizeText(b))
                    CompareRow(R.string.r_days, ia?.ticks?.let { (it / 24000L).toString() } ?: dash, ib?.ticks?.let { (it / 24000L).toString() } ?: dash)
                    CompareRow(
                        R.string.r_played,
                        ia?.lastPlayed?.takeIf { it > 0 }?.let { fmtDate(it) } ?: dash,
                        ib?.lastPlayed?.takeIf { it > 0 }?.let { fmtDate(it) } ?: dash
                    )
                    CompareRow(R.string.r_version, ia?.version ?: dash, ib?.version ?: dash)
                    CompareRow(R.string.r_seed, ia?.seed?.toString() ?: dash, ib?.seed?.toString() ?: dash)
                    CompareRow(R.string.r_backups, a.backups.size.toString(), b.backups.size.toString())
                    CompareRow(R.string.r_backups_size, fmtSize(a.size), fmtSize(b.size))
                    CompareRow(R.string.r_sessions, (vm.sessions[a.id] ?: 0).toString(), (vm.sessions[b.id] ?: 0).toString())
                }
            }
        }
    }
}

// ---------- seed library ----------
@Composable
fun SeedsScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    var name by remember { mutableStateOf("") }
    var seed by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<String?>(null) }
    Page(R.string.title_seeds, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(seed, { seed = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_seed)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(note, { note = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_note)) })
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.sd_add, Icons.Rounded.Add) {
                        if (seed.isNotBlank()) {
                            vm.addSeed(name.ifBlank { seed }, seed.trim(), note)
                            name = ""; seed = ""; note = ""
                        }
                    }
                }
            }
        }
        if (vm.seeds.isEmpty()) item { Text(stringResource(R.string.sd_empty), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(vm.seeds, key = { _, s -> s.id }) { i, s ->
            Appear(i) {
                Glass {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(s.seed, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    if (s.note.isNotBlank()) Text(s.note, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(s.seed)); vm.toast = Msg(R.string.copied, s.seed) }
                        Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = s.id }
                    }
                }
            }
        }
    }
    del?.let { sid -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deleteSeed(sid); del = null }, { del = null }) }
}

// ---------- coordinates book ----------
@Composable
fun PlacesScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    var name by remember { mutableStateOf("") }
    var world by remember { mutableStateOf("") }
    var px by remember { mutableStateOf("") }
    var py by remember { mutableStateOf("") }
    var pz by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(0) }
    var del by remember { mutableStateOf<String?>(null) }
    Page(R.string.title_places, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(world, { world = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.pl_world)) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(px, { px = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                    OutlinedTextField(py, { py = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, keyboardOptions = numeric)
                    OutlinedTextField(pz, { pz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                }
                Spacer(Modifier.height(10.dp))
                Acts { PlaceTypes.forEachIndexed { i, res -> TagChip(stringResource(res), i == type) { type = i } } }
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.pl_add, Icons.Rounded.Add) {
                        if (name.isNotBlank() && px.isNotBlank() && pz.isNotBlank()) {
                            vm.addPlace(name.trim(), type, px.trim(), py.trim().ifEmpty { "~" }, pz.trim(), world.trim())
                            name = ""; px = ""; py = ""; pz = ""
                        }
                    }
                }
            }
        }
        if (vm.places.isEmpty()) item { Text(stringResource(R.string.pl_empty), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        itemsIndexed(vm.places, key = { _, p -> p.id }) { i, p ->
            val coords = p.x + " " + p.y + " " + p.z
            Appear(i) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(p.name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                        Badge(stringResource(PlaceTypes[p.type.coerceIn(0, PlaceTypes.lastIndex)]), MaterialTheme.colorScheme.secondary)
                    }
                    Text(coords, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    if (p.world.isNotBlank()) Text(p.world, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(coords)); vm.toast = Msg(R.string.copied, coords) }
                        Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = p.id }
                    }
                }
            }
        }
    }
    del?.let { pid -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deletePlace(pid); del = null }, { del = null }) }
}
