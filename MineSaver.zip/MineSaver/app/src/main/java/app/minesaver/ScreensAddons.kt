package app.minesaver

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.navigation.NavController
import java.io.File

fun shareFile(ctx: Context, f: File) {
    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
    val i = Intent(Intent.ACTION_SEND).setType("application/octet-stream")
        .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, null))
}

private fun kindRes(k: String) = when (k) {
    "resource" -> R.string.ad_k_resource
    "behavior" -> R.string.ad_k_behavior
    "skin" -> R.string.ad_k_skin
    "template" -> R.string.ad_k_template
    else -> R.string.ad_k_other
}

@Composable
fun depLabel(s: Int): String = stringResource(
    when (s) { 0 -> R.string.dp_missing; 1 -> R.string.dp_ok; 2 -> R.string.dp_low; else -> R.string.dp_engine }
)

@Composable
fun depColor(s: Int): Color = when (s) {
    0 -> MaterialTheme.colorScheme.error
    2 -> Amber
    1 -> Green
    else -> MaterialTheme.colorScheme.secondary
}

@Composable
fun compatLabel(c: Int): String = stringResource(
    when (c) { 1 -> R.string.ad_compat_meets; 2 -> R.string.ad_compat_below; else -> R.string.ad_compat_unknown }
)

@Composable
fun IssueRow(code: String) {
    val p = code.split("|", limit = 3)
    val sev = p.getOrNull(0)?.toIntOrNull() ?: 0
    val kind = p.getOrNull(1) ?: ""
    val arg = p.getOrNull(2) ?: ""
    val res = when (kind) {
        "path" -> R.string.sc_path
        "exec" -> R.string.sc_exec
        "dup" -> R.string.sc_dup
        "badman" -> R.string.sc_badman
        "noman" -> R.string.sc_noman
        "too_many" -> R.string.sc_too_many
        "toolarge" -> R.string.sc_toolarge
        else -> R.string.sc_other
    }
    val col = when (sev) { 2 -> MaterialTheme.colorScheme.error; 1 -> Amber; else -> Green }
    Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(top = 6.dp)) {
        Box(Modifier.padding(top = 7.dp).size(8.dp).clip(CircleShape).background(col))
        Spacer(Modifier.width(10.dp))
        Text(stringResource(res, arg), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun AddonCard(vm: MainVm, a: Addon, mc: IntArray?, onClick: () -> Unit) {
    val prim = MaterialTheme.colorScheme.primary
    val bmp = remember(a.icon) {
        vm.addonIcon(a)?.takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
    }
    Glass(Modifier.clickable(onClick = onClick)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (bmp != null) Image(bmp, null, Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
            else Box(Modifier.size(56.dp).clip(RoundedCornerShape(14.dp)).background(prim.copy(alpha = .16f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Extension, null, tint = prim)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(a.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Badge(stringResource(kindRes(a.kind)), MaterialTheme.colorScheme.secondary)
                    Badge("v" + a.version, MaterialTheme.colorScheme.tertiary)
                }
                val missing = a.deps.count { depState(it, vm.addons) == 0 }
                val c = compatOf(a, mc)
                if (missing > 0 || c == 2) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (missing > 0) Badge(stringResource(R.string.ad_missing_n, missing), MaterialTheme.colorScheme.error)
                        if (c == 2) Badge(stringResource(R.string.ad_compat_below), Amber)
                    }
                }
            }
        }
    }
}

@Composable
fun AddonsScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.importAddons(it) }
    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("all") }
    var col by remember { mutableStateOf<String?>(null) }
    val mc = remember { installedMc(ctx) }
    val mcParts = verParts(mc)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val conflicts = conflictsOf(vm.addons)
    val list = vm.addons.filter { a ->
        (kind == "all" || a.kind == kind) &&
            (query.isBlank() || a.name.contains(query, true)) &&
            (col == null || vm.acols[col]?.contains(a.id) == true)
    }
    Page(R.string.nav_addons) {
        item {
            Acts {
                Act(R.string.ad_import, Icons.Rounded.FolderOpen) { imp.launch(arrayOf("*/*")) }
                Act(R.string.ad_inspector, Icons.Rounded.VerifiedUser) { nav.navigate("addon_check") }
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.ad_intro), style = MaterialTheme.typography.bodySmall, color = dim)
                Spacer(Modifier.height(10.dp))
                DetailRow(R.string.ad_total, vm.addons.size.toString())
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.ad_conflicts, conflicts.size.toString())
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.ad_mc, mc ?: stringResource(R.string.none_dash))
            }
        }
        item {
            OutlinedTextField(
                query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text(stringResource(R.string.ad_search)) }, shape = RoundedCornerShape(16.dp)
            )
        }
        item {
            Acts {
                TagChip(stringResource(R.string.ad_k_all), kind == "all") { kind = "all" }
                listOf("resource", "behavior", "skin", "template", "other").forEach { k ->
                    TagChip(stringResource(kindRes(k)), kind == k) { kind = k }
                }
            }
        }
        if (vm.acols.isNotEmpty()) item {
            Acts {
                vm.acols.keys.forEach { c -> TagChip(c, col == c) { col = if (col == c) null else c } }
            }
        }
        if (list.isEmpty()) item { Text(stringResource(R.string.ad_empty), color = dim) }
        itemsIndexed(list, key = { _, a -> a.id + "|" + a.file }) { i, a ->
            Appear(i) { AddonCard(vm, a, mcParts) { vm.addonSel = a.id + "|" + a.file; nav.navigate("addon") } }
        }
    }
}

@Composable
fun AddonDetailScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val a = vm.addons.find { it.id + "|" + it.file == vm.addonSel }
    LaunchedEffect(vm.backups.size) { vm.ensurePacks() }
    if (a == null) {
        Page(R.string.title_addon, onBack = { nav.popBackStack() }) { item { Glass { Text(stringResource(R.string.ad_gone)) } } }
        return
    }
    val mc = remember { installedMc(ctx) }
    var del by remember { mutableStateOf(false) }
    var newCol by remember { mutableStateOf("") }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val dash = stringResource(R.string.none_dash)
    val usedBy = vm.rows.filter { r -> vm.packRefs[r.id]?.any { it.uuid == a.uuid } == true }
    PageBase(a.name, { nav.popBackStack() }) {
        item {
            Glass {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Badge(stringResource(kindRes(a.kind)), MaterialTheme.colorScheme.secondary)
                    Badge("v" + a.version, MaterialTheme.colorScheme.tertiary)
                }
                if (a.desc.isNotBlank()) Text(a.desc, style = MaterialTheme.typography.bodyMedium, color = dim, modifier = Modifier.padding(top = 10.dp))
                Spacer(Modifier.height(12.dp))
                Acts {
                    Act(R.string.a_share, Icons.Rounded.Share) { runCatching { shareFile(ctx, vm.addonFile(a)) } }
                    Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = true }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_details), Icons.Rounded.Info)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow(R.string.ad_uuid, a.uuid)
                    DetailRow(R.string.r_version, a.version)
                    DetailRow(R.string.ad_min_engine, a.minEngine.ifBlank { dash })
                    DetailRow(R.string.ad_authors, a.authors.ifBlank { dash })
                    DetailRow(R.string.d_size, fmtSize(a.size))
                    DetailRow(R.string.d_sha, a.sha.take(12))
                    DetailRow(R.string.ad_imported, fmtDate(a.time))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_deps), Icons.Rounded.Extension)
                if (a.deps.isEmpty()) Text(stringResource(R.string.ad_no_deps), color = dim, modifier = Modifier.padding(top = 8.dp))
                a.deps.forEach { d ->
                    val s = depState(d, vm.addons)
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(d.module ?: ((d.uuid ?: "").take(13)), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            if (d.version.isNotBlank()) Text("v" + d.version, style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                        Badge(depLabel(s), depColor(s))
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_compat), Icons.Rounded.VerifiedUser)
                Spacer(Modifier.height(8.dp))
                Badge(compatLabel(compatOf(a, verParts(mc))), if (compatOf(a, verParts(mc)) == 2) Amber else Green)
                Text(stringResource(R.string.ad_compat_note, mc ?: dash), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 8.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_scan), Icons.Rounded.VerifiedUser)
                if (a.issues.isEmpty()) Text(stringResource(R.string.sc_clean), modifier = Modifier.padding(top = 8.dp))
                a.issues.forEach { IssueRow(it) }
                Text(stringResource(R.string.sc_scope), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 12.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_worlds), Icons.Rounded.Info)
                if (usedBy.isEmpty()) Text(stringResource(R.string.ad_worlds_none), color = dim, modifier = Modifier.padding(top = 8.dp))
                usedBy.forEach { Text("• " + it.name, modifier = Modifier.padding(top = 6.dp)) }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_collections), Icons.Rounded.Add)
                Spacer(Modifier.height(10.dp))
                Acts { vm.acols.keys.forEach { c -> TagChip(c, vm.acols[c]?.contains(a.id) == true) { vm.toggleInCollection(c, a.id) } } }
                Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(newCol, { newCol = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.ad_new_col)) })
                    IconButton(onClick = { vm.addCollection(newCol.trim()); newCol = "" }) { Icon(Icons.Rounded.Add, null) }
                }
            }
        }
    }
    if (del) ConfirmDialog(
        stringResource(R.string.dlg_delete_addon, a.name),
        { vm.deleteAddon(a); del = false; nav.popBackStack() },
        { del = false }
    )
}

@Composable
fun AddonCheckScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val mc = remember { installedMc(ctx) }
    val mcp = verParts(mc)
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val conflicts = conflictsOf(vm.addons)
    val meets = vm.addons.count { compatOf(it, mcp) == 1 }
    val below = vm.addons.count { compatOf(it, mcp) == 2 }
    val unknown = vm.addons.size - meets - below
    Page(R.string.title_addon_check, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_conflicts), Icons.Rounded.VerifiedUser)
                if (conflicts.isEmpty()) Text(stringResource(R.string.ad_no_conflicts), modifier = Modifier.padding(top = 8.dp))
                conflicts.forEach { c ->
                    val res = when (c.kind) { 0 -> R.string.cf_dup; 1 -> R.string.cf_missing; else -> R.string.cf_low }
                    Text("• " + stringResource(res, c.a, c.b), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.ad_compat), Icons.Rounded.Info)
                Spacer(Modifier.height(8.dp))
                DetailRow(R.string.ad_mc, mc ?: stringResource(R.string.none_dash))
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.ad_compat_meets, meets.toString())
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.ad_compat_below, below.toString())
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.ad_compat_unknown, unknown.toString())
                Text(stringResource(R.string.ad_compat_note, mc ?: stringResource(R.string.none_dash)), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item { SectionTitle(stringResource(R.string.ad_map), Icons.Rounded.Extension) }
        val withDeps = vm.addons.filter { it.deps.isNotEmpty() }
        if (withDeps.isEmpty()) item { Text(stringResource(R.string.ad_map_none), color = dim) }
        itemsIndexed(withDeps) { i, a ->
            Appear(i) {
                Glass {
                    Text(a.name, style = MaterialTheme.typography.titleMedium)
                    a.deps.forEach { d ->
                        val s = depState(d, vm.addons)
                        val target = vm.addons.firstOrNull { it.uuid == d.uuid }?.name ?: d.module ?: ((d.uuid ?: "").take(8))
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("↳ " + target, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Badge(depLabel(s), depColor(s))
                        }
                    }
                }
            }
        }
    }
}
