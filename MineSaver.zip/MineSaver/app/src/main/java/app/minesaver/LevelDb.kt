package app.minesaver

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.zip.Inflater
import java.util.zip.ZipFile

fun packXZ(x: Int, z: Int): Long = (x.toLong() shl 32) or (z.toLong() and 0xFFFFFFFFL)
fun unpackX(v: Long): Int = (v shr 32).toInt()
fun unpackZ(v: Long): Int = v.toInt()

/** Chunk coordinates found in a world's database. chunks = any saved data, blocks = saved terrain (sub-chunk) data. */
class AtlasData(
    val chunks: Array<HashSet<Long>>,
    val blocks: Array<HashSet<Long>>,
    val player: DoubleArray?,
    val playerDim: Int,
    val files: Int,
    val keys: Int
) {
    private val cache = HashMap<Int, LongArray>()

    @Synchronized
    fun cells(dim: Int, step: Int, withBlocks: Boolean): LongArray {
        val k = (dim * 2 + (if (withBlocks) 1 else 0)) * 100000 + step
        val c = cache[k]
        if (c != null) return c
        val src = if (withBlocks) blocks[dim] else chunks[dim]
        val out = HashSet<Long>()
        for (v in src) out.add(packXZ(Math.floorDiv(unpackX(v), step), Math.floorDiv(unpackZ(v), step)))
        val arr = out.toLongArray()
        cache[k] = arr
        return arr
    }

    /** minX, maxX, minZ, maxZ in chunk units, or null when the dimension has no data. */
    fun bounds(dim: Int): IntArray? {
        val s = chunks[dim]
        if (s.isEmpty()) return null
        var a = Int.MAX_VALUE; var b = Int.MIN_VALUE; var c = Int.MAX_VALUE; var d = Int.MIN_VALUE
        for (v in s) {
            val x = unpackX(v); val z = unpackZ(v)
            if (x < a) a = x
            if (x > b) b = x
            if (z < c) c = z
            if (z > d) d = z
        }
        return intArrayOf(a, b, c, d)
    }
}

/** Read-only reader for Bedrock's LevelDB files (tables and write-ahead logs) found inside a backup archive. */
object Atlas {
    private val MAGIC = byteArrayOf(0x57, 0xFB.toByte(), 0x80.toByte(), 0x8B.toByte(), 0x24, 0x75, 0x47, 0xDB.toByte())
    private val PLAYER_KEY = "~local_player".toByteArray()

    private class Cur(val b: ByteArray, var p: Int) {
        fun varint(): Long {
            var r = 0L
            var s = 0
            while (true) {
                val x = b[p++].toInt() and 255
                r = r or ((x and 127).toLong() shl s)
                if (x < 128) break
                s += 7
                if (s > 63) throw IOException("bad varint")
            }
            return r
        }
    }

    private class Collector {
        val chunks = Array(3) { HashSet<Long>() }
        val blocks = Array(3) { HashSet<Long>() }
        var player: DoubleArray? = null
        var playerDim = 0
        var keys = 0

        private fun i32(k: ByteArray, o: Int): Int =
            (k[o].toInt() and 255) or ((k[o + 1].toInt() and 255) shl 8) or ((k[o + 2].toInt() and 255) shl 16) or ((k[o + 3].toInt() and 255) shl 24)

        private fun addChunk(key: ByteArray, hasDim: Boolean, withBlocks: Boolean) {
            val x = i32(key, 0)
            val z = i32(key, 4)
            val dim = if (hasDim) i32(key, 8) else 0
            if (dim !in 0..2) return
            chunks[dim].add(packXZ(x, z))
            if (withBlocks) blocks[dim].add(packXZ(x, z))
        }

        fun add(key: ByteArray, ulen: Int, blk: ByteArray, vo: Int, vl: Int) {
            keys++
            if (ulen == PLAYER_KEY.size) {
                var same = true
                for (i in 0 until ulen) if (key[i] != PLAYER_KEY[i]) { same = false; break }
                if (same) {
                    val m = Nbt.parse(blk.copyOfRange(vo, vo + vl), 0)
                    val pos = m?.get("Pos") as? List<*>
                    if (pos != null && pos.size >= 3) {
                        val x = (pos[0] as? Number)?.toDouble()
                        val y = (pos[1] as? Number)?.toDouble()
                        val z = (pos[2] as? Number)?.toDouble()
                        if (x != null && y != null && z != null) {
                            player = doubleArrayOf(x, y, z)
                            playerDim = (m?.get("DimensionId") as? Number)?.toInt() ?: 0
                        }
                    }
                    return
                }
            }
            if (ulen == 9 || ulen == 13) {
                val tag = key[ulen - 1].toInt() and 255
                if (tag == 0x2c || tag == 0x76 || tag == 0x2b || tag == 0x2d) addChunk(key, ulen == 13, false)
            } else if (ulen == 10 || ulen == 14) {
                val tag = key[ulen - 2].toInt() and 255
                if (tag == 0x2f) addChunk(key, ulen == 14, true)
            }
        }
    }

    private fun u32(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 255) or ((b[o + 1].toInt() and 255) shl 8) or ((b[o + 2].toInt() and 255) shl 16) or ((b[o + 3].toInt() and 255) shl 24)

    private fun inflate(b: ByteArray, nowrap: Boolean): ByteArray? {
        val inf = Inflater(nowrap)
        return try {
            inf.setInput(b)
            val out = ByteArrayOutputStream(b.size * 3)
            val buf = ByteArray(65536)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                out.write(buf, 0, n)
            }
            if (!inf.finished()) null else out.toByteArray()
        } catch (e: Exception) {
            null
        } finally {
            inf.end()
        }
    }

    private fun snappy(src: ByteArray): ByteArray? {
        try {
            val c = Cur(src, 0)
            val total = c.varint().toInt()
            if (total < 0 || total > 64 * 1024 * 1024) return null
            val out = ByteArray(total)
            var o = 0
            var p = c.p
            while (p < src.size && o < total) {
                val tag = src[p++].toInt() and 255
                if ((tag and 3) == 0) {
                    var len = (tag shr 2) + 1
                    if (len > 60) {
                        val nb = len - 60
                        var l = 0
                        for (i in 0 until nb) l = l or ((src[p++].toInt() and 255) shl (8 * i))
                        len = l + 1
                    }
                    System.arraycopy(src, p, out, o, len)
                    p += len
                    o += len
                } else {
                    val len: Int
                    val off: Int
                    if ((tag and 3) == 1) {
                        len = ((tag shr 2) and 7) + 4
                        off = ((tag shr 5) shl 8) or (src[p++].toInt() and 255)
                    } else if ((tag and 3) == 2) {
                        len = (tag shr 2) + 1
                        off = (src[p].toInt() and 255) or ((src[p + 1].toInt() and 255) shl 8)
                        p += 2
                    } else {
                        len = (tag shr 2) + 1
                        off = u32(src, p)
                        p += 4
                    }
                    if (off <= 0 || off > o || o + len > total) return null
                    for (i in 0 until len) { out[o] = out[o - off]; o++ }
                }
            }
            return if (o == total) out else null
        } catch (e: Exception) {
            return null
        }
    }

    private fun block(d: ByteArray, off: Int, size: Int): ByteArray? {
        if (off < 0 || size < 0 || off.toLong() + size + 5 > d.size) return null
        val type = d[off + size].toInt() and 255
        val raw = d.copyOfRange(off, off + size)
        return when (type) {
            0 -> raw
            1 -> snappy(raw)
            2 -> inflate(raw, false) ?: inflate(raw, true)
            else -> inflate(raw, true) ?: inflate(raw, false)
        }
    }

    private fun forEachEntry(blk: ByteArray, f: (ByteArray, ByteArray, Int, Int) -> Unit) {
        if (blk.size < 8) return
        val nr = u32(blk, blk.size - 4)
        if (nr < 0) return
        val end = blk.size - 4 - 4 * nr
        if (end < 0) return
        val c = Cur(blk, 0)
        var prev = ByteArray(0)
        while (c.p < end) {
            val shared = c.varint().toInt()
            val non = c.varint().toInt()
            val vlen = c.varint().toInt()
            if (shared < 0 || non < 0 || vlen < 0 || shared > prev.size || c.p.toLong() + non + vlen > end) return
            val key = ByteArray(shared + non)
            System.arraycopy(prev, 0, key, 0, shared)
            System.arraycopy(blk, c.p, key, shared, non)
            c.p += non
            val vo = c.p
            c.p += vlen
            prev = key
            f(key, blk, vo, vlen)
        }
    }

    private fun readTable(d: ByteArray, col: Collector) {
        val n = d.size
        if (n < 48) return
        for (i in 0 until 8) if (d[n - 8 + i] != MAGIC[i]) return
        val cur = Cur(d, n - 48)
        cur.varint(); cur.varint()
        val ioff = cur.varint().toInt()
        val isz = cur.varint().toInt()
        val index = block(d, ioff, isz) ?: return
        forEachEntry(index) { _, ib, vo, _ ->
            val hc = Cur(ib, vo)
            val off = hc.varint().toInt()
            val sz = hc.varint().toInt()
            val data = block(d, off, sz)
            if (data != null) {
                forEachEntry(data) { k, b, o, l ->
                    // internal key = user key + 8 byte trailer; trailer's first byte 1 = value, 0 = deletion
                    if (k.size >= 8 && (k[k.size - 8].toInt() and 255) == 1) col.add(k, k.size - 8, b, o, l)
                }
            }
        }
    }

    private fun batch(b: ByteArray, col: Collector) {
        if (b.size < 12) return
        var p = 12
        try {
            while (p < b.size) {
                val t = b[p++].toInt() and 255
                val c1 = Cur(b, p)
                val kl = c1.varint().toInt()
                val ko = c1.p
                if (kl < 0 || ko.toLong() + kl > b.size) return
                val key = b.copyOfRange(ko, ko + kl)
                p = ko + kl
                if (t == 1) {
                    val c2 = Cur(b, p)
                    val vl = c2.varint().toInt()
                    val vo = c2.p
                    if (vl < 0 || vo.toLong() + vl > b.size) return
                    col.add(key, key.size, b, vo, vl)
                    p = vo + vl
                } else if (t != 0) {
                    return
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun readLog(d: ByteArray, col: Collector) {
        var pos = 0
        val cur = ByteArrayOutputStream()
        while (pos < d.size) {
            val blockEnd = minOf(d.size, (pos / 32768 + 1) * 32768)
            if (blockEnd - pos < 7) { pos = blockEnd; continue }
            val len = (d[pos + 4].toInt() and 255) or ((d[pos + 5].toInt() and 255) shl 8)
            val type = d[pos + 6].toInt() and 255
            val start = pos + 7
            if (type == 0 && len == 0) { pos = blockEnd; continue }
            if (start + len > blockEnd) break
            when (type) {
                1 -> { batch(d.copyOfRange(start, start + len), col); cur.reset() }
                2 -> { cur.reset(); cur.write(d, start, len) }
                3 -> cur.write(d, start, len)
                4 -> { cur.write(d, start, len); batch(cur.toByteArray(), col); cur.reset() }
                else -> {}
            }
            pos = start + len
        }
    }

    fun build(zipFile: File, cacheFile: File, progress: (Int, Int) -> Unit): AtlasData {
        val cached = loadCache(cacheFile)
        if (cached != null) return cached
        val col = Collector()
        var files = 0
        ZipFile(zipFile).use { z ->
            val es = z.entries().asSequence().filter {
                !it.isDirectory && it.name.contains("db/") && (it.name.endsWith(".ldb") || it.name.endsWith(".log") || it.name.endsWith(".sst"))
            }.toList()
            es.forEachIndexed { i, e ->
                progress(i, es.size)
                if (e.size in 1L..400_000_000L) {
                    val d = z.getInputStream(e).use { it.readBytes() }
                    try {
                        if (e.name.endsWith(".log")) readLog(d, col) else readTable(d, col)
                        files++
                    } catch (ex: Exception) {
                    }
                }
            }
            progress(es.size, es.size)
        }
        if (files == 0) throw IOException("No LevelDB files found in this world backup")
        val a = AtlasData(col.chunks, col.blocks, col.player, col.playerDim, files, col.keys)
        runCatching { saveCache(cacheFile, a) }
        return a
    }

    private fun saveCache(f: File, a: AtlasData) {
        DataOutputStream(BufferedOutputStream(FileOutputStream(f))).use { o ->
            o.writeInt(1)
            o.writeInt(a.files)
            o.writeInt(a.keys)
            for (d in 0..2) {
                o.writeInt(a.chunks[d].size)
                for (v in a.chunks[d]) o.writeLong(v)
                o.writeInt(a.blocks[d].size)
                for (v in a.blocks[d]) o.writeLong(v)
            }
            val p = a.player
            o.writeBoolean(p != null)
            if (p != null) { o.writeDouble(p[0]); o.writeDouble(p[1]); o.writeDouble(p[2]); o.writeInt(a.playerDim) }
        }
    }

    private fun loadCache(f: File): AtlasData? {
        if (!f.exists()) return null
        return try {
            DataInputStream(BufferedInputStream(FileInputStream(f))).use { i ->
                if (i.readInt() != 1) return null
                val files = i.readInt()
                val keys = i.readInt()
                val chunks = Array(3) { HashSet<Long>() }
                val blocks = Array(3) { HashSet<Long>() }
                for (d in 0..2) {
                    repeat(i.readInt()) { chunks[d].add(i.readLong()) }
                    repeat(i.readInt()) { blocks[d].add(i.readLong()) }
                }
                var player: DoubleArray? = null
                var pd = 0
                if (i.readBoolean()) {
                    player = doubleArrayOf(i.readDouble(), i.readDouble(), i.readDouble())
                    pd = i.readInt()
                }
                AtlasData(chunks, blocks, player, pd, files, keys)
            }
        } catch (e: Exception) {
            null
        }
    }
}
