package app.minesaver

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

private val BuildCats = listOf(R.string.bc_house, R.string.bc_farm, R.string.bc_redstone, R.string.bc_castle, R.string.bc_other)
private val BuildStatus = listOf(R.string.bs_planned, R.string.bs_progress, R.string.bs_done)

// ---------- Build Studio ----------
@Composable
fun BuildsScreen(vm: MainVm, nav: NavController) {
    var name by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf(0) }
    var world by remember { mutableStateOf("") }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val done = vm.builds.count { it.status == 2 }
    Page(R.string.title_builds, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                Text(stringResource(R.string.bd_stats, vm.builds.size, done), style = MaterialTheme.typography.bodyMedium)
            }
        }
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(world, { world = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.pl_world)) })
                Spacer(Modifier.height(8.dp))
                Acts { BuildCats.forEachIndexed { i, c -> TagChip(stringResource(c), cat == i) { cat = i } } }
                Spacer(Modifier.height(10.dp))
                Acts { Act(R.string.bd_add, Icons.Rounded.Add) { if (name.isNotBlank()) { vm.addBuild(name, cat, world.trim()); name = ""; world = "" } } }
            }
        }
        if (vm.builds.isEmpty()) item { Text(stringResource(R.string.bd_empty), color = dim) }
        itemsIndexed(vm.builds, key = { _, b -> b.id }) { i, b ->
            val total = b.mats.size
            val ok = b.mats.count { it.endsWith("|1") }
            Appear(i) {
                Glass(Modifier.clickable { vm.buildSel = b.id; nav.navigate("build") }) {
                    Text(b.name, style = MaterialTheme.typography.titleMedium)
                    Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Badge(stringResource(BuildCats[b.cat.coerceIn(0, 4)]), MaterialTheme.colorScheme.secondary)
                        Badge(stringResource(BuildStatus[b.status.coerceIn(0, 2)]), if (b.status == 2) Green else Amber)
                        if (total > 0) Badge("$ok/$total", MaterialTheme.colorScheme.tertiary)
                    }
                }
            }
        }
    }
}

@Composable
fun BuildDetailScreen(vm: MainVm, nav: NavController) {
    val b = vm.builds.find { it.id == vm.buildSel }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var mat by remember { mutableStateOf("") }
    var del by remember { mutableStateOf(false) }
    var l by remember { mutableStateOf("") }
    var w by remember { mutableStateOf("") }
    var h by remember { mutableStateOf("") }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? -> if (u != null && b != null) vm.addBuildShot(b.id, u) }
    if (b == null) {
        Page(R.string.title_builds, onBack = { nav.popBackStack() }) { item { Glass { Text(stringResource(R.string.world_gone)) } } }
        return
    }
    PageBase(b.name, { nav.popBackStack() }) {
        item {
            Glass {
                Acts { BuildStatus.forEachIndexed { i, r -> TagChip(stringResource(r), b.status == i) { vm.updateBuild(b.copy(status = i)) } } }
                Spacer(Modifier.height(10.dp))
                Acts { BuildCats.forEachIndexed { i, c -> TagChip(stringResource(c), b.cat == i) { vm.updateBuild(b.copy(cat = i)) } } }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(b.x, { vm.updateBuild(b.copy(x = it)) }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                    OutlinedTextField(b.y, { vm.updateBuild(b.copy(y = it)) }, Modifier.weight(1f), singleLine = true, label = { Text("Y") }, keyboardOptions = numeric)
                    OutlinedTextField(b.z, { vm.updateBuild(b.copy(z = it)) }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(b.notes, { vm.updateBuild(b.copy(notes = it)) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text(stringResource(R.string.wd_notes)) })
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.bd_materials), Icons.Rounded.Build)
                b.mats.forEachIndexed { i, m ->
                    val done = m.endsWith("|1")
                    val label = m.substringBeforeLast('|')
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(done, { c -> vm.updateBuild(b.copy(mats = b.mats.mapIndexed { k, x -> if (k == i) label + "|" + (if (c) "1" else "0") else x })) })
                        Text(label, Modifier.weight(1f))
                        IconButton(onClick = { vm.updateBuild(b.copy(mats = b.mats.filterIndexed { k, _ -> k != i })) }) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(mat, { mat = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.bd_mat_add)) })
                    IconButton(onClick = { if (mat.isNotBlank()) { vm.updateBuild(b.copy(mats = b.mats + (mat.trim().replace("|", "/") + "|0"))); mat = "" } }) { Icon(Icons.Rounded.Add, null) }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.bd_size_calc), Icons.Rounded.Info)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(l, { l = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.bd_len)) }, keyboardOptions = numeric)
                    OutlinedTextField(w, { w = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.bd_wid)) }, keyboardOptions = numeric)
                    OutlinedTextField(h, { h = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.bd_hei)) }, keyboardOptions = numeric)
                }
                val li = l.toIntOrNull(); val wi = w.toIntOrNull(); val hi = h.toIntOrNull()
                if (li != null && wi != null && hi != null && li > 0 && wi > 0 && hi > 0) {
                    val v = li.toLong() * wi * hi
                    Text(stringResource(R.string.bd_volume, v, (v + 63) / 64, (v + 1727) / 1728), modifier = Modifier.padding(top = 10.dp), fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.bd_volume_note), style = MaterialTheme.typography.bodySmall, color = dim)
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.bd_shots), Icons.Rounded.History)
                Text(stringResource(R.string.bd_shots_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                if (b.shots.isNotEmpty()) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) { items(b.shots) { n -> ShotThumb(vm, n) } }
                }
                Spacer(Modifier.height(8.dp))
                Acts { Act(R.string.dna_add_shot, Icons.Rounded.Add) { pick.launch("image/*") } }
            }
        }
        item { Acts { Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = true } } }
    }
    if (del) ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deleteBuild(b.id); del = false; nav.popBackStack() }, { del = false })
}

// ---------- Play journal ----------
@Composable
fun JournalScreen(vm: MainVm, nav: NavController) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var world by remember { mutableStateOf("") }
    var minutes by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var ch by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<String?>(null) }
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    val now = System.currentTimeMillis()
    val day = 24L * 3600 * 1000
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
    val startToday = cal.timeInMillis
    val today = vm.plays.filter { it.at >= startToday }.sumOf { it.minutes }
    val week = vm.plays.filter { now - it.at < 7 * day }.sumOf { it.minutes }
    val month = vm.plays.filter { now - it.at < 30 * day }.sumOf { it.minutes }
    val total = vm.plays.sumOf { it.minutes }
    val byWorld = vm.plays.groupBy { it.world }.mapValues { e -> e.value.sumOf { it.minutes } }.entries.sortedByDescending { it.value }.take(5)
    val observed = vm.sessions.values.sum()
    Page(R.string.title_journal, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                SectionTitle(stringResource(R.string.jr_stats), Icons.Rounded.History)
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    DetailRow(R.string.jr_today, fmtMin(today))
                    DetailRow(R.string.jr_week, fmtMin(week))
                    DetailRow(R.string.jr_month, fmtMin(month))
                    DetailRow(R.string.jr_total, fmtMin(total))
                    DetailRow(R.string.jr_observed, observed.toString())
                }
                byWorld.forEach { e -> Text("• " + e.key + " — " + fmtMin(e.value), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 6.dp)) }
                Text(stringResource(R.string.jr_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.jr_add), Icons.Rounded.Add)
                Spacer(Modifier.height(8.dp))
                Acts { vm.rows.take(10).forEach { r -> TagChip(r.name, world == r.name) { world = r.name } } }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(world, { world = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.pl_world)) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(minutes, { minutes = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.jr_minutes)) }, keyboardOptions = numeric)
                    OutlinedTextField(note, { note = it }, Modifier.weight(2f), singleLine = true, label = { Text(stringResource(R.string.sd_note)) })
                }
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.jr_save, Icons.Rounded.Add) {
                        val m = minutes.toIntOrNull()
                        if (m != null && m > 0) { vm.addPlay(world.trim(), m, note); minutes = ""; note = "" }
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.jr_challenges), Icons.Rounded.VerifiedUser)
                vm.challenges.forEach { c ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(c.done, { vm.toggleChallenge(c.id) })
                        Column(Modifier.weight(1f)) {
                            Text(c.title)
                            if (c.done) Text(fmtDate(c.doneAt), style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                        IconButton(onClick = { vm.deleteChallenge(c.id) }) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(ch, { ch = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.jr_ch_add)) })
                    IconButton(onClick = { vm.addChallenge(ch); ch = "" }) { Icon(Icons.Rounded.Add, null) }
                }
            }
        }
        item { SectionTitle(stringResource(R.string.jr_history), Icons.Rounded.History) }
        if (vm.plays.isEmpty()) item { Text(stringResource(R.string.jr_empty), color = dim) }
        itemsIndexed(vm.plays, key = { _, p -> p.id }) { i, p ->
            Appear(i) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text((if (p.world.isBlank()) "—" else p.world) + " · " + fmtMin(p.minutes), style = MaterialTheme.typography.titleMedium)
                            Text(fmtDate(p.at), style = MaterialTheme.typography.bodySmall, color = dim)
                            if (p.note.isNotBlank()) Text(p.note, style = MaterialTheme.typography.bodyMedium)
                        }
                        IconButton(onClick = { del = p.id }) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    del?.let { id -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deletePlay(id); del = null }, { del = null }) }
}

@Composable
private fun fmtMin(m: Int): String = stringResource(R.string.jr_fmt, m / 60, m % 60)

// ---------- Pack repair (never changes the original) ----------
private class RepairPlan(val name: String, val changes: Map<String, List<Int>>, val invalid: List<String>)

private fun planRepair(f: File): RepairPlan = ZipFile(f).use { z ->
    val changes = LinkedHashMap<String, List<Int>>()
    val invalid = ArrayList<String>()
    for (e in z.entries().asSequence()) {
        if (e.isDirectory || !e.name.lowercase().endsWith("manifest.json") || e.name.count { it == '/' } > 3) continue
        val raw = z.getInputStream(e).use { readLimited(it, 1_000_000) } ?: continue
        val text = String(raw, Charsets.UTF_8)
        val (cleaned, ch) = cleanJson(text)
        if (parseManifest(cleaned) == null) invalid.add(e.name)
        else if (ch.isNotEmpty()) changes[e.name] = ch
    }
    RepairPlan(f.name, changes, invalid)
}

private fun writeRepaired(src: File, plan: RepairPlan, out: java.io.OutputStream) {
    ZipFile(src).use { z ->
        ZipOutputStream(out).use { zo ->
            for (e in z.entries().asSequence()) {
                val safe = safeEntryName(e.name) ?: continue
                zo.putNextEntry(ZipEntry(safe))
                if (!e.isDirectory) {
                    if (plan.changes.containsKey(e.name)) {
                        val raw = z.getInputStream(e).use { it.readBytes() }
                        zo.write(cleanJson(String(raw, Charsets.UTF_8)).first.toByteArray(Charsets.UTF_8))
                    } else z.getInputStream(e).use { it.copyTo(zo) }
                }
                zo.closeEntry()
            }
        }
    }
}

@Composable
fun RepairScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var plan by remember { mutableStateOf<RepairPlan?>(null) }
    var file by remember { mutableStateOf<File?>(null) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            busy = true
            scope.launch {
                val r = withContext(Dispatchers.IO) {
                    runCatching {
                        val tmp = File(ctx.cacheDir, "repair_src.zip")
                        var total = 0L
                        (ctx.contentResolver.openInputStream(u) ?: error("read")).use { i ->
                            tmp.outputStream().use { o ->
                                val buf = ByteArray(65536)
                                while (true) {
                                    val n = i.read(buf)
                                    if (n < 0) break
                                    total += n
                                    if (total > 1_000_000_000L) error("too large")
                                    o.write(buf, 0, n)
                                }
                            }
                        }
                        tmp to planRepair(tmp)
                    }
                }
                file = r.getOrNull()?.first
                plan = r.getOrNull()?.second
                msg = r.exceptionOrNull()?.message
                busy = false
            }
        }
    }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u: Uri? ->
        val f = file
        val p = plan
        if (u != null && f != null && p != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openOutputStream(u)?.use { writeRepaired(f, p, it) } }.isSuccess }
                vm.logNote(Msg(if (ok) R.string.rj_saved else R.string.err, if (ok) p.changes.size else "?"))
                vm.toast = Msg(if (ok) R.string.rj_saved else R.string.err, if (ok) p.changes.size else "?")
            }
        }
    }
    Page(R.string.title_repair, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.rj_intro), color = dim) }
        item { Acts { Act(R.string.fi_pick, Icons.Rounded.FolderOpen) { pick.launch(arrayOf("*/*")) } } }
        if (busy) item { androidx.compose.material3.LinearProgressIndicator(Modifier.fillMaxWidth()) }
        msg?.let { m -> item { Text(m, color = MaterialTheme.colorScheme.error) } }
        val p = plan
        if (p != null) {
            item {
                Glass {
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    if (p.changes.isEmpty() && p.invalid.isEmpty()) Text(stringResource(R.string.rj_nothing), modifier = Modifier.padding(top = 8.dp))
                    p.changes.forEach { (path, ch) ->
                        Text(path, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                        ch.forEach { Text("• " + stringResource(it), style = MaterialTheme.typography.bodySmall, color = dim) }
                    }
                    p.invalid.forEach { Text(stringResource(R.string.rj_unfixable, it), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp)) }
                    if (p.changes.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Acts { Act(R.string.rj_save, Icons.Rounded.FileUpload) { save.launch(p.name.removeSuffix(".zip").removeSuffix(".mcpack").removeSuffix(".mcaddon") + "_repaired.mcpack") } }
                    }
                    Text(stringResource(R.string.rj_safe), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
    }
}
