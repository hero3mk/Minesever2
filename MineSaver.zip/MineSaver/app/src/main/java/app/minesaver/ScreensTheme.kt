package app.minesaver

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.material3.LocalContentColor
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.util.Locale

/** A real preview: the actual components drawn with the theme being edited. */
@Composable
private fun BigPreview(look: Look) {
    CompositionLocalProvider(LocalLook provides look, LocalContentColor provides look.text) {
        MaterialTheme(colorScheme = look.scheme(), typography = AppTypography) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(26.dp)).background(Brush.verticalGradient(look.bg)).padding(16.dp)) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(stringResource(R.string.app_name), style = AppTypography.headlineMedium, color = look.text)
                    Glass {
                        SectionTitle(stringResource(R.string.home_protected), Icons.Rounded.Storage)
                        Text(stringResource(R.string.home_of, 3, 4), color = look.textDim, modifier = Modifier.padding(vertical = 8.dp))
                        Acts {
                            Act(R.string.qa_restore, Icons.Rounded.Restore) { }
                            Act(R.string.a_storage, Icons.Rounded.Storage) { }
                        }
                        Spacer(Modifier.height(10.dp))
                        GradientButton(stringResource(R.string.home_backup_all), Icons.Rounded.CloudUpload) { }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom, modifier = Modifier.height(48.dp)) {
                        listOf(18, 30, 22, 40, 28, 36, 24).forEachIndexed { i, h ->
                            Box(Modifier.weight(1f).height(h.dp).clip(RoundedCornerShape(5.dp)).background(if (i % 2 == 0) look.accent else look.accent2))
                        }
                    }
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(look.card).padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        repeat(5) { i -> Box(Modifier.size(if (i == 0) 14.dp else 10.dp).clip(CircleShape).background(if (i == 0) look.accent else look.textDim)) }
                    }
                }
            }
        }
    }
}

private val SpecRegex = Regex("^[01]\\|\\d{1,3}\\|\\d{1,3}\\|\\d(\\.\\d+)?\\|[01]$")

@Composable
fun ThemeStudioScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    val init = vm.cspec.split("|")
    var dark by remember { mutableStateOf(init.getOrNull(0) != "0") }
    var h1 by remember { mutableFloatStateOf(init.getOrNull(1)?.toFloatOrNull() ?: 260f) }
    var h2 by remember { mutableFloatStateOf(init.getOrNull(2)?.toFloatOrNull() ?: 190f) }
    var lvl by remember { mutableFloatStateOf(init.getOrNull(3)?.toFloatOrNull() ?: 0.3f) }
    var grad by remember { mutableStateOf(init.getOrNull(4) != "0") }
    val spec = (if (dark) "1" else "0") + "|" + h1.toInt() + "|" + h2.toInt() + "|" + String.format(Locale.US, "%.2f", lvl) + "|" + (if (grad) "1" else "0")
    val look = remember(spec) { customLook(spec) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    fun load(s: String) {
        val p = s.split("|")
        dark = p[0] != "0"; h1 = p[1].toFloat(); h2 = p[2].toFloat(); lvl = p[3].toFloat(); grad = p[4] != "0"
    }
    Page(R.string.title_studio_theme, onBack = { nav.popBackStack() }) {
        item { BigPreview(look) }
        item {
            Glass {
                Segment(listOf(stringResource(R.string.ts_dark), stringResource(R.string.ts_light)), if (dark) 0 else 1) { dark = it == 0 }
                Text(stringResource(R.string.ts_primary), color = dim, modifier = Modifier.padding(top = 14.dp))
                Slider(h1, { h1 = it }, valueRange = 0f..360f)
                Text(stringResource(R.string.ts_secondary), color = dim)
                Slider(h2, { h2 = it }, valueRange = 0f..360f)
                Text(stringResource(R.string.ts_bg), color = dim)
                Slider(lvl, { lvl = it }, valueRange = 0f..1f)
                SwitchRow(R.string.ts_gradient, grad) { grad = it }
            }
        }
        item {
            Acts {
                Act(R.string.ts_apply, Icons.Rounded.Palette) { vm.changeCustom(spec); vm.toast = Msg(R.string.ts_applied) }
                Act(R.string.ts_reset, Icons.Rounded.Refresh) { load(DEFAULT_CSPEC) }
                Act(R.string.ts_export, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString("MSTHEME:$spec")); vm.toast = Msg(R.string.copied, "MSTHEME") }
                Act(R.string.ts_import, Icons.Rounded.FileUpload) {
                    val t = clip.getText()?.text?.trim() ?: ""
                    val code = t.removePrefix("MSTHEME:")
                    if (t.startsWith("MSTHEME:") && SpecRegex.matches(code)) { load(code); vm.toast = Msg(R.string.ts_imported) } else vm.toast = Msg(R.string.ts_bad_code)
                }
            }
        }
        item { Text(stringResource(R.string.ts_note), style = MaterialTheme.typography.bodySmall, color = dim) }
    }
}
