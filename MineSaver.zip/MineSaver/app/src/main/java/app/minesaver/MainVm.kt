package app.minesaver

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

class MainVm(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("ms", 0)

    var backups by mutableStateOf(repo.load()); private set
    var live by mutableStateOf(emptyList<LiveWorld>()); private set
    var bad by mutableStateOf(emptySet<String>()); private set
    var busy by mutableStateOf<Msg?>(null); private set
    var toast by mutableStateOf<Msg?>(null)
    var pick by mutableStateOf<String?>(null)
    var theme by mutableIntStateOf(prefs.getInt("theme", 0)); private set
    var auto by mutableStateOf(prefs.getBoolean("auto", true)); private set
    var src by mutableStateOf(prefs.getString("src", null)); private set
    var safe by mutableStateOf(prefs.getString("safe", null)); private set

    /** 0 = Shizuku not installed, 1 = installed but not running, 2 = running, needs permission, 3 = ready */
    var sz by mutableIntStateOf(0); private set
    var szOn by mutableStateOf(prefs.getBoolean("szOn", false)); private set
    val szActive: Boolean get() = sz == 3 && szOn
    val canWriteGame: Boolean get() = szActive || src != null

    private val onBinder = Shizuku.OnBinderReceivedListener { refreshSz() }
    private val onDead = Shizuku.OnBinderDeadListener { refreshSz() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshSz() }

    init {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        }
        refreshSz()
    }

    override fun onCleared() {
        runCatching {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        }
    }

    fun refreshSz() {
        val installed = runCatching { getApplication<Application>().packageManager.getPackageInfo(Sz.PKG, 0); true }.getOrDefault(false)
        sz = when {
            Sz.ready() -> 3
            Sz.running() -> 2
            installed -> 1
            else -> 0
        }
        if (sz == 3 && !prefs.contains("szOn")) changeSzOn(true)
    }

    fun requestSz() = Sz.request()
    fun changeSzOn(v: Boolean) { szOn = v; prefs.edit().putBoolean("szOn", v).apply() }

    val rows: List<WorldRow>
        get() {
            val ids = (live.map { it.id } + backups.map { it.worldId }).distinct()
            return ids.map { id ->
                val l = live.find { it.id == id }
                val bs = backups.filter { it.worldId == id }.sortedByDescending { it.time }
                WorldRow(id, l?.name ?: bs.first().worldName, l?.mode ?: bs.first().mode, l, bs)
            }.sortedBy { it.name.lowercase() }
        }

    fun file(b: Backup): File = repo.file(b)
    fun iconFile(worldId: String): File = repo.icon(worldId)

    private fun job(m: Msg, block: () -> Msg?) {
        if (busy != null) { toast = Msg(R.string.busy_wait); return }
        busy = m
        viewModelScope.launch {
            val r = try { withContext(Dispatchers.IO) { block() } } catch (e: Exception) { Msg(R.string.err, e.message ?: e.javaClass.simpleName) }
            backups = repo.load()
            if (r != null) toast = r
            busy = null
        }
    }

    private fun doScan() {
        live = when {
            szActive -> try { Sz.listWorlds() } catch (e: Exception) { toast = Msg(R.string.msg_sz_fail, e.message ?: "?"); emptyList() }
            src != null -> runCatching { repo.scan(Uri.parse(src!!)) }.getOrDefault(emptyList())
            else -> emptyList()
        }
    }

    private fun backupMany(ws: List<LiveWorld>): Msg? {
        if (ws.isEmpty()) return null
        var ok = 0; var fail = 0; var mirrorFail = 0
        var lastErr: String? = null
        ws.forEach { w ->
            try {
                val b = repo.backupLive(w)
                ok++
                safe?.let { if (!repo.mirror(b, Uri.parse(it))) mirrorFail++ }
            } catch (e: Exception) { fail++; lastErr = e.message }
        }
        backups = repo.load()
        val le = lastErr
        return when {
            fail > 0 && ok == 0 && le != null -> Msg(R.string.err, le)
            fail > 0 -> Msg(R.string.msg_backed_part, ok, fail)
            mirrorFail > 0 -> Msg(R.string.msg_mirror_fail)
            else -> Msg(R.string.msg_backed, ok)
        }
    }

    fun appStarted() {
        if ((src == null && !szActive) || busy != null) return
        job(Msg(R.string.busy_scan)) { doScan(); if (auto) backupMany(live.filter { w -> rows.find { it.id == w.id }?.changed == true }) else null }
    }

    fun rescan() = job(Msg(R.string.busy_scan)) { doScan(); Msg(R.string.msg_scanned, live.size) }
    fun backupNow(w: LiveWorld) = job(Msg(R.string.busy_backup)) { backupMany(listOf(w)) }
    fun backupWorlds(ws: List<LiveWorld>) = job(Msg(R.string.busy_backup)) { backupMany(ws) ?: Msg(R.string.msg_no_worlds) }
    fun backupAll() = job(Msg(R.string.busy_backup)) { doScan(); backupMany(live) ?: Msg(R.string.msg_no_worlds) }

    private fun importCore(uris: List<Uri>, mirror: Boolean): Msg {
        var n = 0; var dup = 0; var failure: String? = null
        uris.forEach { u ->
            try {
                val (b, isNew) = repo.importMcworld(u)
                if (isNew) { n++; if (mirror) safe?.let { repo.mirror(b, Uri.parse(it)) } } else dup++
            } catch (e: Exception) { failure = e.message ?: "import" }
        }
        backups = repo.load()
        val f = failure
        return if (f != null && n == 0 && dup == 0) Msg(R.string.err, f) else Msg(R.string.msg_imported, n, dup)
    }

    fun import(uris: List<Uri>) = job(Msg(R.string.busy_import)) { importCore(uris, true) }

    fun importSafe() {
        val s = safe ?: run { toast = Msg(R.string.msg_no_safe); return }
        job(Msg(R.string.busy_import)) { importCore(repo.listMcworlds(Uri.parse(s)), false) }
    }

    fun restoreToGame(b: Backup) {
        if (szActive) {
            job(Msg(R.string.busy_restore)) { val n = repo.restoreViaShizuku(b); doScan(); Msg(R.string.msg_restored, n) }
            return
        }
        val s = src ?: run { toast = Msg(R.string.msg_no_src); return }
        job(Msg(R.string.busy_restore)) { val n = repo.restoreToTree(b, Uri.parse(s)); doScan(); Msg(R.string.msg_restored, n) }
    }

    fun exportTo(b: Backup, u: Uri) = job(Msg(R.string.busy_export)) { repo.exportTo(b, u); Msg(R.string.msg_exported) }

    fun verifyAll() = job(Msg(R.string.busy_verify)) {
        val ids = backups.filter { !repo.verify(it) }.map { it.id }.toSet()
        bad = ids
        if (ids.isEmpty()) Msg(R.string.msg_verify_ok, backups.size) else Msg(R.string.msg_verify_bad, ids.size)
    }

    fun verifyOne(b: Backup) = job(Msg(R.string.busy_verify)) {
        val ok = repo.verify(b)
        bad = if (ok) bad - b.id else bad + b.id
        if (ok) Msg(R.string.msg_verify_ok, 1) else Msg(R.string.msg_verify_bad, 1)
    }

    fun deleteBackups(list: List<Backup>) = job(Msg(R.string.busy_scan)) { repo.delete(list); Msg(R.string.msg_deleted) }
    fun deleteWorlds(ids: Set<String>) = job(Msg(R.string.busy_scan)) { repo.delete(backups.filter { it.worldId in ids }); Msg(R.string.msg_deleted) }

    private fun grant(u: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
    }

    fun changeTheme(i: Int) { theme = i; prefs.edit().putInt("theme", i).apply() }
    fun changeAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun setSrc(u: Uri?) {
        u?.let { grant(it) }
        src = u?.toString(); prefs.edit().putString("src", src).apply()
        if (u != null) rescan() else live = emptyList()
    }
    fun setSafe(u: Uri?) {
        u?.let { grant(it) }
        safe = u?.toString(); prefs.edit().putString("safe", safe).apply()
    }
}
