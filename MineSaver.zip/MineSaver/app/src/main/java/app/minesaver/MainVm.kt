package app.minesaver

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

class MainVm(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("ms", 0)
    private val addonRepo = AddonRepo(app)

    var backups by mutableStateOf(repo.load()); private set
    var live by mutableStateOf(emptyList<LiveWorld>()); private set
    var bad by mutableStateOf(emptySet<String>()); private set
    var busy by mutableStateOf<Msg?>(null); private set
    var toast by mutableStateOf<Msg?>(null)
    var pick by mutableStateOf<String?>(null)
    var theme by mutableIntStateOf(prefs.getInt("theme", 0)); private set
    var auto by mutableStateOf(prefs.getBoolean("auto", true)); private set
    var src by mutableStateOf(prefs.getString("src", null)); private set
    var safe by mutableStateOf(prefs.getString("safe", null)); private set

    /** 0 = Shizuku not installed, 1 = installed but not running, 2 = running, needs permission, 3 = ready */
    var sz by mutableIntStateOf(0); private set
    var szOn by mutableStateOf(prefs.getBoolean("szOn", false)); private set
    val szActive: Boolean get() = sz == 3 && szOn
    val canWriteGame: Boolean get() = szActive || src != null

    private val onBinder = Shizuku.OnBinderReceivedListener { refreshSz() }
    private val onDead = Shizuku.OnBinderDeadListener { refreshSz() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshSz() }

    init {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        }
        refreshSz()
    }

    override fun onCleared() {
        runCatching {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        }
    }

    fun refreshSz() {
        val installed = runCatching { getApplication<Application>().packageManager.getPackageInfo(Sz.PKG, 0); true }.getOrDefault(false)
        sz = when {
            Sz.ready() -> 3
            Sz.running() -> 2
            installed -> 1
            else -> 0
        }
        if (sz == 3 && !prefs.contains("szOn")) changeSzOn(true)
    }

    var diag by mutableStateOf<String?>(null)
    var log by mutableStateOf(repo.logLoad()); private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()); private set
    var anim by mutableStateOf(prefs.getBoolean("anim", true)); private set
    var bg by mutableStateOf(prefs.getBoolean("bg", true)); private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0)); private set
    var pinSet by mutableStateOf(prefs.contains("pin")); private set
    var locked by mutableStateOf(prefs.contains("pin")); private set

    var look by mutableIntStateOf(prefs.getInt("look", 0)); private set
    var follow by mutableStateOf(prefs.getBoolean("follow", false)); private set
    var fontScale by mutableIntStateOf(prefs.getInt("fscale", 1)); private set
    var welcome by mutableStateOf(!prefs.getBoolean("welcome", false)); private set
    var dl by mutableStateOf(prefs.getBoolean("dl", true)); private set

    var detailId by mutableStateOf<String?>(null)
    var cmpA by mutableStateOf<String?>(null)
    var cmpB by mutableStateOf<String?>(null)
    var infos by mutableStateOf<Map<String, WorldInfo>>(emptyMap()); private set
    var sessions by mutableStateOf(loadSessions()); private set
    var meta by mutableIntStateOf(0); private set
    var seeds by mutableStateOf(loadSeeds()); private set
    var places by mutableStateOf(loadPlaces()); private set

    var addons by mutableStateOf(addonRepo.load()); private set
    var addonSel by mutableStateOf<String?>(null)
    var acols by mutableStateOf(loadAcols()); private set
    var packRefs by mutableStateOf<Map<String, List<PackRef>>>(emptyMap()); private set

    var atlasWorld by mutableStateOf<String?>(null)
    var atlas by mutableStateOf<Map<String, AtlasData>>(emptyMap()); private set
    var atlasLoading by mutableStateOf(false); private set
    var atlasProgress by mutableFloatStateOf(0f); private set
    var atlasError by mutableStateOf<String?>(null); private set
    var mapFocus by mutableStateOf<Pair<Int, Int>?>(null)
    var routeA by mutableStateOf<Pair<Int, Int>?>(null)
    var routeB by mutableStateOf<Pair<Int, Int>?>(null)

    var report by mutableStateOf<WorldReport?>(null); private set
    var reportBusy by mutableStateOf(false); private set
    var zstats by mutableStateOf<Map<String, ZipStat>>(emptyMap()); private set

    var bio by mutableStateOf(prefs.getBoolean("bio", false)); private set
    var lockTimeout by mutableIntStateOf(prefs.getInt("lockto", 1)); private set
    var servers by mutableStateOf(loadServers()); private set
    fun runDiag() = job(Msg(R.string.busy_scan)) { diag = try { Sz.diagnose() } catch (e: Exception) { e.message ?: "error" }; null }
    fun requestSz() = Sz.request()
    fun changeSzOn(v: Boolean) { szOn = v; prefs.edit().putBoolean("szOn", v).apply() }

    private val rowsDerived = derivedStateOf {
        val ids = (live.map { it.id } + backups.map { it.worldId }).distinct()
        ids.map { id ->
            val l = live.find { it.id == id }
            val bs = backups.filter { it.worldId == id }.sortedByDescending { it.time }
            WorldRow(id, l?.name ?: bs.first().worldName, l?.mode ?: bs.first().mode, l, bs)
        }.sortedBy { it.name.lowercase() }
    }
    val rows: List<WorldRow> get() = rowsDerived.value

    fun file(b: Backup): File = repo.file(b)
    fun iconFile(worldId: String): File = repo.icon(worldId)

    private fun job(m: Msg, block: () -> Msg?) {
        if (busy != null) { toast = Msg(R.string.busy_wait); return }
        busy = m
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                val x = try { block() } catch (e: Exception) { Msg(R.string.err, e.message ?: e.javaClass.simpleName) }
                if (x != null) repo.logAdd(x)
                x
            }
            backups = repo.load()
            log = repo.logLoad()
            if (r != null) toast = r
            busy = null
        }
    }

    private fun doScan(): Msg? {
        var err: Msg? = null
        live = when {
            szActive -> try { Sz.listWorlds() } catch (e: Exception) { err = Msg(R.string.msg_sz_fail, e.message ?: "?"); emptyList() }
            src != null -> runCatching { repo.scan(Uri.parse(src!!)) }.getOrDefault(emptyList())
            else -> emptyList()
        }
        infos = emptyMap()
        trackSessions(live)
        return err
    }

    private fun backupMany(ws: List<LiveWorld>): Msg? {
        if (ws.isEmpty()) return null
        var ok = 0; var fail = 0; var mirrorFail = 0
        var lastErr: String? = null
        ws.forEach { w ->
            try {
                val b = repo.backupLive(w)
                ok++
                safe?.let { if (!repo.mirror(b, Uri.parse(it))) mirrorFail++ }
                if (dl && !repo.mirrorDownloads(b)) mirrorFail++
            } catch (e: Exception) { fail++; lastErr = e.message }
        }
        backups = repo.load()
        val le = lastErr
        return when {
            fail > 0 && ok == 0 && le != null -> Msg(R.string.err, le)
            fail > 0 -> Msg(R.string.msg_backed_part, ok, fail)
            mirrorFail > 0 -> Msg(R.string.msg_mirror_fail)
            else -> Msg(R.string.msg_backed, ok)
        }
    }

    fun appStarted() {
        if ((src == null && !szActive) || busy != null) return
        job(Msg(R.string.busy_scan)) {
            val e = doScan()
            if (e != null) e else if (auto) backupMany(live.filter { w -> rows.find { it.id == w.id }?.changed == true }) else null
        }
    }

    fun rescan() = job(Msg(R.string.busy_scan)) {
        val e = doScan()
        if (e != null) e else if (live.isEmpty() && szActive) Msg(R.string.msg_none_sz) else Msg(R.string.msg_scanned, live.size)
    }
    fun backupNow(w: LiveWorld) = job(Msg(R.string.busy_backup)) { backupMany(listOf(w)) }
    fun backupWorlds(ws: List<LiveWorld>) = job(Msg(R.string.busy_backup)) { backupMany(ws) ?: Msg(R.string.msg_no_worlds) }
    fun backupAll() = job(Msg(R.string.busy_backup)) {
        val e = doScan()
        if (e != null) e else backupMany(live) ?: Msg(R.string.msg_no_worlds)
    }

    private fun importCore(uris: List<Uri>, mirror: Boolean): Msg {
        var n = 0; var dup = 0; var failure: String? = null
        uris.forEach { u ->
            try {
                val (b, isNew) = repo.importMcworld(u)
                if (isNew) { n++; if (mirror) { safe?.let { repo.mirror(b, Uri.parse(it)) }; if (dl) repo.mirrorDownloads(b) } } else dup++
            } catch (e: Exception) { failure = e.message ?: "import" }
        }
        backups = repo.load()
        val f = failure
        return if (f != null && n == 0 && dup == 0) Msg(R.string.err, f) else Msg(R.string.msg_imported, n, dup)
    }

    fun import(uris: List<Uri>) = job(Msg(R.string.busy_import)) { importCore(uris, true) }

    fun importSafe() {
        val s = safe ?: run { toast = Msg(R.string.msg_no_safe); return }
        job(Msg(R.string.busy_import)) { importCore(repo.listMcworlds(Uri.parse(s)), false) }
    }

    fun restoreToGame(b: Backup) {
        if (szActive) {
            job(Msg(R.string.busy_restore)) { val n = repo.restoreViaShizuku(b); doScan(); Msg(R.string.msg_restored, n) }
            return
        }
        val s = src ?: run { toast = Msg(R.string.msg_no_src); return }
        job(Msg(R.string.busy_restore)) { val n = repo.restoreToTree(b, Uri.parse(s)); doScan(); Msg(R.string.msg_restored, n) }
    }

    fun exportTo(b: Backup, u: Uri) = job(Msg(R.string.busy_export)) { repo.exportTo(b, u); Msg(R.string.msg_exported) }

    fun verifyAll() = job(Msg(R.string.busy_verify)) {
        val ids = backups.filter { !repo.verify(it) }.map { it.id }.toSet()
        bad = ids
        if (ids.isEmpty()) Msg(R.string.msg_verify_ok, backups.size) else Msg(R.string.msg_verify_bad, ids.size)
    }

    fun verifyOne(b: Backup) = job(Msg(R.string.busy_verify)) {
        val ok = repo.verify(b)
        bad = if (ok) bad - b.id else bad + b.id
        if (ok) Msg(R.string.msg_verify_ok, 1) else Msg(R.string.msg_verify_bad, 1)
    }

    fun deleteBackups(list: List<Backup>) = job(Msg(R.string.busy_scan)) { repo.delete(list); Msg(R.string.msg_deleted) }
    fun deleteWorlds(ids: Set<String>) = job(Msg(R.string.busy_scan)) { repo.delete(backups.filter { it.worldId in ids }); Msg(R.string.msg_deleted) }

    private fun grant(u: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
    }

    fun changeTheme(i: Int) { theme = i; prefs.edit().putInt("theme", i).apply() }
    fun changeAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun setSrc(u: Uri?) {
        u?.let { grant(it) }
        src = u?.toString(); prefs.edit().putString("src", src).apply()
        if (u != null) rescan() else live = emptyList()
    }
    fun setSafe(u: Uri?) {
        u?.let { grant(it) }
        safe = u?.toString(); prefs.edit().putString("safe", safe).apply()
    }

    private fun hashPin(p: String) =
        MessageDigest.getInstance("SHA-256").digest(("minesaver:" + p).toByteArray()).joinToString("") { "%02x".format(it) }

    fun unlock(p: String): Boolean {
        val ok = prefs.getString("pin", null) == hashPin(p)
        if (ok) locked = false
        return ok
    }

    fun setPin(p: String?) {
        if (p == null) prefs.edit().remove("pin").apply() else prefs.edit().putString("pin", hashPin(p)).apply()
        pinSet = p != null
    }

    fun toggleFav(id: String) {
        favs = if (id in favs) favs - id else favs + id
        prefs.edit().putStringSet("fav", favs.toSet()).apply()
    }

    fun changeAnim(v: Boolean) { anim = v; prefs.edit().putBoolean("anim", v).apply() }
    fun changeBg(v: Boolean) { bg = v; prefs.edit().putBoolean("bg", v).apply() }
    fun changeAccent(i: Int) { accent = i; prefs.edit().putInt("accent", i).apply() }
    fun clearLog() { repo.logClear(); log = emptyList() }

    fun oldCopies(keep: Int): List<Backup> =
        backups.groupBy { it.worldId }.flatMap { (_, l) -> l.sortedByDescending { it.time }.drop(keep) }

    fun tempSize(): Long = repo.tempFiles().sumOf { it.length() }
    fun cleanTemp() = job(Msg(R.string.busy_scan)) { repo.tempFiles().forEach { it.delete() }; Msg(R.string.msg_temp_cleaned) }

    // ---------- look & general ----------
    fun changeLook(i: Int) { look = i; prefs.edit().putInt("look", i).apply() }
    fun changeDl(v: Boolean) { dl = v; prefs.edit().putBoolean("dl", v).apply() }
    fun changeFollow(v: Boolean) { follow = v; prefs.edit().putBoolean("follow", v).apply() }
    fun changeFontScale(i: Int) { fontScale = i; prefs.edit().putInt("fscale", i).apply() }
    fun closeWelcome() { welcome = false; prefs.edit().putBoolean("welcome", true).apply() }
    fun showWelcome() { welcome = true }

    // ---------- world intelligence ----------
    fun ensureInfo(ids: List<String>) {
        val todo = ids.filter { it !in infos }
        if (todo.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val add = HashMap<String, WorldInfo>()
            for (id in todo) {
                val r = rows.find { it.id == id } ?: continue
                val bytes = runCatching { repo.levelBytes(r.live, r.backups.firstOrNull()) }.getOrNull() ?: continue
                val wi = worldInfo(bytes)
                if (wi != null) add[id] = wi
            }
            if (add.isNotEmpty()) infos = infos + add
        }
    }

    private fun loadSessions(): Map<String, Int> {
        return try {
            val o = JSONObject(prefs.getString("sess", "{}") ?: "{}")
            val m = HashMap<String, Int>()
            for (k in o.keys()) m[k] = o.getJSONArray(k).getInt(0)
            m
        } catch (e: Exception) { emptyMap() }
    }

    private fun trackSessions(ws: List<LiveWorld>) {
        val o = try { JSONObject(prefs.getString("sess", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }
        var changed = false
        for (w in ws) {
            val a = o.optJSONArray(w.id)
            if (a == null) {
                o.put(w.id, JSONArray().put(0).put(w.modified)); changed = true
            } else if (w.modified > a.optLong(1)) {
                o.put(w.id, JSONArray().put(a.optInt(0) + 1).put(w.modified)); changed = true
            }
        }
        if (changed) {
            prefs.edit().putString("sess", o.toString()).apply()
            sessions = loadSessions()
        }
    }

    fun noteOf(id: String): String { if (meta < 0) return ""; return prefs.getString("note_" + id, "") ?: "" }
    fun setNote(id: String, text: String) { prefs.edit().putString("note_" + id, text).apply() }
    fun tagsOf(id: String): Set<String> {
        if (meta < 0) return emptySet()
        return prefs.getStringSet("tags_" + id, emptySet())?.toSet() ?: emptySet()
    }
    fun toggleTag(id: String, t: String) {
        val c = tagsOf(id)
        prefs.edit().putStringSet("tags_" + id, if (t in c) c - t else c + t).apply()
        meta += 1
    }

    // ---------- seeds & places ----------
    private fun loadSeeds(): List<SavedSeed> {
        return try {
            val a = JSONArray(prefs.getString("seeds", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                SavedSeed(o.getString("id"), o.getString("n"), o.getString("s"), o.optString("w", ""))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveSeeds(l: List<SavedSeed>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("s", it.seed).put("w", it.note)) }
        prefs.edit().putString("seeds", a.toString()).apply()
        seeds = l
    }

    fun addSeed(name: String, seed: String, note: String) =
        saveSeeds(listOf(SavedSeed(UUID.randomUUID().toString(), name, seed, note)) + seeds)
    fun deleteSeed(id: String) = saveSeeds(seeds.filter { it.id != id })

    private fun loadPlaces(): List<SavedPlace> {
        return try {
            val a = JSONArray(prefs.getString("places", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                SavedPlace(o.getString("id"), o.getString("n"), o.getInt("t"), o.getString("x"), o.getString("y"), o.getString("z"), o.optString("w", ""))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun savePlaces(l: List<SavedPlace>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("t", it.type).put("x", it.x).put("y", it.y).put("z", it.z).put("w", it.world)) }
        prefs.edit().putString("places", a.toString()).apply()
        places = l
    }

    fun addPlace(name: String, type: Int, x: String, y: String, z: String, world: String) =
        savePlaces(listOf(SavedPlace(UUID.randomUUID().toString(), name, type, x, y, z, world)) + places)
    fun deletePlace(id: String) = savePlaces(places.filter { it.id != id })

    // ---------- add-ons ----------
    fun importAddons(uris: List<Uri>) = job(Msg(R.string.busy_import)) {
        var n = 0; var dup = 0; var failure: String? = null
        uris.forEach { u ->
            try {
                val c = addonRepo.import(u)
                if (c < 0) dup++ else n += c
            } catch (e: Exception) { failure = e.message ?: "import" }
        }
        addons = addonRepo.load()
        val f = failure
        if (f != null && n == 0 && dup == 0) Msg(R.string.err, f) else Msg(R.string.msg_addons_imported, n, dup)
    }

    fun deleteAddon(a: Addon) = job(Msg(R.string.busy_scan)) { addonRepo.delete(a); addons = addonRepo.load(); Msg(R.string.msg_deleted) }
    fun addonFile(a: Addon): File = addonRepo.fileOf(a)
    fun addonIcon(a: Addon): File? = addonRepo.iconOf(a)

    private fun loadAcols(): Map<String, Set<String>> {
        return try {
            val o = JSONObject(prefs.getString("acol", "{}") ?: "{}")
            val m = LinkedHashMap<String, Set<String>>()
            for (k in o.keys()) {
                val a = o.getJSONArray(k)
                m[k] = (0 until a.length()).map { a.getString(it) }.toSet()
            }
            m
        } catch (e: Exception) { emptyMap() }
    }

    private fun saveAcols(m: Map<String, Set<String>>) {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, JSONArray(v.toList())) }
        prefs.edit().putString("acol", o.toString()).apply()
        acols = m
    }

    fun addCollection(name: String) { if (name.isNotBlank() && name !in acols) saveAcols(acols + (name.trim() to emptySet())) }
    fun deleteCollection(name: String) = saveAcols(acols - name)
    fun toggleInCollection(name: String, id: String) {
        val cur = acols[name] ?: emptySet()
        saveAcols(acols + (name to (if (id in cur) cur - id else cur + id)))
    }

    fun ensurePacks() {
        val todo = rows.filter { it.backups.isNotEmpty() && it.id !in packRefs }
        if (todo.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val add = HashMap<String, List<PackRef>>()
            for (r in todo) add[r.id] = runCatching { worldPacks(repo.file(r.backups.first())) }.getOrDefault(emptyList())
            packRefs = packRefs + add
        }
    }

    // ---------- atlas ----------
    fun loadAtlas(id: String, force: Boolean = false) {
        val r = rows.find { it.id == id } ?: return
        val b = r.backups.firstOrNull() ?: run { toast = Msg(R.string.atlas_need_backup); return }
        if (!force && atlas[id] != null) return
        if (atlasLoading) return
        atlasLoading = true
        atlasProgress = 0f
        atlasError = null
        val cache = File(getApplication<Application>().cacheDir, "atlas_" + b.sha.take(16) + ".bin")
        if (force) cache.delete()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val a = Atlas.build(repo.file(b), cache) { done, total -> atlasProgress = if (total == 0) 0f else done.toFloat() / total }
                atlas = atlas + (id to a)
            } catch (e: Exception) {
                atlasError = e.message ?: e.javaClass.simpleName
            }
            atlasLoading = false
        }
    }

    // ---------- reports ----------
    fun runReport(id: String) {
        val r = rows.find { it.id == id } ?: return
        val b = r.backups.firstOrNull() ?: run { toast = Msg(R.string.atlas_need_backup); return }
        if (reportBusy) return
        reportBusy = true
        report = null
        val mc = installedMc(getApplication())
        viewModelScope.launch(Dispatchers.IO) {
            report = try { buildReport(repo, b, addons, mc) } catch (e: Exception) { null }
            reportBusy = false
        }
    }

    fun ensureStats(bs: List<Backup>) {
        val todo = bs.filter { it.id !in zstats }
        if (todo.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            val add = HashMap<String, ZipStat>()
            for (b in todo) runCatching { add[b.id] = zipStat(repo.file(b)) }
            if (add.isNotEmpty()) zstats = zstats + add
        }
    }

    // ---------- journal & screenshots ----------
    fun journalOf(id: String): List<Pair<Long, String>> {
        if (meta < 0) return emptyList()
        return try {
            val a = JSONArray(prefs.getString("jr_" + id, "[]") ?: "[]")
            (0 until a.length()).map { val o = a.getJSONObject(it); o.getLong("t") to o.getString("x") }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveJournal(id: String, l: List<Pair<Long, String>>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("t", it.first).put("x", it.second)) }
        prefs.edit().putString("jr_" + id, a.toString()).apply()
        meta += 1
    }

    fun addJournal(id: String, text: String) {
        if (text.isBlank()) return
        saveJournal(id, listOf(System.currentTimeMillis() to text.trim()) + journalOf(id))
    }

    fun deleteJournal(id: String, t: Long) = saveJournal(id, journalOf(id).filter { it.first != t })

    fun shotsOf(backupId: String): List<String> {
        if (meta < 0) return emptyList()
        return try {
            val a = JSONArray(prefs.getString("shots_" + backupId, "[]") ?: "[]")
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) { emptyList() }
    }

    fun shotFile(name: String): File = File(File(getApplication<Application>().getExternalFilesDir(null) ?: getApplication<Application>().filesDir, "shots"), name)

    fun addShot(backupId: String, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val dir = shotFile("x").parentFile ?: return@launch
                dir.mkdirs()
                val name = backupId.take(8) + "_" + System.currentTimeMillis() + ".jpg"
                getApplication<Application>().contentResolver.openInputStream(uri)?.use { i -> File(dir, name).outputStream().use { o -> i.copyTo(o) } }
                val cur = shotsOf(backupId)
                val a = JSONArray((cur + name).toList())
                prefs.edit().putString("shots_" + backupId, a.toString()).apply()
                meta += 1
            } catch (e: Exception) {
                toast = Msg(R.string.err, e.message ?: "image")
            }
        }
    }

    // ---------- servers ----------
    private fun loadServers(): List<ServerProfile> {
        return try {
            val a = JSONArray(prefs.getString("servers", "[]") ?: "[]")
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                ServerProfile(o.getString("id"), o.getString("n"), o.getString("h"), o.getString("p"), o.optString("v", ""), o.optString("x", ""))
            }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveServers(l: List<ServerProfile>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("n", it.name).put("h", it.host).put("p", it.port).put("v", it.version).put("x", it.notes)) }
        prefs.edit().putString("servers", a.toString()).apply()
        servers = l
    }

    fun addServer(name: String, host: String, port: String, version: String, notes: String) =
        saveServers(listOf(ServerProfile(UUID.randomUUID().toString(), name, host, port, version, notes)) + servers)
    fun deleteServer(id: String) = saveServers(servers.filter { it.id != id })

    // ---------- privacy & lock ----------
    fun changeBio(v: Boolean) { bio = v; prefs.edit().putBoolean("bio", v).apply() }
    fun changeLockTimeout(i: Int) { lockTimeout = i; prefs.edit().putInt("lockto", i).apply() }

    private var bgAt = 0L
    fun markBackground() { bgAt = System.currentTimeMillis() }
    fun relockIfNeeded() {
        if (!pinSet || locked || bgAt == 0L) return
        val ms = when (lockTimeout) { 0 -> 0L; 1 -> 60_000L; 2 -> 300_000L; else -> Long.MAX_VALUE }
        if (System.currentTimeMillis() - bgAt >= ms) locked = true
    }
    fun unlockBio() { locked = false }

    fun clearLocalNotes() {
        val e = prefs.edit()
        prefs.all.keys.filter { it.startsWith("note_") || it.startsWith("tags_") || it.startsWith("jr_") || it.startsWith("shots_") }.forEach { e.remove(it) }
        e.remove("seeds").remove("places").remove("servers").apply()
        seeds = emptyList(); places = emptyList(); servers = emptyList()
        meta += 1
    }

    // ---------- favorite commands ----------
    var favCmds by mutableStateOf(loadFavCmds()); private set

    private fun loadFavCmds(): List<String> {
        return try {
            val a = JSONArray(prefs.getString("favcmds", "[]") ?: "[]")
            (0 until a.length()).map { a.getString(it) }
        } catch (e: Exception) { emptyList() }
    }

    private fun saveFavCmds(l: List<String>) {
        prefs.edit().putString("favcmds", JSONArray(l).toString()).apply()
        favCmds = l
    }

    fun addFavCmd(c: String) { if (c !in favCmds) saveFavCmds(listOf(c) + favCmds) }
    fun deleteFavCmd(c: String) = saveFavCmds(favCmds.filter { it != c })
}
