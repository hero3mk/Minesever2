package app.minesaver

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File
import java.security.MessageDigest

class MainVm(app: Application) : AndroidViewModel(app) {
    private val repo = Repo(app)
    private val prefs = app.getSharedPreferences("ms", 0)

    var backups by mutableStateOf(repo.load()); private set
    var live by mutableStateOf(emptyList<LiveWorld>()); private set
    var bad by mutableStateOf(emptySet<String>()); private set
    var busy by mutableStateOf<Msg?>(null); private set
    var toast by mutableStateOf<Msg?>(null)
    var pick by mutableStateOf<String?>(null)
    var theme by mutableIntStateOf(prefs.getInt("theme", 0)); private set
    var auto by mutableStateOf(prefs.getBoolean("auto", true)); private set
    var src by mutableStateOf(prefs.getString("src", null)); private set
    var safe by mutableStateOf(prefs.getString("safe", null)); private set

    /** 0 = Shizuku not installed, 1 = installed but not running, 2 = running, needs permission, 3 = ready */
    var sz by mutableIntStateOf(0); private set
    var szOn by mutableStateOf(prefs.getBoolean("szOn", false)); private set
    val szActive: Boolean get() = sz == 3 && szOn
    val canWriteGame: Boolean get() = szActive || src != null

    private val onBinder = Shizuku.OnBinderReceivedListener { refreshSz() }
    private val onDead = Shizuku.OnBinderDeadListener { refreshSz() }
    private val onPerm = Shizuku.OnRequestPermissionResultListener { _, _ -> refreshSz() }

    init {
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(onBinder)
            Shizuku.addBinderDeadListener(onDead)
            Shizuku.addRequestPermissionResultListener(onPerm)
        }
        refreshSz()
    }

    override fun onCleared() {
        runCatching {
            Shizuku.removeBinderReceivedListener(onBinder)
            Shizuku.removeBinderDeadListener(onDead)
            Shizuku.removeRequestPermissionResultListener(onPerm)
        }
    }

    fun refreshSz() {
        val installed = runCatching { getApplication<Application>().packageManager.getPackageInfo(Sz.PKG, 0); true }.getOrDefault(false)
        sz = when {
            Sz.ready() -> 3
            Sz.running() -> 2
            installed -> 1
            else -> 0
        }
        if (sz == 3 && !prefs.contains("szOn")) changeSzOn(true)
    }

    var diag by mutableStateOf<String?>(null)
    var log by mutableStateOf(repo.logLoad()); private set
    var favs by mutableStateOf<Set<String>>(prefs.getStringSet("fav", emptySet())?.toSet() ?: emptySet()); private set
    var anim by mutableStateOf(prefs.getBoolean("anim", true)); private set
    var bg by mutableStateOf(prefs.getBoolean("bg", true)); private set
    var accent by mutableIntStateOf(prefs.getInt("accent", 0)); private set
    var pinSet by mutableStateOf(prefs.contains("pin")); private set
    var locked by mutableStateOf(prefs.contains("pin")); private set
    fun runDiag() = job(Msg(R.string.busy_scan)) { diag = try { Sz.diagnose() } catch (e: Exception) { e.message ?: "error" }; null }
    fun requestSz() = Sz.request()
    fun changeSzOn(v: Boolean) { szOn = v; prefs.edit().putBoolean("szOn", v).apply() }

    val rows: List<WorldRow>
        get() {
            val ids = (live.map { it.id } + backups.map { it.worldId }).distinct()
            return ids.map { id ->
                val l = live.find { it.id == id }
                val bs = backups.filter { it.worldId == id }.sortedByDescending { it.time }
                WorldRow(id, l?.name ?: bs.first().worldName, l?.mode ?: bs.first().mode, l, bs)
            }.sortedBy { it.name.lowercase() }
        }

    fun file(b: Backup): File = repo.file(b)
    fun iconFile(worldId: String): File = repo.icon(worldId)

    private fun job(m: Msg, block: () -> Msg?) {
        if (busy != null) { toast = Msg(R.string.busy_wait); return }
        busy = m
        viewModelScope.launch {
            val r = withContext(Dispatchers.IO) {
                val x = try { block() } catch (e: Exception) { Msg(R.string.err, e.message ?: e.javaClass.simpleName) }
                if (x != null) repo.logAdd(x)
                x
            }
            backups = repo.load()
            log = repo.logLoad()
            if (r != null) toast = r
            busy = null
        }
    }

    private fun doScan(): Msg? {
        var err: Msg? = null
        live = when {
            szActive -> try { Sz.listWorlds() } catch (e: Exception) { err = Msg(R.string.msg_sz_fail, e.message ?: "?"); emptyList() }
            src != null -> runCatching { repo.scan(Uri.parse(src!!)) }.getOrDefault(emptyList())
            else -> emptyList()
        }
        return err
    }

    private fun backupMany(ws: List<LiveWorld>): Msg? {
        if (ws.isEmpty()) return null
        var ok = 0; var fail = 0; var mirrorFail = 0
        var lastErr: String? = null
        ws.forEach { w ->
            try {
                val b = repo.backupLive(w)
                ok++
                safe?.let { if (!repo.mirror(b, Uri.parse(it))) mirrorFail++ }
            } catch (e: Exception) { fail++; lastErr = e.message }
        }
        backups = repo.load()
        val le = lastErr
        return when {
            fail > 0 && ok == 0 && le != null -> Msg(R.string.err, le)
            fail > 0 -> Msg(R.string.msg_backed_part, ok, fail)
            mirrorFail > 0 -> Msg(R.string.msg_mirror_fail)
            else -> Msg(R.string.msg_backed, ok)
        }
    }

    fun appStarted() {
        if ((src == null && !szActive) || busy != null) return
        job(Msg(R.string.busy_scan)) {
            val e = doScan()
            if (e != null) e else if (auto) backupMany(live.filter { w -> rows.find { it.id == w.id }?.changed == true }) else null
        }
    }

    fun rescan() = job(Msg(R.string.busy_scan)) {
        val e = doScan()
        if (e != null) e else if (live.isEmpty() && szActive) Msg(R.string.msg_none_sz) else Msg(R.string.msg_scanned, live.size)
    }
    fun backupNow(w: LiveWorld) = job(Msg(R.string.busy_backup)) { backupMany(listOf(w)) }
    fun backupWorlds(ws: List<LiveWorld>) = job(Msg(R.string.busy_backup)) { backupMany(ws) ?: Msg(R.string.msg_no_worlds) }
    fun backupAll() = job(Msg(R.string.busy_backup)) {
        val e = doScan()
        if (e != null) e else backupMany(live) ?: Msg(R.string.msg_no_worlds)
    }

    private fun importCore(uris: List<Uri>, mirror: Boolean): Msg {
        var n = 0; var dup = 0; var failure: String? = null
        uris.forEach { u ->
            try {
                val (b, isNew) = repo.importMcworld(u)
                if (isNew) { n++; if (mirror) safe?.let { repo.mirror(b, Uri.parse(it)) } } else dup++
            } catch (e: Exception) { failure = e.message ?: "import" }
        }
        backups = repo.load()
        val f = failure
        return if (f != null && n == 0 && dup == 0) Msg(R.string.err, f) else Msg(R.string.msg_imported, n, dup)
    }

    fun import(uris: List<Uri>) = job(Msg(R.string.busy_import)) { importCore(uris, true) }

    fun importSafe() {
        val s = safe ?: run { toast = Msg(R.string.msg_no_safe); return }
        job(Msg(R.string.busy_import)) { importCore(repo.listMcworlds(Uri.parse(s)), false) }
    }

    fun restoreToGame(b: Backup) {
        if (szActive) {
            job(Msg(R.string.busy_restore)) { val n = repo.restoreViaShizuku(b); doScan(); Msg(R.string.msg_restored, n) }
            return
        }
        val s = src ?: run { toast = Msg(R.string.msg_no_src); return }
        job(Msg(R.string.busy_restore)) { val n = repo.restoreToTree(b, Uri.parse(s)); doScan(); Msg(R.string.msg_restored, n) }
    }

    fun exportTo(b: Backup, u: Uri) = job(Msg(R.string.busy_export)) { repo.exportTo(b, u); Msg(R.string.msg_exported) }

    fun verifyAll() = job(Msg(R.string.busy_verify)) {
        val ids = backups.filter { !repo.verify(it) }.map { it.id }.toSet()
        bad = ids
        if (ids.isEmpty()) Msg(R.string.msg_verify_ok, backups.size) else Msg(R.string.msg_verify_bad, ids.size)
    }

    fun verifyOne(b: Backup) = job(Msg(R.string.busy_verify)) {
        val ok = repo.verify(b)
        bad = if (ok) bad - b.id else bad + b.id
        if (ok) Msg(R.string.msg_verify_ok, 1) else Msg(R.string.msg_verify_bad, 1)
    }

    fun deleteBackups(list: List<Backup>) = job(Msg(R.string.busy_scan)) { repo.delete(list); Msg(R.string.msg_deleted) }
    fun deleteWorlds(ids: Set<String>) = job(Msg(R.string.busy_scan)) { repo.delete(backups.filter { it.worldId in ids }); Msg(R.string.msg_deleted) }

    private fun grant(u: Uri) {
        runCatching {
            getApplication<Application>().contentResolver.takePersistableUriPermission(
                u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
    }

    fun changeTheme(i: Int) { theme = i; prefs.edit().putInt("theme", i).apply() }
    fun changeAuto(v: Boolean) { auto = v; prefs.edit().putBoolean("auto", v).apply() }
    fun setSrc(u: Uri?) {
        u?.let { grant(it) }
        src = u?.toString(); prefs.edit().putString("src", src).apply()
        if (u != null) rescan() else live = emptyList()
    }
    fun setSafe(u: Uri?) {
        u?.let { grant(it) }
        safe = u?.toString(); prefs.edit().putString("safe", safe).apply()
    }

    private fun hashPin(p: String) =
        MessageDigest.getInstance("SHA-256").digest(("minesaver:" + p).toByteArray()).joinToString("") { "%02x".format(it) }

    fun unlock(p: String): Boolean {
        val ok = prefs.getString("pin", null) == hashPin(p)
        if (ok) locked = false
        return ok
    }

    fun setPin(p: String?) {
        if (p == null) prefs.edit().remove("pin").apply() else prefs.edit().putString("pin", hashPin(p)).apply()
        pinSet = p != null
    }

    fun toggleFav(id: String) {
        favs = if (id in favs) favs - id else favs + id
        prefs.edit().putStringSet("fav", favs.toSet()).apply()
    }

    fun changeAnim(v: Boolean) { anim = v; prefs.edit().putBoolean("anim", v).apply() }
    fun changeBg(v: Boolean) { bg = v; prefs.edit().putBoolean("bg", v).apply() }
    fun changeAccent(i: Int) { accent = i; prefs.edit().putInt("accent", i).apply() }
    fun clearLog() { repo.logClear(); log = emptyList() }

    fun oldCopies(keep: Int): List<Backup> =
        backups.groupBy { it.worldId }.flatMap { (_, l) -> l.sortedByDescending { it.time }.drop(keep) }

    fun tempSize(): Long = repo.tempFiles().sumOf { it.length() }
    fun cleanTemp() = job(Msg(R.string.busy_scan)) { repo.tempFiles().forEach { it.delete() }; Msg(R.string.msg_temp_cleaned) }
}
