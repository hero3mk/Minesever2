package app.minesaver

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

private class Feat(val center: String, val name: String, val code: Char)

private val FEATS: List<Feat> by lazy {
    FEATURE_DATA.trim().lines().mapNotNull { l ->
        val p = l.split("|")
        if (p.size == 3) Feat(p[0], p[1], p[2][0]) else null
    }
}

private fun statusRes(c: Char) = when (c) {
    'F' -> R.string.fs_f; 'P' -> R.string.fs_p; 'N' -> R.string.fs_n; 'A' -> R.string.fs_a; 'B' -> R.string.fs_b; else -> R.string.fs_e
}

@Composable
private fun statusColor(c: Char) = when (c) {
    'F' -> Green; 'P' -> Amber; 'N' -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.secondary
}

@Composable
fun FeatureStatusScreen(vm: MainVm, nav: NavController) {
    var filter by remember { mutableStateOf<Char?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val counts = FEATS.groupingBy { it.code }.eachCount()
    val shown = FEATS.filter { filter == null || it.code == filter }
    val centers = shown.map { it.center }.distinct()
    Page(R.string.title_status, onBack = { nav.popBackStack() }) {
        item { Glass { Text(stringResource(R.string.fs_intro), style = MaterialTheme.typography.bodySmall, color = dim) } }
        item {
            Acts {
                TagChip(stringResource(R.string.tag_all) + " " + FEATS.size, filter == null) { filter = null }
                listOf('F', 'P', 'N', 'A', 'B', 'E').forEach { c ->
                    val n = counts[c] ?: 0
                    if (n > 0) TagChip(stringResource(statusRes(c)) + " " + n, filter == c) { filter = if (filter == c) null else c }
                }
            }
        }
        centers.forEach { center ->
            item {
                Glass {
                    SectionTitle(center, Icons.Rounded.Info)
                    shown.filter { it.center == center }.forEach { f ->
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(f.name, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Spacer(Modifier.height(0.dp))
                            Badge(stringResource(statusRes(f.code)), statusColor(f.code))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChangelogScreen(vm: MainVm, nav: NavController) {
    Page(R.string.title_changelog, onBack = { nav.popBackStack() }) {
        listOf(R.string.cl_400, R.string.cl_310, R.string.cl_300, R.string.cl_200).forEach { r ->
            item { Glass { Text(stringResource(r), style = MaterialTheme.typography.bodyMedium) } }
        }
    }
}
