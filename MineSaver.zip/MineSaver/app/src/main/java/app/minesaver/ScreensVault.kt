package app.minesaver

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.PowerManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipFile

// ---------- Recently deleted ----------
@Composable
fun TrashScreen(vm: MainVm, nav: NavController) {
    var empty by remember { mutableStateOf(false) }
    var purge by remember { mutableStateOf<Repo.TrashItem?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val err = MaterialTheme.colorScheme.error
    Page(R.string.title_trash, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.tr_intro), color = dim) }
        if (vm.trash.isEmpty()) {
            item { Glass { Text(stringResource(R.string.tr_empty)) } }
        } else {
            item { Acts { Act(R.string.tr_empty_btn, Icons.Rounded.Delete, err) { empty = true } } }
            itemsIndexed(vm.trash.sortedByDescending { it.at }, key = { _, t -> t.b.id }) { i, t ->
                Appear(i) {
                    Glass {
                        Text(t.b.worldName, style = MaterialTheme.typography.titleMedium)
                        Text(fmtDate(t.b.time) + " · " + fmtSize(t.b.size), style = MaterialTheme.typography.bodySmall, color = dim)
                        Text(stringResource(R.string.tr_deleted_at, fmtDate(t.at)), style = MaterialTheme.typography.bodySmall, color = dim)
                        Spacer(Modifier.height(8.dp))
                        Acts {
                            Act(R.string.a_restore, Icons.Rounded.Restore) { vm.restoreTrash(t) }
                            Act(R.string.tr_forever, Icons.Rounded.Delete, err) { purge = t }
                        }
                    }
                }
            }
        }
    }
    if (empty) ConfirmDialog(stringResource(R.string.tr_empty_q, vm.trash.size), { vm.emptyTrash(); empty = false }, { empty = false })
    purge?.let { t -> ConfirmDialog(stringResource(R.string.tr_forever_q), { vm.purgeTrash(t); purge = null }, { purge = null }) }
}

// ---------- Compare two backups ----------
@Composable
fun CompareBackupsScreen(vm: MainVm, nav: NavController) {
    var a by remember { mutableStateOf<String?>(null) }
    var b by remember { mutableStateOf<String?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val list = vm.backups.sortedByDescending { it.time }
    val ba = list.find { it.id == a }
    val bb = list.find { it.id == b }
    Page(R.string.title_cmpb, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.cb_intro), color = dim) }
        item {
            Glass {
                Text(stringResource(R.string.cmp_pick_a), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Acts { list.take(20).forEach { x -> TagChip(x.worldName + " · " + fmtDate(x.time), x.id == a) { a = x.id } } }
                Spacer(Modifier.height(12.dp))
                Text(stringResource(R.string.cmp_pick_b), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Acts { list.take(20).forEach { x -> TagChip(x.worldName + " · " + fmtDate(x.time), x.id == b) { b = x.id } } }
                Spacer(Modifier.height(10.dp))
                if (ba != null && bb != null && ba.id != bb.id) {
                    val older = if (ba.time <= bb.time) ba else bb
                    val newer = if (ba.time <= bb.time) bb else ba
                    Acts { Act(R.string.cb_run, Icons.Rounded.Refresh) { vm.compareBackups(older, newer) } }
                }
            }
        }
        val d = vm.cmpDiff
        if (d != null) {
            item {
                Glass {
                    SectionTitle(stringResource(R.string.cb_files), Icons.Rounded.Info)
                    Spacer(Modifier.height(8.dp))
                    DetailRow(R.string.cb_added, d.added.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.cb_removed, d.removed.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.cb_changed, d.changed.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.cb_same, d.same.toString())
                }
            }
            for ((titleRes, names) in listOf(R.string.cb_added to d.added, R.string.cb_removed to d.removed, R.string.cb_changed to d.changed)) {
                if (names.isNotEmpty()) item {
                    Glass {
                        Text(stringResource(titleRes), fontWeight = FontWeight.Bold)
                        names.take(60).forEach { Text(it, style = MaterialTheme.typography.bodySmall, color = dim, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp)) }
                        if (names.size > 60) Text(stringResource(R.string.fi_more, names.size - 60), color = dim, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            val inf = vm.cmpInfos
            if (inf != null) item {
                val dash = stringResource(R.string.none_dash)
                val pa = inf.first
                val pb = inf.second
                Glass {
                    SectionTitle(stringResource(R.string.cb_meta), Icons.Rounded.Info)
                    CompareRow(R.string.r_version, pa?.version ?: dash, pb?.version ?: dash)
                    CompareRow(R.string.r_difficulty, pa?.difficulty?.let { diffName(it) } ?: dash, pb?.difficulty?.let { diffName(it) } ?: dash)
                    CompareRow(R.string.d_mode, pa?.gameType?.let { modeName(it) } ?: dash, pb?.gameType?.let { modeName(it) } ?: dash)
                    CompareRow(R.string.r_days, pa?.ticks?.let { (it / 24000L).toString() } ?: dash, pb?.ticks?.let { (it / 24000L).toString() } ?: dash)
                    CompareRow(R.string.r_spawn, pa?.spawn ?: dash, pb?.spawn ?: dash)
                    CompareRow(R.string.r_cheats, pa?.cheats?.let { yesNo(it) } ?: dash, pb?.cheats?.let { yesNo(it) } ?: dash)
                    CompareRow(R.string.r_seed, pa?.seed?.toString() ?: dash, pb?.seed?.toString() ?: dash)
                }
            }
        }
    }
}

// ---------- ZIP explorer ----------
private class Preview(val name: String, val text: String?, val image: androidx.compose.ui.graphics.ImageBitmap?, val size: Long, val crc: Long)

private fun makePreview(f: File, name: String): Preview? = ZipFile(f).use { z ->
    val e = z.getEntry(name) ?: return null
    val ext = name.substringAfterLast('.', "").lowercase()
    val size = maxOf(e.size, 0L)
    if (ext in setOf("png", "jpg", "jpeg") && size in 1L..3_000_000L) {
        val b = z.getInputStream(e).use { it.readBytes() }
        return Preview(name, null, BitmapFactory.decodeByteArray(b, 0, b.size)?.asImageBitmap(), size, e.crc)
    }
    if (ext in setOf("txt", "json", "lang", "mcfunction", "properties", "js", "ts", "xml", "md", "cfg", "ini", "material", "fragment", "vertex", "mcmeta") || name.endsWith("manifest.json") || name == "levelname.txt") {
        val b = z.getInputStream(e).use { s -> val buf = ByteArray(20000); val n = s.read(buf); if (n <= 0) ByteArray(0) else buf.copyOf(n) }
        return Preview(name, String(b, Charsets.UTF_8), null, size, e.crc)
    }
    return Preview(name, null, null, size, e.crc)
}

private fun extractTo(ctx: Context, f: File, names: Set<String>, tree: Uri): Int {
    val root = DocumentFile.fromTreeUri(ctx, tree) ?: return 0
    var n = 0
    var total = 0L
    ZipFile(f).use { z ->
        for (name in names) {
            val safe = safeEntryName(name) ?: continue
            val e = z.getEntry(name) ?: continue
            if (e.isDirectory || e.size > 1_000_000_000L) continue
            total += maxOf(e.size, 0L)
            if (total > 2_000_000_000L) break
            val parts = safe.split('/')
            var cur: DocumentFile = root
            for (p in parts.dropLast(1)) cur = cur.findFile(p) ?: cur.createDirectory(p) ?: return n
            val out = cur.createFile("application/octet-stream", parts.last()) ?: continue
            ctx.contentResolver.openOutputStream(out.uri)?.use { o -> z.getInputStream(e).use { it.copyTo(o) } }
            n++
        }
    }
    return n
}

@Composable
fun ExplorerScreen(vm: MainVm, nav: NavController) {
    val f = vm.exFile
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var entries by remember(f) { mutableStateOf<List<Pair<String, Long>>?>(null) }
    var err by remember(f) { mutableStateOf<String?>(null) }
    var q by remember { mutableStateOf("") }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var bySize by remember { mutableStateOf(false) }
    var prev by remember { mutableStateOf<Preview?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    LaunchedEffect(f) {
        if (f != null) {
            try {
                entries = withContext(Dispatchers.IO) {
                    ZipFile(f).use { z -> z.entries().asSequence().filter { !it.isDirectory }.map { it.name to maxOf(it.size, 0L) }.take(20000).toList() }
                }
            } catch (e: Exception) { err = e.message ?: "error" }
        }
    }
    val pickDir = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null && f != null) {
            val chosen = sel
            scope.launch {
                val n = withContext(Dispatchers.IO) { runCatching { extractTo(ctx, f, chosen, u) }.getOrDefault(0) }
                vm.toast = Msg(R.string.ex_done, n)
            }
        }
    }
    Page(R.string.title_explorer, onBack = { nav.popBackStack() }) {
        if (f == null) { item { Glass { Text(stringResource(R.string.ex_none)) } }; return@Page }
        item { Text(vm.exTitle.ifBlank { f.name }, style = MaterialTheme.typography.titleMedium) }
        item { Text(stringResource(R.string.ex_note), style = MaterialTheme.typography.bodySmall, color = dim) }
        item {
            Acts {
                Act(R.string.ex_check, Icons.Rounded.VerifiedUser) { vm.checkFile(f) }
                if (sel.isNotEmpty()) Act(stringResource(R.string.ex_extract, sel.size), Icons.Rounded.FileUpload) { pickDir.launch(null) }
                if (sel.isNotEmpty()) Act(R.string.a_select_none, Icons.Rounded.Refresh) { sel = emptySet() }
                Act(if (bySize) R.string.ex_by_name else R.string.ex_by_size, Icons.Rounded.Info) { bySize = !bySize }
            }
        }
        item {
            OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.ex_search)) })
        }
        err?.let { e -> item { Text(e, color = MaterialTheme.colorScheme.error) } }
        val all = entries
        if (all == null && err == null) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        if (all != null) {
            val shown = all.filter { q.isBlank() || it.first.contains(q, true) }.let { l -> if (bySize) l.sortedByDescending { it.second } else l }
            item { Text(stringResource(R.string.ex_count, shown.size, all.size), style = MaterialTheme.typography.bodySmall, color = dim) }
            itemsIndexed(shown.take(400)) { _, e ->
                Row(
                    Modifier.fillMaxWidth().clickable {
                        scope.launch { prev = withContext(Dispatchers.IO) { runCatching { makePreview(f, e.first) }.getOrNull() } }
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(e.first in sel, { sel = if (it) sel + e.first else sel - e.first })
                    Column(Modifier.weight(1f)) {
                        Text(e.first, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Text(fmtSize(e.second), style = MaterialTheme.typography.labelSmall, color = dim)
                    }
                }
            }
            if (shown.size > 400) item { Text(stringResource(R.string.fi_more, shown.size - 400), color = dim) }
        }
    }
    prev?.let { p ->
        AlertDialog(
            onDismissRequest = { prev = null },
            title = { Text(p.name.substringAfterLast('/'), maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Text(fmtSize(p.size) + " · CRC " + java.lang.Long.toHexString(p.crc), style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                    if (p.image != null) Image(p.image, null, Modifier.fillMaxWidth())
                    else if (p.text != null) Text(p.text, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    else Text(stringResource(R.string.ex_nopreview), color = dim)
                }
            },
            confirmButton = { TextButton({ prev = null }) { Text(stringResource(R.string.a_close)) } }
        )
    }
}

// ---------- Data protection center ----------
@Composable
fun DataProtectionScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val err = MaterialTheme.colorScheme.error
    var dropDlg by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm.backups.size) { vm.refreshIntegrity() }
    val saveCfg = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u: Uri? -> if (u != null) vm.exportConfig(u) }
    val openCfg = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) vm.importConfig(u) }
    val ig = vm.integrity
    val canR = fun(u: String?): Boolean = u != null && runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(u))?.canRead() == true }.getOrDefault(false)
    val canW = fun(u: String?): Boolean = u != null && runCatching { DocumentFile.fromTreeUri(ctx, Uri.parse(u))?.canWrite() == true }.getOrDefault(false)
    val battery = runCatching { (ctx.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(ctx.packageName) }.getOrDefault(false)
    Page(R.string.title_dataprot, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.dp_intro), color = dim) }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dp_integrity), Icons.Rounded.VerifiedUser)
                Spacer(Modifier.height(8.dp))
                if (ig == null) LinearProgressIndicator(Modifier.fillMaxWidth())
                else {
                    DetailRow(R.string.dp_indexed, vm.backups.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.dp_missing, ig.missing.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.dp_orphans, ig.orphans.size.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.dp_parts, ig.parts.size.toString())
                    if (ig.indexBad) Text(stringResource(R.string.dp_indexbad), color = err, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        if (ig.orphans.isNotEmpty()) Act(R.string.dp_rebuild, Icons.Rounded.Restore) { vm.rebuildIndex() }
                        if (ig.missing.isNotEmpty()) Act(R.string.dp_drop, Icons.Rounded.Delete, err) { dropDlg = true }
                        if (ig.parts.isNotEmpty()) Act(R.string.dp_clean, Icons.Rounded.Delete) { vm.cleanParts() }
                        Act(R.string.a_recheck, Icons.Rounded.Refresh) { vm.refreshIntegrity() }
                    }
                }
                Text(stringResource(R.string.dp_integrity_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dp_access), Icons.Rounded.FolderOpen)
                Spacer(Modifier.height(8.dp))
                val rows = listOf(
                    R.string.dp_a_shizuku to vm.szActive,
                    R.string.dp_a_src to canR(vm.src),
                    R.string.dp_a_safe to canW(vm.safe),
                    R.string.dp_a_notif to Notifier.can(ctx),
                    R.string.dp_a_battery to battery
                )
                rows.forEach { r ->
                    Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                        Text(stringResource(r.first), Modifier.weight(1f))
                        Text(stringResource(if (r.second) R.string.v_yes else R.string.v_no), color = if (r.second) Green else Amber, fontWeight = FontWeight.SemiBold)
                    }
                }
                Text(stringResource(R.string.dp_access_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dp_config), Icons.Rounded.CloudUpload)
                Text(stringResource(R.string.dp_config_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                Acts {
                    Act(R.string.dp_export, Icons.Rounded.FileUpload) { saveCfg.launch("minesaver-config.json") }
                    Act(R.string.dp_import, Icons.Rounded.FolderOpen) { openCfg.launch(arrayOf("*/*")) }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dp_diag), Icons.Rounded.Info)
                Spacer(Modifier.height(8.dp))
                Acts {
                    Act(R.string.dp_diag_make, Icons.Rounded.Refresh) { report = vm.diagnostics(ctx) }
                }
                report?.let { r ->
                    Text(r, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_share, Icons.Rounded.Share) {
                            ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, r), null))
                        }
                    }
                }
            }
        }
        item { Glass { Text(stringResource(R.string.dp_flow), style = MaterialTheme.typography.bodySmall, color = dim) } }
    }
    if (dropDlg) ConfirmDialog(stringResource(R.string.dp_drop_q, ig?.missing?.size ?: 0), { vm.dropMissing(); dropDlg = false }, { dropDlg = false })
}

// ---------- Automation ----------
@Composable
fun AutomationScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.changeNotifyDone(true) else vm.toast = Msg(R.string.au_notif_denied)
    }
    val last = vm.lastAuto()
    Page(R.string.title_automation, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.au_intro), color = dim) }
        item {
            Glass {
                SwitchRow(R.string.au_on, vm.autoOn) { vm.changeAutoOn(it) }
                Text(stringResource(R.string.au_every), color = dim, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
                Segment(listOf(stringResource(R.string.au_h6), stringResource(R.string.au_h12), stringResource(R.string.au_h24)), vm.autoHours) { vm.changeAutoHours(it) }
                SwitchRow(R.string.au_charging, vm.autoCharging) { vm.changeAutoCharging(it) }
                Text(stringResource(R.string.au_rules), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(10.dp))
                Acts { Act(R.string.au_run, Icons.Rounded.Refresh) { vm.runAutoNow() } }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.au_notify), Icons.Rounded.Info)
                SwitchRow(R.string.au_notify_done, vm.notifyDone) {
                    if (it && !Notifier.can(ctx)) perm.launch("android.permission.POST_NOTIFICATIONS") else vm.changeNotifyDone(it)
                }
                SwitchRow(R.string.au_notify_low, vm.notifyLow) { vm.changeNotifyLow(it) }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.au_status), Icons.Rounded.VerifiedUser)
                Spacer(Modifier.height(8.dp))
                if (last.first == 0L) Text(stringResource(R.string.au_never), color = dim)
                else {
                    DetailRow(R.string.au_last, fmtDate(last.first))
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.au_ok, last.second.toString())
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.au_fail, last.third.toString())
                }
                Text(stringResource(R.string.au_limits), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item { SectionTitle(stringResource(R.string.au_history), Icons.Rounded.Info) }
        if (vm.log.isEmpty()) item { Text(stringResource(R.string.act_empty), color = dim) }
        vm.log.take(15).forEach { e -> item { Glass { LogLine(e) } } }
    }
}

// ---------- Encryption ----------
@Composable
fun EncryptScreen(vm: MainVm, nav: NavController) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var pick by remember { mutableStateOf<String?>(null) }
    var pw1 by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var inPw by remember { mutableStateOf("") }
    var inUri by remember { mutableStateOf<Uri?>(null) }
    val list = vm.backups.sortedByDescending { it.time }
    val chosen = list.find { it.id == pick }
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u: Uri? ->
        if (u != null && chosen != null) { vm.exportEncrypted(chosen, u, pw1.toCharArray()); pw1 = ""; pw2 = "" }
    }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) { inUri = u; inPw = "" } }
    Page(R.string.title_encrypt, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.enc_intro), color = dim) }
        item {
            Glass {
                SectionTitle(stringResource(R.string.enc_export), Icons.Rounded.Lock)
                Spacer(Modifier.height(8.dp))
                Acts { list.take(20).forEach { x -> TagChip(x.worldName + " · " + fmtDate(x.time), x.id == pick) { pick = x.id } } }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(pw1, { pw1 = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.enc_pw)) }, visualTransformation = PasswordVisualTransformation())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(pw2, { pw2 = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.enc_pw2)) }, visualTransformation = PasswordVisualTransformation())
                if (pw1.isNotEmpty() && pw1 != pw2) Text(stringResource(R.string.enc_mismatch), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                if (pw1.isNotEmpty() && pw1.length < 8) Text(stringResource(R.string.enc_short), color = Amber, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(10.dp))
                if (chosen != null && pw1.length >= 8 && pw1 == pw2) Acts { Act(R.string.enc_go, Icons.Rounded.FileUpload) { save.launch(chosen.file + ".mse") } }
                Text(stringResource(R.string.enc_warn), style = MaterialTheme.typography.bodySmall, color = Amber, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.enc_import), Icons.Rounded.FolderOpen)
                Spacer(Modifier.height(8.dp))
                Acts { Act(R.string.fi_pick, Icons.Rounded.FolderOpen) { open.launch(arrayOf("*/*")) } }
            }
        }
    }
    inUri?.let { u ->
        AlertDialog(
            onDismissRequest = { inUri = null },
            title = { Text(stringResource(R.string.enc_import)) },
            text = { OutlinedTextField(inPw, { inPw = it }, singleLine = true, label = { Text(stringResource(R.string.enc_pw)) }, visualTransformation = PasswordVisualTransformation()) },
            confirmButton = { TextButton({ if (inPw.isNotEmpty()) { vm.importEncrypted(u, inPw.toCharArray()); inUri = null } }) { Text(stringResource(R.string.a_done)) } },
            dismissButton = { TextButton({ inUri = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

// ---------- Migration assistant ----------
@Composable
fun MigrationScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    var sel by remember { mutableStateOf(setOf<String>()) }
    val worlds = vm.rows.filter { it.backups.isNotEmpty() }
    val chosen = worlds.filter { it.id in sel }
    LaunchedEffect(sel, vm.backups.size, vm.infos.size) { vm.ensureInfo(sel.toList()) }
    val mc = remember { installedMc(ctx) }
    Page(R.string.title_migration, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.mg_intro), color = dim) }
        if (worlds.isEmpty()) item { Glass { Text(stringResource(R.string.backups_empty)) } }
        itemsIndexed(worlds, key = { _, w -> w.id }) { i, w ->
            Appear(i) {
                Glass(Modifier.clickable { sel = if (w.id in sel) sel - w.id else sel + w.id }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(w.id in sel, { sel = if (it) sel + w.id else sel - w.id })
                        Column(Modifier.weight(1f)) {
                            Text(w.name, style = MaterialTheme.typography.titleMedium)
                            Text(fmtDate(w.backups.first().time) + " · " + fmtSize(w.backups.first().size), style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                    }
                }
            }
        }
        if (chosen.isNotEmpty()) {
            item {
                Glass {
                    SectionTitle(stringResource(R.string.mg_check), Icons.Rounded.VerifiedUser)
                    chosen.forEach { w ->
                        val b = w.backups.first()
                        val info = vm.infos[w.id]
                        val wv = verParts(info?.version)
                        val mv = verParts(mc)
                        val newer = wv != null && mv != null && verCmp(mv, wv) < 0
                        Column(Modifier.padding(top = 10.dp)) {
                            Text(w.name, fontWeight = FontWeight.SemiBold)
                            Text(fmtSize(b.size) + " · SHA-256 " + b.sha.take(12), style = MaterialTheme.typography.bodySmall, color = dim)
                            if (newer) Text(stringResource(R.string.handoff_warn, info?.version ?: "", mc ?: ""), color = Amber, style = MaterialTheme.typography.bodySmall)
                            if (w.id in vm.bad) Text(stringResource(R.string.b_bad), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        Act(R.string.mg_share, Icons.Rounded.Share) {
                            val uris = ArrayList<Uri>()
                            chosen.forEach { uris.add(FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.file(it.backups.first()))) }
                            val i = Intent(Intent.ACTION_SEND_MULTIPLE).setType("application/octet-stream")
                                .putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            runCatching { ctx.startActivity(Intent.createChooser(i, null)) }
                            vm.logNote(Msg(R.string.mg_logged, chosen.size))
                        }
                        Act(R.string.mg_copy, Icons.Rounded.Share) {
                            val t = chosen.joinToString("\n") { it.name + " | " + it.backups.first().file + " | " + it.backups.first().sha }
                            clip.setText(AnnotatedString(t)); vm.toast = Msg(R.string.copied, "SHA-256")
                        }
                    }
                }
            }
        }
        item { Glass { Text(stringResource(R.string.mg_steps), style = MaterialTheme.typography.bodySmall, color = dim) } }
    }
}
