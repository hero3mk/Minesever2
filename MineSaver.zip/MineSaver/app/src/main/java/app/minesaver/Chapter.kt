package app.minesaver

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Dream(val id: String, val title: String, val note: String, val date: String, val done: Boolean, val archived: Boolean)
data class Milestone(val id: String, val date: String, val text: String)
data class PNote(val id: String, val cat: String, val title: String, val text: String, val at: Long)
data class ChapterData(
    val story: String = "", val msg: String? = null, val dreams: List<Dream> = emptyList(),
    val plans: String = "", val goals: String = "", val learn: String = "", val achieve: String = "",
    val timeline: List<Milestone> = emptyList(), val notes: List<PNote> = emptyList()
)

/** Local-only storage for the private section. AES-256-GCM, key held in the Android Keystore, file in internal storage. */
object ChapterStore {
    private const val ALIAS = "ms_private_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256).build()
        )
        return g.generateKey()
    }

    private fun file(ctx: Context) = File(ctx.filesDir, "chapter.bin")

    private fun toJson(d: ChapterData): JSONObject = JSONObject()
        .put("story", d.story).put("msg", d.msg ?: JSONObject.NULL)
        .put("plans", d.plans).put("goals", d.goals).put("learn", d.learn).put("achieve", d.achieve)
        .put("dreams", JSONArray().also { a -> d.dreams.forEach { a.put(JSONObject().put("id", it.id).put("t", it.title).put("n", it.note).put("d", it.date).put("x", it.done).put("a", it.archived)) } })
        .put("timeline", JSONArray().also { a -> d.timeline.forEach { a.put(JSONObject().put("id", it.id).put("d", it.date).put("t", it.text)) } })
        .put("notes", JSONArray().also { a -> d.notes.forEach { a.put(JSONObject().put("id", it.id).put("c", it.cat).put("t", it.title).put("x", it.text).put("at", it.at)) } })

    private fun fromJson(o: JSONObject): ChapterData {
        fun arr(k: String): JSONArray = o.optJSONArray(k) ?: JSONArray()
        return ChapterData(
            story = o.optString("story"), msg = if (o.isNull("msg")) null else o.optString("msg"),
            dreams = (0 until arr("dreams").length()).map { arr("dreams").getJSONObject(it).let { j -> Dream(j.getString("id"), j.optString("t"), j.optString("n"), j.optString("d"), j.optBoolean("x"), j.optBoolean("a")) } },
            plans = o.optString("plans"), goals = o.optString("goals"), learn = o.optString("learn"), achieve = o.optString("achieve"),
            timeline = (0 until arr("timeline").length()).map { arr("timeline").getJSONObject(it).let { j -> Milestone(j.getString("id"), j.optString("d"), j.optString("t")) } },
            notes = (0 until arr("notes").length()).map { arr("notes").getJSONObject(it).let { j -> PNote(j.getString("id"), j.optString("c"), j.optString("t"), j.optString("x"), j.optLong("at")) } }
        )
    }

    @Synchronized
    fun load(ctx: Context): ChapterData {
        val f = file(ctx)
        if (!f.exists()) return ChapterData()
        return try {
            val raw = f.readBytes()
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            fromJson(JSONObject(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)))
        } catch (e: Exception) {
            f.renameTo(File(ctx.filesDir, "chapter.unreadable"))
            ChapterData()
        }
    }

    @Synchronized
    fun save(ctx: Context, d: ChapterData) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(toJson(d).toString().toByteArray(Charsets.UTF_8))
        val tmp = File(ctx.filesDir, "chapter.tmp")
        tmp.writeBytes(out)
        if (!tmp.renameTo(file(ctx))) { file(ctx).delete(); tmp.renameTo(file(ctx)) }
    }

    @Synchronized
    fun wipe(ctx: Context) {
        file(ctx).delete()
        File(ctx.filesDir, "chapter.unreadable").delete()
        File(ctx.filesDir, "chapter.tmp").delete()
        runCatching { KeyStore.getInstance("AndroidKeyStore").apply { load(null) }.deleteEntry(ALIAS) }
    }
}
