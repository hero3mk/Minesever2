package app.minesaver

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

data class AddonDep(val uuid: String?, val module: String?, val version: String)

data class Addon(
    val id: String, val uuid: String, val name: String, val desc: String, val kind: String,
    val version: String, val minEngine: String, val deps: List<AddonDep>, val authors: String,
    val file: String, val size: Long, val sha: String, val time: Long, val issues: List<String>, val icon: String
)

class Manifest(
    val name: String, val desc: String, val uuid: String, val version: String, val minEngine: String,
    val kind: String, val deps: List<AddonDep>, val authors: String
) {
    var icon: ByteArray? = null
}

class ScanResult(val manifests: List<Manifest>, val issues: List<String>)

/** kind: 0 same uuid, other version/file, 1 missing dependency, 2 dependency version too low */
data class Conflict(val kind: Int, val a: String, val b: String)

fun verParts(v: String?): IntArray? {
    if (v.isNullOrBlank()) return null
    val l = v.split('.', '-', '+').mapNotNull { it.takeWhile { c -> c.isDigit() }.toIntOrNull() }
    return if (l.isEmpty()) null else l.toIntArray()
}

fun verCmp(a: IntArray, b: IntArray): Int {
    val n = maxOf(a.size, b.size)
    for (i in 0 until n) {
        val x = if (i < a.size) a[i] else 0
        val y = if (i < b.size) b[i] else 0
        if (x != y) return if (x < y) -1 else 1
    }
    return 0
}

private fun verString(x: Any?): String = when (x) {
    is JSONArray -> (0 until x.length()).joinToString(".") { x.optString(it) }
    is String -> x
    else -> ""
}

fun parseManifest(text: String): Manifest? {
    return try {
        val o = JSONObject(text.removePrefix("\uFEFF"))
        val h = o.getJSONObject("header")
        val uuid = h.getString("uuid").lowercase()
        var kind = "other"
        val mods = o.optJSONArray("modules")
        if (mods != null) {
            for (i in 0 until mods.length()) {
                val t = mods.optJSONObject(i)?.optString("type") ?: continue
                if (t == "resources") kind = "resource"
                else if (t == "skin_pack") kind = "skin"
                else if (t == "world_template") kind = "template"
                else if (kind == "other" && (t == "data" || t == "script" || t == "client_data" || t == "interface" || t == "javascript")) kind = "behavior"
            }
        }
        val deps = ArrayList<AddonDep>()
        val da = o.optJSONArray("dependencies")
        if (da != null) {
            for (i in 0 until da.length()) {
                val d = da.optJSONObject(i) ?: continue
                deps.add(
                    AddonDep(
                        d.optString("uuid").takeIf { it.isNotEmpty() }?.lowercase(),
                        d.optString("module_name").takeIf { it.isNotEmpty() },
                        verString(d.opt("version"))
                    )
                )
            }
        }
        val authors = o.optJSONObject("metadata")?.optJSONArray("authors")?.let { a ->
            (0 until a.length()).joinToString(", ") { a.optString(it) }
        } ?: ""
        Manifest(
            h.optString("name", "?"), h.optString("description", ""), uuid, verString(h.opt("version")),
            verString(h.opt("min_engine_version")), kind, deps, authors
        )
    } catch (e: Exception) {
        null
    }
}

private val EXEC_EXT = setOf("exe", "apk", "dex", "so", "sh", "bat", "cmd", "jar", "dll", "msi", "scr")

fun readLimited(ins: InputStream, limit: Int): ByteArray? {
    val out = ByteArrayOutputStream()
    val buf = ByteArray(8192)
    var total = 0
    while (true) {
        val r = ins.read(buf)
        if (r < 0) break
        total += r
        if (total > limit) return null
        out.write(buf, 0, r)
    }
    return out.toByteArray()
}

private fun unsafePath(n: String) = n.startsWith("/") || n.contains("..") || n.contains("\\")

/** Reads an add-on archive WITHOUT extracting or running anything. Issues are "severity|code|argument". */
fun scanAddon(f: File): ScanResult {
    val issues = ArrayList<String>()
    val mans = ArrayList<Manifest>()
    ZipFile(f).use { z ->
        if (z.size() > 20000) {
            issues.add("2|too_many|" + z.size())
            return ScanResult(emptyList(), issues)
        }
        var total = 0L
        val names = HashSet<String>()
        for (e in z.entries().asSequence().toList()) {
            val n = e.name
            total += maxOf(e.size, 0L)
            if (unsafePath(n)) issues.add("2|path|" + n.take(80))
            if (!names.add(n)) issues.add("1|dup|" + n.take(80))
            val ext = n.substringAfterLast('.', "").lowercase()
            if (ext in EXEC_EXT) issues.add("2|exec|" + n.take(80))
            if (e.isDirectory) continue
            if (n.lowercase().endsWith("manifest.json") && n.count { it == '/' } <= 3) {
                val b = z.getInputStream(e).use { readLimited(it, 1_000_000) }
                val m = if (b == null) null else parseManifest(String(b, Charsets.UTF_8))
                if (m == null) issues.add("2|badman|" + n.take(80)) else {
                    val prefix = n.substring(0, n.length - "manifest.json".length)
                    val ic = z.getEntry(prefix + "pack_icon.png")
                    if (ic != null && ic.size in 1L..600_000L) m.icon = z.getInputStream(ic).use { readLimited(it, 600_000) }
                    mans.add(m)
                }
            }
            if ((ext == "mcpack" || ext == "zip" || ext == "mcaddon") && e.size in 1L..300_000_000L) {
                ZipInputStream(z.getInputStream(e)).use { zi ->
                    var ne = zi.nextEntry
                    var guard = 0
                    while (ne != null && guard++ < 5000) {
                        val nn = ne.name
                        if (unsafePath(nn)) issues.add("2|path|" + nn.take(80))
                        if (nn.substringAfterLast('.', "").lowercase() in EXEC_EXT) issues.add("2|exec|" + nn.take(80))
                        if (!ne.isDirectory && nn.lowercase().endsWith("manifest.json") && nn.count { it == '/' } <= 3) {
                            val b = readLimited(zi, 1_000_000)
                            val m = if (b == null) null else parseManifest(String(b, Charsets.UTF_8))
                            if (m == null) issues.add("2|badman|" + nn.take(80)) else mans.add(m)
                        }
                        ne = zi.nextEntry
                    }
                }
            }
        }
        if (total > 2_000_000_000L) issues.add("2|toolarge|" + total)
    }
    if (mans.isEmpty()) issues.add("2|noman|")
    return ScanResult(mans, issues.distinct().take(30))
}

class AddonRepo(private val ctx: Context) {
    val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "addons").apply { mkdirs() }
    private val icons = File(dir, "icons").apply { mkdirs() }
    private val index = File(dir, "index.json")

    fun fileOf(a: Addon) = File(dir, a.file)
    fun iconOf(a: Addon): File? = if (a.icon.isEmpty()) null else File(icons, a.icon)

    fun load(): List<Addon> {
        if (!index.exists()) return emptyList()
        return try {
            val a = JSONArray(index.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val da = o.getJSONArray("deps")
                val deps = (0 until da.length()).map { k ->
                    val d = da.getJSONObject(k)
                    AddonDep(d.optString("u").takeIf { it.isNotEmpty() }, d.optString("m").takeIf { it.isNotEmpty() }, d.optString("v"))
                }
                val ia = o.getJSONArray("issues")
                Addon(
                    o.getString("id"), o.getString("uuid"), o.getString("name"), o.getString("desc"), o.getString("kind"),
                    o.getString("ver"), o.getString("min"), deps, o.getString("authors"), o.getString("file"),
                    o.getLong("size"), o.getString("sha"), o.getLong("time"), (0 until ia.length()).map { ia.getString(it) }, o.optString("icon", "")
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(l: List<Addon>) {
        val a = JSONArray()
        l.forEach {
            val d = JSONArray()
            it.deps.forEach { x -> d.put(JSONObject().put("u", x.uuid ?: "").put("m", x.module ?: "").put("v", x.version)) }
            a.put(
                JSONObject().put("id", it.id).put("uuid", it.uuid).put("name", it.name).put("desc", it.desc).put("kind", it.kind)
                    .put("ver", it.version).put("min", it.minEngine).put("deps", d).put("authors", it.authors).put("file", it.file)
                    .put("size", it.size).put("sha", it.sha).put("time", it.time).put("issues", JSONArray(it.issues)).put("icon", it.icon)
            )
        }
        val t = File(dir, "index.tmp")
        t.writeText(a.toString())
        if (!t.renameTo(index)) throw IOException("Could not save add-on index")
    }

    private fun nameOf(uri: Uri): String {
        val n = runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull()
        return n ?: "addon.mcpack"
    }

    /** Returns the number of packs added, or -1 if this exact file is already in the library. */
    fun import(uri: Uri): Int {
        val tmp = File(dir, "import_${System.nanoTime()}.part")
        try {
            var total = 0L
            (ctx.contentResolver.openInputStream(uri) ?: throw IOException("Cannot read file")).use { i ->
                tmp.outputStream().use { o ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val r = i.read(buf)
                        if (r < 0) break
                        total += r
                        if (total > 1_500_000_000L) throw IOException("File is too large")
                        o.write(buf, 0, r)
                    }
                }
            }
            val sha = sha256(tmp)
            val cur = load()
            if (cur.any { it.sha == sha }) { tmp.delete(); return -1 }
            val res = try { scanAddon(tmp) } catch (e: Exception) { throw IOException("Not a valid add-on archive") }
            if (res.manifests.isEmpty()) throw IOException("No manifest.json found, so this is not a valid pack")
            val fname = sha.take(8) + "_" + safeName(nameOf(uri))
            val dest = File(dir, fname)
            if (!tmp.renameTo(dest)) throw IOException("Could not store the file")
            val added = res.manifests.map { m ->
                var iconName = ""
                val ib = m.icon
                if (ib != null) {
                    iconName = sha.take(8) + "_" + m.uuid.take(8) + ".png"
                    runCatching { File(icons, iconName).writeBytes(ib) }
                }
                Addon(
                    m.uuid + "@" + m.version, m.uuid, m.name, m.desc, m.kind, m.version, m.minEngine, m.deps, m.authors,
                    fname, dest.length(), sha, System.currentTimeMillis(), res.issues, iconName
                )
            }
            save(cur + added)
            return added.size
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    fun delete(a: Addon) {
        val rest = load().filter { it.id != a.id || it.file != a.file }
        save(rest)
        if (rest.none { it.file == a.file }) File(dir, a.file).delete()
        iconOf(a)?.let { ic -> if (rest.none { it.icon == a.icon }) ic.delete() }
    }
}

// ---------- analysis (pure functions) ----------
/** 0 missing, 1 satisfied, 2 present but version too low, 3 provided by the game engine (cannot be checked) */
fun depState(d: AddonDep, all: List<Addon>): Int {
    if (d.uuid == null) return 3
    val found = all.filter { it.uuid == d.uuid }
    if (found.isEmpty()) return 0
    val need = verParts(d.version) ?: return 1
    return if (found.any { val v = verParts(it.version); v == null || verCmp(v, need) >= 0 }) 1 else 2
}

fun conflictsOf(all: List<Addon>): List<Conflict> {
    val out = ArrayList<Conflict>()
    all.groupBy { it.uuid }.forEach { (_, l) ->
        if (l.map { it.file }.distinct().size > 1) out.add(Conflict(0, l.first().name, l.joinToString(", ") { it.version }))
    }
    all.forEach { a ->
        a.deps.forEach { d ->
            val s = depState(d, all)
            if (s == 0) out.add(Conflict(1, a.name, d.uuid ?: ""))
            if (s == 2) out.add(Conflict(2, a.name, (d.uuid ?: "") + " " + d.version))
        }
    }
    return out.distinct()
}

/** 0 unknown, 1 meets the declared minimum engine version, 2 below the minimum */
fun compatOf(a: Addon, mc: IntArray?): Int {
    val need = verParts(a.minEngine) ?: return 0
    if (mc == null) return 0
    return if (verCmp(mc, need) >= 0) 1 else 2
}

fun installedMc(ctx: Context): String? =
    runCatching { ctx.packageManager.getPackageInfo("com.mojang.minecraftpe", 0).versionName }.getOrNull()
