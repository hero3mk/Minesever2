package app.minesaver

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.text.format.DateUtils
import android.widget.RemoteViews
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb

/** Builds the three home screen widgets (2x2, 4x2, 4x4) from the theme the user chose. Panels rotate with a fade animation. */
object WidgetUpdater {
    private val kinds = listOf(WidgetSmall::class.java, WidgetMedium::class.java, WidgetLarge::class.java)

    fun refreshAll(ctx: Context) {
        runCatching {
            val m = AppWidgetManager.getInstance(ctx)
            kinds.forEachIndexed { k, c -> for (id in m.getAppWidgetIds(ComponentName(ctx, c))) m.updateAppWidget(id, build(ctx, k)) }
        }
    }

    private fun pi(ctx: Context, code: Int, route: String? = null, backup: Boolean = false): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (route != null) i.putExtra("route", route)
        if (backup) i.putExtra("quick_backup", true)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun background(w: Int, h: Int, look: Look): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val r = minOf(w, h) * 0.12f
        val rect = RectF(0f, 0f, w.toFloat(), h.toFloat())
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), look.bg[0].toArgb(), look.bg[1].toArgb(), Shader.TileMode.CLAMP)
        c.drawRoundRect(rect, r, r, p)
        c.save()
        val path = Path()
        path.addRoundRect(rect, r, r, Path.Direction.CW)
        c.clipPath(path)
        val g = Paint(Paint.ANTI_ALIAS_FLAG)
        g.shader = RadialGradient(w * 0.85f, 0f, w * 0.75f, look.accent.copy(alpha = if (look.dark) 0.34f else 0.22f).toArgb(), 0, Shader.TileMode.CLAMP)
        c.drawRect(rect, g)
        val g2 = Paint(Paint.ANTI_ALIAS_FLAG)
        g2.shader = RadialGradient(0f, h.toFloat(), w * 0.6f, look.accent2.copy(alpha = if (look.dark) 0.18f else 0.12f).toArgb(), 0, Shader.TileMode.CLAMP)
        c.drawRect(rect, g2)
        c.restore()
        val b = Paint(Paint.ANTI_ALIAS_FLAG)
        b.style = Paint.Style.STROKE
        b.strokeWidth = 2f
        b.color = look.text.copy(alpha = 0.10f).toArgb()
        c.drawRoundRect(RectF(1f, 1f, w - 1f, h - 1f), r, r, b)
        return bmp
    }

    private fun ring(size: Int, pct: Int, color: Int, track: Int): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val s = size.toFloat()
        val sw = s * 0.11f
        val rect = RectF(sw / 2, sw / 2, s - sw / 2, s - sw / 2)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = sw
        p.strokeCap = Paint.Cap.ROUND
        p.color = track
        c.drawArc(rect, 0f, 360f, false, p)
        p.color = color
        if (pct > 0) c.drawArc(rect, -90f, 360f * pct.coerceIn(0, 100) / 100f, false, p)
        return bmp
    }

    private fun button(w: Int, h: Int, a: Int, b: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, w.toFloat(), 0f, a, b, Shader.TileMode.CLAMP)
        Canvas(bmp).drawRoundRect(RectF(0f, 0f, w.toFloat(), h.toFloat()), h / 2f, h / 2f, p)
        return bmp
    }

    fun build(ctx: Context, kind: Int): RemoteViews {
        val look = lookFromPrefs(ctx)
        val p = ctx.getSharedPreferences("ms", 0)
        val worlds = p.getInt("wWorlds", 0)
        val prot = p.getInt("wProtected", 0)
        val count = p.getInt("wCount", 0)
        val bytes = p.getLong("wBytes", 0L)
        val last = p.getLong("lastBackup", 0L)
        val fail = p.getInt("lastAutoFail", 0)
        val sz = p.getBoolean("wSz", false)
        val log = p.getString("wlog", "") ?: ""
        val pct = if (worlds == 0) 0 else prot * 100 / worlds
        val txt = look.text.toArgb()
        val dim = look.textDim.toArgb()
        val acc = look.accent.toArgb()
        val warn = Color(0xFFFFC857).toArgb()
        val onAcc = look.onAccent.toArgb()
        val v = RemoteViews(ctx.packageName, when (kind) { 0 -> R.layout.widget_small; 1 -> R.layout.widget_medium; else -> R.layout.widget_large })
        fun t(id: Int, s: String, color: Int) { v.setTextViewText(id, s); v.setTextColor(id, color) }
        val (bw, bh) = when (kind) { 0 -> 360 to 360; 1 -> 720 to 360; else -> 640 to 640 }
        v.setImageViewBitmap(R.id.w_bg, background(bw, bh, look))
        v.setImageViewBitmap(R.id.w_ring, ring(240, pct, if (fail > 0) warn else acc, look.text.copy(alpha = 0.14f).toArgb()))
        t(R.id.w_pct, "$pct%", txt)
        t(R.id.w_title, ctx.getString(R.string.app_name), txt)
        t(R.id.w_status, if (fail > 0) ctx.getString(R.string.wd_failed) else ctx.getString(R.string.wd_status, prot, worlds), if (fail > 0) warn else dim)
        t(R.id.w_storage, ctx.getString(R.string.wd_storage, fmtSize(bytes), count), dim)
        t(R.id.w_last_label, ctx.getString(R.string.wd_last), dim)
        val lastText = if (last == 0L) ctx.getString(R.string.wd_never) else DateUtils.getRelativeTimeSpanString(last, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS).toString()
        t(R.id.w_last, lastText, txt)
        t(R.id.w_sz, ctx.getString(if (sz) R.string.wd_sz_on else R.string.wd_sz_off), if (sz) acc else dim)
        t(R.id.w_log_label, ctx.getString(R.string.wd_ops), dim)
        t(R.id.w_log, if (log.isBlank()) ctx.getString(R.string.wd_no_ops) else log, txt)
        t(R.id.w_extra, ctx.getString(R.string.wd_tip), dim)
        val bt = button(300, 84, acc, look.accent2.toArgb())
        for (id in listOf(R.id.w_btn_bg, R.id.w_b1_bg, R.id.w_b2_bg, R.id.w_b3_bg)) v.setImageViewBitmap(id, bt)
        t(R.id.w_btn, ctx.getString(R.string.wd_btn), onAcc)
        t(R.id.w_b1, ctx.getString(R.string.wd_btn), onAcc)
        t(R.id.w_b2, ctx.getString(R.string.nav_worlds), onAcc)
        t(R.id.w_b3, ctx.getString(R.string.wd_tools), onAcc)
        val k = kind * 10
        v.setOnClickPendingIntent(R.id.w_root, pi(ctx, k + 1))
        for (id in listOf(R.id.w_btn, R.id.w_btn_bg, R.id.w_b1, R.id.w_b1_bg)) v.setOnClickPendingIntent(id, pi(ctx, k + 2, backup = true))
        for (id in listOf(R.id.w_b2, R.id.w_b2_bg)) v.setOnClickPendingIntent(id, pi(ctx, k + 3, route = "worlds"))
        for (id in listOf(R.id.w_b3, R.id.w_b3_bg)) v.setOnClickPendingIntent(id, pi(ctx, k + 4, route = "more"))
        return v
    }
}

open class BaseWidget(private val kind: Int) : AppWidgetProvider() {
    override fun onUpdate(context: Context, m: AppWidgetManager, ids: IntArray) {
        for (id in ids) m.updateAppWidget(id, WidgetUpdater.build(context, kind))
    }

    override fun onAppWidgetOptionsChanged(context: Context, m: AppWidgetManager, id: Int, newOptions: android.os.Bundle?) {
        m.updateAppWidget(id, WidgetUpdater.build(context, kind))
    }
}

class WidgetSmall : BaseWidget(0)
class WidgetMedium : BaseWidget(1)
class WidgetLarge : BaseWidget(2)
