package app.minesaver

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.zip.ZipFile

// ---------- More hub ----------
@Composable
fun MoreScreen(vm: MainVm, nav: NavController) {
    Page(R.string.nav_more) {
        item { SectionTitle(stringResource(R.string.more_manage), Icons.Rounded.Extension) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.nav_addons, Icons.Rounded.Extension, Modifier.weight(1f)) { nav.navigate("addons") }
                    Tile(R.string.a_storage, Icons.Rounded.Storage, Modifier.weight(1f)) { nav.navigate("storage") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.a_activity, Icons.Rounded.History, Modifier.weight(1f)) { nav.navigate("activity") }
                    Tile(R.string.title_recovery, Icons.Rounded.Restore, Modifier.weight(1f)) { nav.navigate("recovery") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.a_transfer, Icons.Rounded.CloudUpload, Modifier.weight(1f)) { nav.navigate("transfer") }
                    Tile(R.string.title_servers, Icons.Rounded.Storage, Modifier.weight(1f)) { nav.navigate("servers") }
                }
            }
        }
        item { SectionTitle(stringResource(R.string.more_create), Icons.Rounded.Build) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_studio, Icons.Rounded.Build, Modifier.weight(1f)) { nav.navigate("studio") }
                    Tile(R.string.nav_tools, Icons.Rounded.Build, Modifier.weight(1f)) { nav.navigate("tools") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_assistant, Icons.Rounded.Lightbulb, Modifier.weight(1f)) { nav.navigate("assistant") }
                    Tile(R.string.title_atlas_map, Icons.Rounded.Map, Modifier.weight(1f)) { nav.navigate("atlas") }
                }
            }
        }
        item { SectionTitle(stringResource(R.string.more_security), Icons.Rounded.Lock) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_privacy, Icons.Rounded.Lock, Modifier.weight(1f)) { nav.navigate("privacy") }
                    Tile(R.string.nav_settings, Icons.Rounded.Settings, Modifier.weight(1f)) { nav.navigate("settings") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.title_help, Icons.Rounded.Lightbulb, Modifier.weight(1f)) { nav.navigate("help") }
                    Tile(R.string.title_about, Icons.Rounded.Info, Modifier.weight(1f)) { nav.navigate("about") }
                }
            }
        }
    }
}

// ---------- World identity, health, evolution ----------
@Composable
fun FindingRow(f: Finding) {
    val col = when (f.sev) { 2 -> MaterialTheme.colorScheme.error; 1 -> Amber; else -> Green }
    Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.Top) {
        Box(Modifier.padding(top = 7.dp).size(9.dp).clip(CircleShape).background(col))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(stringResource(f.title, f.detail), style = MaterialTheme.typography.bodyMedium)
            if (f.fix != R.string.rp_fix_none) {
                Text("→ " + stringResource(f.fix), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun ShotThumb(vm: MainVm, name: String) {
    val bmp = remember(name) {
        runCatching {
            val o = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeFile(vm.shotFile(name).path, o)?.asImageBitmap()
        }.getOrNull()
    }
    if (bmp != null) Image(bmp, null, Modifier.size(84.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
}

@Composable
fun DnaScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val id = vm.detailId
    val r = vm.rows.find { it.id == id }
    LaunchedEffect(id, vm.backups.size, vm.infos.size) { if (id != null) { vm.ensureInfo(listOf(id)); vm.ensurePacks() } }
    if (r == null) {
        Page(R.string.title_world, onBack = { nav.popBackStack() }) { item { Glass { Text(stringResource(R.string.world_gone)) } } }
        return
    }
    LaunchedEffect(r.id, vm.backups.size) { vm.ensureStats(r.backups) }
    val info = vm.infos[r.id]
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val prim = MaterialTheme.colorScheme.primary
    val dash = stringResource(R.string.none_dash)
    var shotFor by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        val b = shotFor
        if (u != null && b != null) vm.addShot(b, u)
    }
    var jtext by remember(r.id) { mutableStateOf("") }
    var jdel by remember { mutableStateOf<Long?>(null) }
    var handoff by remember { mutableStateOf(false) }
    val mc = remember { installedMc(ctx) }
    val packs = vm.packRefs[r.id] ?: emptyList()
    val journal = vm.journalOf(r.id)
    val byTime = r.backups.sortedBy { it.time }
    PageBase(r.name, { nav.popBackStack() }) {
        item {
            Appear(0) {
                Glass {
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        WorldIcon(vm, r.id, r.last, 72.dp)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(stringResource(R.string.dna_title), style = MaterialTheme.typography.titleMedium, color = prim)
                            val st = statusOf(r)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Badge(modeName(info?.gameType ?: r.mode), MaterialTheme.colorScheme.secondary)
                                Badge(st.first, st.second)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DetailRow(R.string.r_seed, info?.seed?.toString() ?: dash)
                        DetailRow(R.string.r_version, info?.version ?: dash)
                        DetailRow(R.string.r_difficulty, info?.difficulty?.let { diffName(it) } ?: dash)
                        DetailRow(R.string.r_hardcore, info?.hardcore?.let { yesNo(it) } ?: dash)
                        DetailRow(R.string.r_days, info?.ticks?.let { (it / 24000L).toString() } ?: dash)
                        DetailRow(R.string.r_played, info?.lastPlayed?.takeIf { it > 0 }?.let { fmtDate(it) } ?: dash)
                        DetailRow(R.string.dna_first, byTime.firstOrNull()?.let { fmtDate(it.time) } ?: dash)
                        DetailRow(R.string.d_size, sizeText(r))
                        DetailRow(R.string.r_backups, r.backups.size.toString())
                        DetailRow(R.string.r_sessions, (vm.sessions[r.id] ?: 0).toString())
                        DetailRow(R.string.dna_places, vm.places.count { it.world.equals(r.name, true) }.toString())
                    }
                    Spacer(Modifier.height(12.dp))
                    Acts {
                        Act(R.string.atlas_open_world, Icons.Rounded.Map) { vm.atlasWorld = r.id; nav.navigate("atlas") }
                        if (r.backups.isNotEmpty()) Act(R.string.a_handoff, Icons.Rounded.Share) { handoff = true }
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dna_packs), Icons.Rounded.Extension)
                if (r.backups.isEmpty()) Text(stringResource(R.string.dna_need_backup), color = dim, modifier = Modifier.padding(top = 8.dp))
                else if (packs.isEmpty()) Text(stringResource(R.string.dna_no_packs), color = dim, modifier = Modifier.padding(top = 8.dp))
                packs.forEach { p ->
                    val a = vm.addons.firstOrNull { it.uuid == p.uuid }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(a?.name ?: p.uuid.take(13), Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Badge(if (p.kind == "behavior") stringResource(R.string.ad_k_behavior) else stringResource(R.string.ad_k_resource), MaterialTheme.colorScheme.secondary)
                    }
                }
                Text(stringResource(R.string.dna_packs_note), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dna_evolution), Icons.Rounded.History)
                if (byTime.size < 2) Text(stringResource(R.string.dna_evo_need), color = dim, modifier = Modifier.padding(top = 8.dp))
                else {
                    val mx = byTime.maxOf { it.size }.coerceAtLeast(1L)
                    Canvas(Modifier.fillMaxWidth().height(110.dp).padding(top = 10.dp)) {
                        val n = byTime.size
                        val bw = size.width / (n * 1.5f)
                        byTime.forEachIndexed { i, b ->
                            val h = (b.size.toFloat() / mx) * size.height
                            drawRect(prim.copy(alpha = .85f), Offset(i * bw * 1.5f, size.height - h), Size(bw, h))
                        }
                    }
                }
                r.backups.forEachIndexed { i, b ->
                    val older = r.backups.getOrNull(i + 1)
                    val delta = if (older != null) b.size - older.size else 0L
                    val z = vm.zstats[b.id]
                    Column(Modifier.padding(top = 10.dp)) {
                        Text(fmtDate(b.time), style = MaterialTheme.typography.bodyMedium)
                        Text(
                            fmtSize(b.size) + (if (older != null) "  (" + (if (delta >= 0) "+" else "-") + fmtSize(Math.abs(delta)) + ")" else "") +
                                (if (z != null) "  ·  " + stringResource(R.string.dna_files, z.entries) else ""),
                            style = MaterialTheme.typography.bodySmall, color = dim
                        )
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dna_shots), Icons.Rounded.History)
                Text(stringResource(R.string.dna_shots_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                r.backups.take(6).forEach { b ->
                    val shots = vm.shotsOf(b.id)
                    Column(Modifier.padding(top = 10.dp)) {
                        Text(fmtDate(b.time), style = MaterialTheme.typography.bodyMedium)
                        if (shots.isNotEmpty()) {
                            LazyRow(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(shots) { n -> ShotThumb(vm, n) }
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Acts { Act(R.string.dna_add_shot, Icons.Rounded.Add) { shotFor = b.id; picker.launch("image/*") } }
                    }
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dna_health), Icons.Rounded.VerifiedUser)
                Text(stringResource(R.string.dna_health_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                Acts { Act(R.string.dna_run, Icons.Rounded.VerifiedUser) { vm.runReport(r.id) } }
                if (vm.reportBusy) {
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                }
                val rep = vm.report
                if (rep != null) {
                    rep.findings.forEach { FindingRow(it) }
                    val st = rep.stat
                    if (st != null) {
                        Spacer(Modifier.height(12.dp))
                        DetailRow(R.string.dna_files_label, st.entries.toString())
                        Spacer(Modifier.height(6.dp))
                        DetailRow(R.string.dna_unpacked, fmtSize(st.total))
                        Spacer(Modifier.height(6.dp))
                        DetailRow(R.string.dna_dbfiles, (st.ldb + st.logs).toString())
                    }
                    Text(stringResource(R.string.dna_scope), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.dna_journal), Icons.Rounded.Lightbulb)
                Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(jtext, { jtext = it }, Modifier.weight(1f), label = { Text(stringResource(R.string.dna_journal_hint)) })
                    IconButton(onClick = { vm.addJournal(r.id, jtext); jtext = "" }) { Icon(Icons.Rounded.Add, null) }
                }
                journal.forEach { e ->
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.Top) {
                        Column(Modifier.weight(1f)) {
                            Text(e.second, style = MaterialTheme.typography.bodyMedium)
                            Text(fmtDate(e.first), style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                        IconButton(onClick = { jdel = e.first }) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        }
    }
    jdel?.let { t -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deleteJournal(r.id, t); jdel = null }, { jdel = null }) }
    if (handoff) {
        val b = r.backups.firstOrNull()
        if (b != null) {
            val wv = verParts(info?.version)
            val mv = verParts(mc)
            val newer = wv != null && mv != null && verCmp(mv, wv) < 0
            AlertDialog(
                onDismissRequest = { handoff = false },
                title = { Text(stringResource(R.string.a_handoff)) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        DetailRow(R.string.d_size, fmtSize(b.size))
                        DetailRow(R.string.d_sha, b.sha.take(12))
                        DetailRow(R.string.r_version, info?.version ?: dash)
                        Text(stringResource(R.string.handoff_note), style = MaterialTheme.typography.bodySmall)
                        if (newer) Text(stringResource(R.string.handoff_warn, info?.version ?: "", mc ?: ""), color = Amber, style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton({ runCatching { shareBackup(ctx, vm, b) }; handoff = false }) { Text(stringResource(R.string.a_share)) } },
                dismissButton = { TextButton({ handoff = false }) { Text(stringResource(R.string.a_close)) } }
            )
        }
    }
}

// ---------- Recovery center ----------
@Composable
fun RecoveryScreen(vm: MainVm, nav: NavController) {
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val worlds = vm.rows.filter { it.backups.isNotEmpty() }
    Page(R.string.title_recovery, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.rec_intro), color = dim) }
        item {
            Glass {
                DetailRow(R.string.rec_total, vm.backups.size.toString())
                Spacer(Modifier.height(6.dp))
                DetailRow(R.string.rec_damaged, vm.bad.size.toString())
                Spacer(Modifier.height(10.dp))
                Acts { Act(R.string.a_verify_all, Icons.Rounded.VerifiedUser) { vm.verifyAll() } }
            }
        }
        if (worlds.isEmpty()) item { Text(stringResource(R.string.backups_empty), color = dim) }
        itemsIndexed(worlds, key = { _, w -> w.id }) { i, w ->
            val best = w.backups.firstOrNull { it.id !in vm.bad }
            Appear(i) {
                Glass {
                    Text(w.name, style = MaterialTheme.typography.titleMedium)
                    if (best == null) Text(stringResource(R.string.rec_none_ok), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp))
                    else {
                        Text(stringResource(R.string.rec_best, fmtDate(best.time), fmtSize(best.size)), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 6.dp))
                        Spacer(Modifier.height(8.dp))
                        Acts { Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = best.id; nav.navigate("restore") } }
                    }
                }
            }
        }
        item { Text(stringResource(R.string.rec_note), style = MaterialTheme.typography.bodySmall, color = dim) }
    }
}

// ---------- Privacy & security center ----------
@Composable
fun PrivacyScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val perms = remember {
        runCatching {
            ctx.packageManager.getPackageInfo(ctx.packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toList() ?: emptyList()
        }.getOrDefault(emptyList())
    }
    var clearDlg by remember { mutableStateOf(false) }
    Page(R.string.title_privacy, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                SectionTitle(stringResource(R.string.pv_stored), Icons.Rounded.Storage)
                listOf(R.string.pv_s1, R.string.pv_s2, R.string.pv_s3, R.string.pv_s4, R.string.pv_s5).forEach {
                    Text("• " + stringResource(it), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.pv_network), Icons.Rounded.Lock)
                val net = perms.contains("android.permission.INTERNET")
                Text(
                    stringResource(if (net) R.string.pv_net_yes else R.string.pv_net_no),
                    color = if (net) Amber else Green, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp)
                )
                Text(stringResource(R.string.pv_services), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 8.dp))
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.pv_access), Icons.Rounded.FolderOpen)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 10.dp)) {
                    DetailRow(R.string.sz_title, stringResource(if (vm.szActive) R.string.v_yes else R.string.v_no))
                    DetailRow(R.string.set_mc, stringResource(if (vm.src != null) R.string.v_yes else R.string.v_no))
                    DetailRow(R.string.set_safe, stringResource(if (vm.safe != null) R.string.v_yes else R.string.v_no))
                    DetailRow(R.string.set_dl, stringResource(if (vm.dl) R.string.v_yes else R.string.v_no))
                }
                Text(stringResource(R.string.pv_perms, perms.size), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                perms.forEach { Text(it.substringAfterLast('.'), style = MaterialTheme.typography.bodySmall, color = dim) }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.set_lock), Icons.Rounded.Lock)
                Text(stringResource(if (vm.pinSet) R.string.pv_lock_on else R.string.pv_lock_off), modifier = Modifier.padding(top = 8.dp))
                if (!vm.pinSet) Text(stringResource(R.string.pv_lock_need), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 6.dp))
                if (vm.pinSet) {
                    SwitchRow(R.string.pv_bio, vm.bio) { vm.changeBio(it) }
                    Text(stringResource(R.string.pv_timeout), color = dim, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
                    Segment(
                        listOf(stringResource(R.string.to_now), stringResource(R.string.to_1), stringResource(R.string.to_5), stringResource(R.string.to_never)),
                        vm.lockTimeout
                    ) { vm.changeLockTimeout(it) }
                }
                Spacer(Modifier.height(10.dp))
                Acts { Act(R.string.nav_settings, Icons.Rounded.Settings) { nav.navigate("settings") } }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.pv_delete), Icons.Rounded.Delete)
                Text(stringResource(R.string.pv_delete_hint), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(vertical = 8.dp))
                Acts {
                    Act(R.string.a_clear_log, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.clearLog() }
                    Act(R.string.pv_clear_notes, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { clearDlg = true }
                }
            }
        }
    }
    if (clearDlg) ConfirmDialog(stringResource(R.string.pv_clear_q), { vm.clearLocalNotes(); clearDlg = false }, { clearDlg = false })
}

// ---------- Studio ----------
@Composable
fun StudioScreen(vm: MainVm, nav: NavController) {
    Page(R.string.title_studio, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.st_intro), color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.st_manifest, Icons.Rounded.Build, Modifier.weight(1f)) { nav.navigate("manifest") }
                    Tile(R.string.st_inspect, Icons.Rounded.Info, Modifier.weight(1f)) { nav.navigate("inspect") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Tile(R.string.st_commands, Icons.Rounded.Build, Modifier.weight(1f)) { nav.navigate("tools") }
                    Tile(R.string.nav_addons, Icons.Rounded.Extension, Modifier.weight(1f)) { nav.navigate("addons") }
                }
            }
        }
    }
}

private fun isUuid(s: String) = Regex("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$").matches(s.trim())

private fun threeInts(s: String): List<Int>? {
    val p = s.trim().split(".")
    if (p.size != 3) return null
    val l = p.map { it.toIntOrNull() ?: return null }
    return if (l.any { it < 0 }) null else l
}

@Composable
fun ManifestBuilderScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(0) }
    var ver by remember { mutableStateOf("1.0.0") }
    var eng by remember { mutableStateOf("1.20.0") }
    var u1 by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var u2 by remember { mutableStateOf(UUID.randomUUID().toString()) }
    var dep by remember { mutableStateOf("") }
    var depVer by remember { mutableStateOf("1.0.0") }
    val vl = threeInts(ver)
    val el = threeInts(eng)
    val dl = threeInts(depVer)
    val errors = ArrayList<Int>()
    if (name.isBlank()) errors.add(R.string.mb_err_name)
    if (vl == null) errors.add(R.string.mb_err_version)
    if (el == null) errors.add(R.string.mb_err_engine)
    if (dep.isNotBlank() && !isUuid(dep)) errors.add(R.string.mb_err_dep)
    if (dep.isNotBlank() && dl == null) errors.add(R.string.mb_err_depver)
    val json = if (errors.isEmpty() && vl != null && el != null) {
        val o = JSONObject()
        o.put("format_version", 2)
        o.put("header", JSONObject().put("name", name.trim()).put("description", desc.trim()).put("uuid", u1)
            .put("version", JSONArray(vl)).put("min_engine_version", JSONArray(el)))
        o.put("modules", JSONArray().put(JSONObject().put("type", if (type == 0) "resources" else "data").put("uuid", u2).put("version", JSONArray(vl))))
        if (dep.isNotBlank() && dl != null) o.put("dependencies", JSONArray().put(JSONObject().put("uuid", dep.trim().lowercase()).put("version", JSONArray(dl))))
        o.toString(2)
    } else ""
    val save = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u: Uri? ->
        if (u != null) runCatching { ctx.contentResolver.openOutputStream(u)?.use { it.write(json.toByteArray()) } }
    }
    Page(R.string.st_manifest, onBack = { nav.popBackStack() }) {
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(desc, { desc = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.mb_desc)) })
                Spacer(Modifier.height(10.dp))
                Acts {
                    TagChip(stringResource(R.string.ad_k_resource), type == 0) { type = 0 }
                    TagChip(stringResource(R.string.ad_k_behavior), type == 1) { type = 1 }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(ver, { ver = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.r_version)) })
                    OutlinedTextField(eng, { eng = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.ad_min_engine)) })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(dep, { dep = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.mb_dep)) })
                if (dep.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(depVer, { depVer = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.mb_depver)) })
                }
                Spacer(Modifier.height(10.dp))
                Acts { Act(R.string.mb_regen, Icons.Rounded.Build) { u1 = UUID.randomUUID().toString(); u2 = UUID.randomUUID().toString() } }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.mb_output), Icons.Rounded.Info)
                if (errors.isNotEmpty()) {
                    errors.forEach { Text("• " + stringResource(it), color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp)) }
                } else {
                    Text(json, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(10.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(json)); vm.toast = Msg(R.string.copied, "manifest.json") }
                        Act(R.string.mb_save, Icons.Rounded.CloudUpload) { save.launch("manifest.json") }
                    }
                }
            }
        }
    }
}

class Inspect(
    val name: String, val size: Long, val entries: List<Pair<String, Long>>, val count: Int, val total: Long,
    val manifests: List<Manifest>, val issues: List<String>, val world: WorldInfo?, val err: String?
)

@Composable
fun InspectScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var res by remember { mutableStateOf<Inspect?>(null) }
    var busy by remember { mutableStateOf(false) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            busy = true
            scope.launch {
                res = withContext(Dispatchers.IO) { inspectUri(ctx, u) }
                busy = false
            }
        }
    }
    Page(R.string.st_inspect, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.fi_intro), color = dim) }
        item { Acts { Act(R.string.fi_pick, Icons.Rounded.FolderOpen) { pick.launch(arrayOf("*/*")) } } }
        if (busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()) }
        val x = res
        if (x != null) {
            item {
                Glass {
                    Text(x.name, style = MaterialTheme.typography.titleMedium)
                    Text(fmtSize(x.size), style = MaterialTheme.typography.bodySmall, color = dim)
                    if (x.err != null) Text(x.err, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                    else {
                        Spacer(Modifier.height(8.dp))
                        DetailRow(R.string.dna_files_label, x.count.toString())
                        Spacer(Modifier.height(6.dp))
                        DetailRow(R.string.dna_unpacked, fmtSize(x.total))
                    }
                }
            }
            val w = x.world
            if (w != null) item {
                Glass {
                    SectionTitle(stringResource(R.string.wd_analyzer), Icons.Rounded.Info)
                    Spacer(Modifier.height(8.dp))
                    DetailRow(R.string.r_seed, w.seed?.toString() ?: stringResource(R.string.none_dash))
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.r_version, w.version ?: stringResource(R.string.none_dash))
                    Spacer(Modifier.height(6.dp))
                    DetailRow(R.string.d_mode, modeName(w.gameType ?: -1))
                }
            }
            if (x.manifests.isNotEmpty()) item {
                Glass {
                    SectionTitle(stringResource(R.string.fi_manifests), Icons.Rounded.Extension)
                    x.manifests.forEach { m ->
                        Column(Modifier.padding(top = 10.dp)) {
                            Text(m.name, style = MaterialTheme.typography.titleMedium)
                            Text(m.kind + " · v" + m.version + " · " + m.uuid.take(13), style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                    }
                }
            }
            if (x.issues.isNotEmpty()) item {
                Glass {
                    SectionTitle(stringResource(R.string.ad_scan), Icons.Rounded.VerifiedUser)
                    x.issues.forEach { IssueRow(it) }
                    Text(stringResource(R.string.sc_scope), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 10.dp))
                }
            }
            item {
                Glass {
                    SectionTitle(stringResource(R.string.fi_entries), Icons.Rounded.FolderOpen)
                    x.entries.forEach { e ->
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                            Text(e.first, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmtSize(e.second), style = MaterialTheme.typography.bodySmall, color = dim)
                        }
                    }
                    if (x.count > x.entries.size) Text(stringResource(R.string.fi_more, x.count - x.entries.size), color = dim, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

private fun inspectUri(ctx: Context, u: Uri): Inspect {
    val tmp = File(ctx.cacheDir, "inspect_${System.nanoTime()}.tmp")
    var label = "file"
    try {
        ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) label = c.getString(0) ?: label
        }
        var total = 0L
        (ctx.contentResolver.openInputStream(u) ?: return Inspect(label, 0, emptyList(), 0, 0, emptyList(), emptyList(), null, "Cannot read file")).use { i ->
            tmp.outputStream().use { o ->
                val buf = ByteArray(65536)
                while (true) {
                    val r = i.read(buf)
                    if (r < 0) break
                    total += r
                    if (total > 1_500_000_000L) return Inspect(label, total, emptyList(), 0, 0, emptyList(), emptyList(), null, "File is too large to inspect")
                    o.write(buf, 0, r)
                }
            }
        }
        return try {
            val scan = scanAddon(tmp)
            ZipFile(tmp).use { z ->
                val es = z.entries().asSequence().filter { !it.isDirectory }.toList()
                val list = es.take(150).map { it.name to maxOf(it.size, 0L) }
                val lvl = z.getEntry("level.dat")
                val world = if (lvl == null) null else worldInfo(z.getInputStream(lvl).use { it.readBytes() })
                val issues = scan.issues.filter { !it.contains("|noman|") || lvl == null }
                Inspect(label, total, list, es.size, es.sumOf { maxOf(it.size, 0L) }, scan.manifests, issues, world, null)
            }
        } catch (e: Exception) {
            Inspect(label, total, emptyList(), 0, 0, emptyList(), emptyList(), null, "Not a ZIP-based Minecraft file")
        }
    } finally {
        tmp.delete()
    }
}

// ---------- Assistant ----------
@Composable
fun AssistantScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    val msgs = remember { mutableStateListOf<Pair<String, AssistAnswer>>() }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val recs = remember(vm.rows, vm.backups, vm.addons, vm.safe, vm.dl, vm.pinSet) { Assistant.recommendations(ctx, vm) }
    fun ask(t: String) {
        if (t.isNotBlank()) { msgs.add(0, t to Assistant.answer(ctx, t, vm)); q = "" }
    }
    Page(R.string.title_assistant, onBack = { nav.popBackStack() }) {
        item { Glass { Text(stringResource(R.string.as_notice), style = MaterialTheme.typography.bodySmall, color = dim) } }
        item {
            Glass {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.as_ask)) })
                Spacer(Modifier.height(8.dp))
                Acts {
                    Act(R.string.as_send, Icons.Rounded.Lightbulb) { ask(q) }
                }
                Spacer(Modifier.height(8.dp))
                Acts {
                    listOf(R.string.as_ex1, R.string.as_ex2, R.string.as_ex3, R.string.as_ex4).forEach { id ->
                        val t = stringResource(id)
                        TagChip(t, false) { ask(t) }
                    }
                }
            }
        }
        msgs.forEachIndexed { i, m ->
            item(key = "m$i-${m.first}") {
                Glass {
                    Text(m.first, style = MaterialTheme.typography.titleMedium)
                    Text(m.second.text, modifier = Modifier.padding(top = 8.dp))
                    Text(stringResource(R.string.as_source, m.second.source), style = MaterialTheme.typography.bodySmall, color = dim, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        item {
            Glass {
                SectionTitle(stringResource(R.string.rc_title), Icons.Rounded.Lightbulb)
                if (recs.isEmpty()) Text(stringResource(R.string.rc_none_needed), color = dim, modifier = Modifier.padding(top = 8.dp))
                recs.forEach { rc ->
                    Row(
                        Modifier.fillMaxWidth().clickable {
                            if (rc.route == "backup") vm.backupAll() else if (rc.route != null) nav.navigate(rc.route)
                        }.padding(top = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { Text(rc.text, Modifier.weight(1f)) }
                }
            }
        }
    }
}

// ---------- Server profiles ----------
@Composable
fun ServersScreen(vm: MainVm, nav: NavController) {
    val clip = LocalClipboardManager.current
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("19132") }
    var ver by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var del by remember { mutableStateOf<String?>(null) }
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Page(R.string.title_servers, onBack = { nav.popBackStack() }) {
        item { Text(stringResource(R.string.sv_note), color = dim, style = MaterialTheme.typography.bodySmall) }
        item {
            Glass {
                OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(host, { host = it }, Modifier.weight(2f), singleLine = true, label = { Text(stringResource(R.string.sv_host)) })
                    OutlinedTextField(port, { port = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.sv_port)) })
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(ver, { ver = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.r_version)) })
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth(), label = { Text(stringResource(R.string.sd_note)) })
                Spacer(Modifier.height(10.dp))
                Acts {
                    Act(R.string.sv_add, Icons.Rounded.Add) {
                        if (name.isNotBlank() && host.isNotBlank()) {
                            vm.addServer(name.trim(), host.trim(), port.trim().ifEmpty { "19132" }, ver.trim(), notes.trim())
                            name = ""; host = ""; ver = ""; notes = ""
                        }
                    }
                }
            }
        }
        if (vm.servers.isEmpty()) item { Text(stringResource(R.string.sv_empty), color = dim) }
        itemsIndexed(vm.servers, key = { _, s -> s.id }) { i, s ->
            Appear(i) {
                Glass {
                    Text(s.name, style = MaterialTheme.typography.titleMedium)
                    Text(s.host + ":" + s.port, fontFamily = FontFamily.Monospace, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 4.dp))
                    if (s.version.isNotBlank()) Text(s.version, style = MaterialTheme.typography.bodySmall, color = dim)
                    if (s.notes.isNotBlank()) Text(s.notes, style = MaterialTheme.typography.bodySmall, color = dim)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(s.host + ":" + s.port)); vm.toast = Msg(R.string.copied, s.host) }
                        Act(R.string.a_delete, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { del = s.id }
                    }
                }
            }
        }
    }
    del?.let { sid -> ConfirmDialog(stringResource(R.string.dlg_delete_item), { vm.deleteServer(sid); del = null }, { del = null }) }
}
