package app.minesaver

import android.content.Context
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.annotation.StringRes
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.StarBorder
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlin.math.floor
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import androidx.navigation.NavController
import kotlin.math.min
import kotlin.random.Random

// ---------- helpers ----------
@Composable
fun fmtDate(t: Long): String {
    val loc = LocalConfiguration.current.locales[0]
    return remember(t, loc) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT, loc).format(java.util.Date(t))
    }
}

@Composable
fun fmtSize(n: Long): String = Formatter.formatShortFileSize(LocalContext.current, n)

@Composable
fun modeName(m: Int) = stringResource(
    when (m) { 0 -> R.string.mode_0; 1 -> R.string.mode_1; 2 -> R.string.mode_2; else -> R.string.mode_x }
)

@Composable
fun statusOf(r: WorldRow): Pair<String, Color> = when {
    r.last == null -> stringResource(R.string.st_none) to Rose
    r.changed -> stringResource(R.string.st_changed) to Amber
    else -> stringResource(R.string.st_ok) to Green
}

@Composable
fun rememberExporter(vm: MainVm): (Backup) -> Unit {
    var pending by remember { mutableStateOf<Backup?>(null) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u ->
        val b = pending
        if (u != null && b != null) vm.exportTo(b, u)
    }
    return { b -> pending = b; l.launch(b.file) }
}

fun shareBackup(ctx: Context, vm: MainVm, b: Backup) {
    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.file(b))
    val i = Intent(Intent.ACTION_SEND).setType("application/octet-stream")
        .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, null))
}

fun openInMinecraft(ctx: Context, vm: MainVm, b: Backup) {
    val pkg = "com.mojang.minecraftpe"
    if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) { vm.toast = Msg(R.string.msg_no_mc); return }
    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.file(b))
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/octet-stream")
        .setPackage(pkg).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: Exception) { vm.toast = Msg(R.string.err, e.message ?: "open") }
}

@Composable
fun WorldIcon(vm: MainVm, id: String, last: Long?, dim: Dp = 64.dp) {
    val bmp = remember(id, last) {
        vm.iconFile(id).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(18.dp)
    if (bmp != null) Image(bmp, null, Modifier.size(dim).clip(shape), contentScale = ContentScale.Crop)
    else Box(
        Modifier.size(dim).clip(shape).background(Brush.linearGradient(listOf(Green.copy(alpha = .5f), Blue.copy(alpha = .5f), Violet.copy(alpha = .5f)))),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Public, null, tint = Color.White) }
}

// ---------- Home ----------
@Composable
fun Ring(p: Float, dim: Dp = 96.dp) {
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = .12f)
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 12.dp.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            rotate(-90f) {
                drawArc(Brush.sweepGradient(listOf(Green, Blue, Violet, Green)), 0f, 360f * p, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        Text("${(p * 100).toInt()}%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun Constellation(rows: List<WorldRow>) {
    val pulse = 1f
    Glass {
        Text(stringResource(R.string.home_stars), fontWeight = FontWeight.SemiBold)
        if (rows.isEmpty()) {
            Text(stringResource(R.string.home_empty), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            return@Glass
        }
        val pts = rows.map { r -> val rnd = Random(r.id.hashCode()); Triple(r, 0.1f + 0.68f * rnd.nextFloat(), 0.1f + 0.55f * rnd.nextFloat()) }.sortedBy { it.second }
        val line = MaterialTheme.colorScheme.onSurface.copy(alpha = .18f)
        BoxWithConstraints(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
            val mw = constraints.maxWidth
            val mh = constraints.maxHeight
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0 until pts.size - 1) {
                    drawLine(line, Offset(pts[i].second * size.width, pts[i].third * size.height),
                        Offset(pts[i + 1].second * size.width, pts[i + 1].third * size.height), strokeWidth = 1.5.dp.toPx())
                }
                pts.forEach { (r, x, y) ->
                    val c = if (r.last == null) Rose else if (r.changed) Amber else Green
                    val rad = (4f + min(r.backups.size, 6) * 1.1f).dp.toPx() * (if (r.changed || r.last == null) pulse else 1f)
                    drawCircle(c.copy(alpha = .22f), rad * 2.4f, Offset(x * size.width, y * size.height))
                    drawCircle(c, rad * .7f, Offset(x * size.width, y * size.height))
                }
            }
            pts.forEach { (r, x, y) ->
                Text(
                    r.name, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.widthIn(max = 84.dp).offset { IntOffset((x * mw).toInt() - 16.dp.roundToPx(), (y * mh).toInt() + 14.dp.roundToPx()) }
                )
            }
        }
    }
}

@Composable
fun Stat(value: String, @StringRes label: Int, modifier: Modifier = Modifier) {
    Glass(modifier) {
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(stringResource(label), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
    }
}

@Composable
fun CheckRow(ok: Boolean, @StringRes label: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(
            if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null,
            tint = if (ok) Green else MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.width(10.dp))
        Text(stringResource(label), Modifier.weight(1f))
    }
}

@Composable
fun LogLine(e: LogEntry) {
    val ctx = LocalContext.current
    val text = remember(e) {
        val id = ctx.resources.getIdentifier(e.res, "string", ctx.packageName)
        if (id == 0) e.res else runCatching { ctx.resources.getString(id, *e.args.toTypedArray()) }.getOrDefault(e.res)
    }
    val col = when (e.kind) { 2 -> MaterialTheme.colorScheme.error; 1 -> Amber; else -> Green }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(col))
        Spacer(Modifier.width(10.dp))
        Column {
            Text(text, style = MaterialTheme.typography.bodyMedium)
            Text(fmtDate(e.time), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun HomeScreen(vm: MainVm, nav: NavController) {
    val rows = vm.rows
    val now = System.currentTimeMillis()
    val safe = rows.count { r -> val l = r.last; l != null && now - l < 604_800_000L && !r.changed }
    val p by animateFloatAsState(if (rows.isEmpty()) 0f else safe / rows.size.toFloat(), tween(1400, easing = FastOutSlowInEasing), label = "ring")
    val total = vm.backups.sumOf { it.size }
    val lastAll = vm.backups.maxOfOrNull { it.time }
    val recent = rows.sortedByDescending { it.live?.modified ?: it.last ?: 0L }.take(3)
    val accessOk = vm.szActive || vm.src != null
    val worldsOk = vm.live.isNotEmpty()
    val safeOk = vm.safe != null
    Page(null) {
        item {
            Appear(0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_logo), null, Modifier.size(76.dp))
                    Column(Modifier.padding(start = 8.dp)) {
                        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.tagline), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Ring(p)
                        Column {
                            Text(stringResource(R.string.home_protected), fontWeight = FontWeight.SemiBold)
                            Text(stringResource(R.string.home_of, safe, rows.size), color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                stringResource(R.string.last_backup, lastAll?.let { fmtDate(it) } ?: stringResource(R.string.never)),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
        if (!worldsOk) item {
            Appear(2) {
                Glass {
                    SectionTitle(stringResource(R.string.tip_title), Icons.Rounded.Info)
                    Text(
                        stringResource(R.string.tip_body), style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        }
        if (!(accessOk && worldsOk && safeOk)) item {
            Appear(2) {
                Glass {
                    SectionTitle(stringResource(R.string.chk_title), Icons.Rounded.CheckCircle)
                    CheckRow(accessOk, R.string.chk_access) { nav.navigate("settings") }
                    CheckRow(worldsOk, R.string.chk_worlds) { vm.rescan() }
                    CheckRow(safeOk, R.string.chk_safe) { nav.navigate("settings") }
                }
            }
        }
        item {
            Appear(2) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat(rows.size.toString(), R.string.stat_worlds, Modifier.weight(1f))
                    Stat(vm.backups.size.toString(), R.string.stat_backups, Modifier.weight(1f))
                    Stat(fmtSize(total), R.string.stat_size, Modifier.weight(1f))
                }
            }
        }
        item {
            Appear(3) {
                GradientButton(stringResource(R.string.home_backup_all), Icons.Rounded.CloudUpload) { vm.backupAll() }
            }
        }
        if (recent.isNotEmpty()) item {
            Appear(4) {
                Glass {
                    Text(stringResource(R.string.home_recent_worlds), fontWeight = FontWeight.Bold)
                    recent.forEach { r ->
                        val (st, col) = statusOf(r)
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(r.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Badge(st, col)
                        }
                    }
                }
            }
        }
        item { Appear(5) { Constellation(rows) } }
        if (vm.log.isNotEmpty()) item {
            Appear(6) {
                Glass {
                    Text(stringResource(R.string.home_recent_activity), fontWeight = FontWeight.Bold)
                    vm.log.take(3).forEach { e -> Box(Modifier.padding(top = 10.dp)) { LogLine(e) } }
                }
            }
        }
        item {
            Appear(7) {
                Acts {
                    Act(R.string.a_restore, Icons.Rounded.Restore) { nav.navigate("restore") }
                    Act(R.string.a_activity, Icons.Rounded.History) { nav.navigate("activity") }
                    Act(R.string.a_storage, Icons.Rounded.Storage) { nav.navigate("storage") }
                    Act(R.string.a_transfer, Icons.Rounded.SwapHoriz) { nav.navigate("transfer") }
                    Act(R.string.home_scan, Icons.Rounded.Refresh) { vm.rescan() }
                    Act(R.string.title_about, Icons.Rounded.Info) { nav.navigate("about") }
                    if (!vm.canWriteGame) Act(R.string.go_settings, Icons.Rounded.Settings) { nav.navigate("settings") }
                }
            }
        }
    }
}

// ---------- Worlds ----------
@Composable
fun DetailRow(@StringRes label: Int, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        Text(stringResource(label), Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, Modifier.weight(1.4f), fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
    }
}

@Composable
fun WorldsScreen(vm: MainVm, nav: NavController) {
    val rows = vm.rows
    val export = rememberExporter(vm)
    var selecting by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var del by remember { mutableStateOf<Pair<Int, List<WorldRow>>?>(null) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(0) }
    var detail by remember { mutableStateOf<WorldRow?>(null) }
    val withBackups = rows.filter { it.backups.isNotEmpty() }
    val err = MaterialTheme.colorScheme.error
    val cmp: Comparator<WorldRow> = when (sort) {
        1 -> compareByDescending<WorldRow> { it.live?.size ?: 0L }
        2 -> compareByDescending<WorldRow> { it.live?.modified ?: it.last ?: 0L }
        else -> compareBy<WorldRow> { it.name.lowercase() }
    }
    val shown = rows.filter { query.isBlank() || it.name.contains(query, true) }
        .sortedWith(compareByDescending<WorldRow> { it.id in vm.favs }.then(cmp))
    Page(R.string.title_worlds) {
        if (rows.isNotEmpty()) {
            item {
                OutlinedTextField(
                    query, { query = it }, Modifier.fillMaxWidth(), singleLine = true,
                    label = { Text(stringResource(R.string.w_search)) },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(16.dp)
                )
            }
            item {
                Segment(listOf(stringResource(R.string.w_sort_name), stringResource(R.string.w_sort_size), stringResource(R.string.w_sort_date)), sort) { sort = it }
            }
            item {
                Acts {
                    if (!selecting) {
                        Act(R.string.a_select, Icons.Rounded.DoneAll) { selecting = true }
                    } else {
                        Act(R.string.a_done, Icons.Rounded.Close) { selecting = false; sel = emptySet() }
                        Act(R.string.a_select_all, Icons.Rounded.SelectAll) { sel = rows.map { it.id }.toSet() }
                        if (sel.isNotEmpty()) {
                            Act(stringResource(R.string.a_backup_sel, sel.size), Icons.Rounded.CloudUpload) {
                                vm.backupWorlds(rows.filter { it.id in sel }.mapNotNull { it.live })
                            }
                            Act(stringResource(R.string.a_delete_sel, sel.size), Icons.Rounded.Delete, err) {
                                del = 2 to rows.filter { it.id in sel && it.backups.isNotEmpty() }
                            }
                        }
                        if (withBackups.isNotEmpty()) Act(R.string.a_delete_all, Icons.Rounded.DeleteSweep, err) { del = 3 to withBackups }
                    }
                }
            }
        }
        if (rows.isEmpty()) item { Glass { Text(stringResource(R.string.home_empty)) } }
        itemsIndexed(shown, key = { _, r -> r.id }) { i, r ->
            Appear(i) {
                Glass(if (selecting) Modifier.clickable { sel = if (r.id in sel) sel - r.id else sel + r.id } else Modifier) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (selecting) Checkbox(r.id in sel, { sel = if (it) sel + r.id else sel - r.id })
                        WorldIcon(vm, r.id, r.last)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val (st, col) = statusOf(r)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Badge(modeName(r.mode), MaterialTheme.colorScheme.secondary); Badge(st, col) }
                            Text(
                                stringResource(R.string.last_backup, r.last?.let { fmtDate(it) } ?: stringResource(R.string.never)),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            val ws = r.live?.size ?: 0L
                            Text(
                                (if (ws > 0) fmtSize(ws) + " · " else "") + stringResource(R.string.copies, r.backups.size) + " · " + fmtSize(r.size),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { vm.toggleFav(r.id) }) {
                            Icon(if (r.id in vm.favs) Icons.Rounded.Star else Icons.Rounded.StarBorder, null, tint = Amber)
                        }
                    }
                    if (!selecting) {
                        Spacer(Modifier.height(10.dp))
                        Acts {
                            r.live?.let { w -> Act(R.string.a_backup, Icons.Rounded.CloudUpload) { vm.backupNow(w) } }
                            if (r.backups.isNotEmpty()) {
                                Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = r.backups.first().id; nav.navigate("restore") }
                                Act(R.string.a_export, Icons.Rounded.FileUpload) { export(r.backups.first()) }
                            }
                            Act(R.string.a_details, Icons.Rounded.Info) { detail = r }
                            if (r.backups.isNotEmpty()) Act(R.string.a_delete, Icons.Rounded.Delete, err) { del = 1 to listOf(r) }
                        }
                    }
                }
            }
        }
    }
    del?.let { d ->
        val kind = d.first
        val list = d.second
        val text = when (kind) {
            1 -> stringResource(R.string.dlg_delete_world, list.first().name)
            2 -> stringResource(R.string.dlg_delete_worlds, list.size)
            else -> stringResource(R.string.dlg_delete_allw, list.size)
        }
        ConfirmDialog(text, { vm.deleteWorlds(list.map { it.id }.toSet()); sel = emptySet(); selecting = false; del = null }, { del = null })
    }
    detail?.let { r ->
        val dash = stringResource(R.string.none_dash)
        AlertDialog(
            onDismissRequest = { detail = null },
            title = { Text(r.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    DetailRow(R.string.d_folder, r.id)
                    DetailRow(R.string.d_mode, modeName(r.mode))
                    DetailRow(R.string.d_size, r.live?.size?.takeIf { it > 0 }?.let { fmtSize(it) } ?: dash)
                    DetailRow(R.string.d_modified, r.live?.modified?.takeIf { it > 0 }?.let { fmtDate(it) } ?: dash)
                    DetailRow(R.string.d_copies, r.backups.size.toString())
                    DetailRow(R.string.d_path, r.live?.path ?: dash)
                }
            },
            confirmButton = { TextButton({ detail = null }) { Text(stringResource(R.string.a_done)) } }
        )
    }
}

// ---------- Backups ----------
@Composable
fun BackupsScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val export = rememberExporter(vm)
    var selecting by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var del by remember { mutableStateOf<Pair<Int, List<Backup>>?>(null) }
    val err = MaterialTheme.colorScheme.error
    Page(R.string.title_backups) {
        item {
            Acts {
                if (!selecting) {
                    Act(R.string.a_select, Icons.Rounded.DoneAll) { selecting = true }
                    Act(R.string.a_verify_all, Icons.Rounded.VerifiedUser) { vm.verifyAll() }
                    Act(R.string.a_transfer, Icons.Rounded.SwapHoriz) { nav.navigate("transfer") }
                    Act(R.string.a_backup, Icons.Rounded.CloudUpload) { vm.backupAll() }
                } else {
                    Act(R.string.a_done, Icons.Rounded.Close) { selecting = false; sel = emptySet() }
                    Act(R.string.a_select_all, Icons.Rounded.SelectAll) { sel = vm.backups.map { it.id }.toSet() }
                    if (sel.isNotEmpty()) {
                        Act(R.string.a_select_none, Icons.Rounded.Close) { sel = emptySet() }
                        Act(stringResource(R.string.a_delete_sel, sel.size), Icons.Rounded.Delete, err) {
                            del = 2 to vm.backups.filter { it.id in sel }
                        }
                    }
                    if (vm.backups.isNotEmpty()) Act(R.string.a_delete_all, Icons.Rounded.DeleteSweep, err) { del = 3 to vm.backups }
                }
            }
        }
        if (vm.backups.isEmpty()) item { Glass { Text(stringResource(R.string.backups_empty)) } }
        itemsIndexed(vm.backups.sortedByDescending { it.time }, key = { _, b -> b.id }) { i, b ->
            Appear(i) {
                Glass(if (selecting) Modifier.clickable { sel = if (b.id in sel) sel - b.id else sel + b.id } else Modifier) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selecting) Checkbox(b.id in sel, { sel = if (it) sel + b.id else sel - b.id })
                        Column(Modifier.weight(1f)) {
                            Text(b.worldName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                fmtDate(b.time) + " · " + fmtSize(b.size),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (b.id in vm.bad) Badge(stringResource(R.string.b_bad), err) else Badge(stringResource(R.string.b_ok), Green)
                        Badge("SHA-256 " + b.sha.take(8), MaterialTheme.colorScheme.tertiary)
                    }
                    if (!selecting) {
                        Acts {
                            Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = b.id; nav.navigate("restore") }
                            Act(R.string.a_export, Icons.Rounded.FileUpload) { export(b) }
                            Act(R.string.a_share, Icons.Rounded.Share) { runCatching { shareBackup(ctx, vm, b) } }
                            Act(R.string.a_verify, Icons.Rounded.VerifiedUser) { vm.verifyOne(b) }
                            Act(R.string.a_delete, Icons.Rounded.Delete, err) { del = 1 to listOf(b) }
                        }
                    }
                }
            }
        }
    }
    del?.let { d ->
        val list = d.second
        val text = when (d.first) {
            1 -> stringResource(R.string.dlg_delete_backup)
            2 -> stringResource(R.string.dlg_delete_sel, list.size)
            else -> stringResource(R.string.dlg_delete_allb, list.size)
        }
        ConfirmDialog(text, { vm.deleteBackups(list); sel = emptySet(); selecting = false; del = null }, { del = null })
    }
}

// ---------- Restore ----------
@Composable
fun RestoreScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val list = vm.backups.sortedByDescending { it.time }
    val chosen = list.find { it.id == vm.pick }
    Page(R.string.title_restore, onBack = { nav.popBackStack() }) {
        item { Glass { Text(stringResource(R.string.restore_note), color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        if (list.isEmpty()) item { Glass { Text(stringResource(R.string.restore_none)) } }
        else item { Text(stringResource(R.string.restore_pick), fontWeight = FontWeight.SemiBold) }
        itemsIndexed(list, key = { _, b -> b.id }) { i, b ->
            Appear(i) {
                val sel = b.id == vm.pick
                Glass(
                    Modifier.clickable { vm.pick = b.id }
                        .border(BorderStroke(if (sel) 2.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent), RoundedCornerShape(24.dp))
                ) {
                    Text(b.worldName, fontWeight = FontWeight.Bold)
                    Text(fmtDate(b.time) + " · " + fmtSize(b.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (chosen != null) item {
            Glass {
                DetailRow(R.string.d_folder, chosen.worldName)
                DetailRow(R.string.d_mode, modeName(chosen.mode))
                DetailRow(R.string.d_date, fmtDate(chosen.time))
                DetailRow(R.string.d_size, fmtSize(chosen.size))
                DetailRow(R.string.d_sha, chosen.sha.take(12))
            }
        }
        if (list.isNotEmpty()) item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { chosen?.let { openInMinecraft(ctx, vm, it) } }, enabled = chosen != null,
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)
                ) { Text(stringResource(R.string.restore_open)) }
                Text(stringResource(R.string.restore_open_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = { chosen?.let { vm.restoreToGame(it) } }, enabled = chosen != null && vm.canWriteGame,
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)
                ) { Text(stringResource(R.string.restore_game)) }
                if (!vm.canWriteGame) {
                    Text(stringResource(R.string.restore_need_src), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Acts { Act(R.string.go_settings, Icons.Rounded.Settings) { nav.navigate("settings") } }
                }
            }
        }
    }
}

// ---------- Transfer ----------
@Composable
fun TransferScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val export = rememberExporter(vm)
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.import(it) }
    Page(R.string.title_transfer, onBack = { nav.popBackStack() }) {
        item {
            Appear(0) {
                Glass {
                    Text(stringResource(R.string.transfer_import), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.transfer_import_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts { Act(R.string.transfer_import, Icons.Rounded.FolderOpen) { imp.launch(arrayOf("*/*")) } }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Text(stringResource(R.string.transfer_safe), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.transfer_safe_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts { Act(R.string.transfer_safe, Icons.Rounded.FolderOpen) { vm.importSafe() } }
                }
            }
        }
        item { Text(stringResource(R.string.transfer_export), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        itemsIndexed(vm.rows.filter { it.backups.isNotEmpty() }, key = { _, r -> r.id }) { i, r ->
            Appear(i) {
                Glass {
                    Text(r.name, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_export, Icons.Rounded.FileUpload) { export(r.backups.first()) }
                        Act(R.string.a_share, Icons.Rounded.Share) { runCatching { shareBackup(ctx, vm, r.backups.first()) } }
                    }
                }
            }
        }
    }
}

// ---------- Settings ----------
@Composable
fun SettingsScreen(vm: MainVm, nav: NavController) {
    val pickSrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { if (it != null) vm.setSrc(it) }
    val pickSafe = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { if (it != null) vm.setSafe(it) }
    val ctx = LocalContext.current
    var pinDlg by remember { mutableStateOf(false) }
    var pinText by remember { mutableStateOf("") }
    var rmPin by remember { mutableStateOf(false) }
    val errC = MaterialTheme.colorScheme.error
    val lang = LocalConfiguration.current.locales[0].language
    fun label(s: String?) = s?.let { Uri.decode(Uri.parse(it).lastPathSegment ?: it) }
    Page(R.string.nav_settings) {
        item {
            Appear(0) {
                Glass {
                    Text(stringResource(R.string.set_appearance), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.set_theme), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
                    Segment(listOf(stringResource(R.string.th_system), stringResource(R.string.th_light), stringResource(R.string.th_dark)), vm.theme) { vm.changeTheme(it) }
                    Text(stringResource(R.string.set_lang), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                    Segment(listOf("العربية", "English"), if (lang == "ar") 0 else 1) {
                        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(if (it == 0) "ar" else "en"))
                    }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Text(stringResource(R.string.sz_title), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.sz_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Text(stringResource(R.string.tip_body), style = MaterialTheme.typography.bodySmall, color = Amber, modifier = Modifier.padding(bottom = 8.dp))
                    Text(
                        stringResource(when (vm.sz) { 0 -> R.string.sz_s0; 1 -> R.string.sz_s1; 2 -> R.string.sz_s2; else -> R.string.sz_s3 }),
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        if (vm.sz == 0) Act(R.string.a_get_sz, Icons.Rounded.Public) {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + Sz.PKG))) }
                        }
                        if (vm.sz == 1) Act(R.string.a_open_sz, Icons.Rounded.Settings) {
                            ctx.packageManager.getLaunchIntentForPackage(Sz.PKG)?.let { runCatching { ctx.startActivity(it) } }
                        }
                        if (vm.sz == 2) Act(R.string.a_grant, Icons.Rounded.VerifiedUser) { vm.requestSz() }
                        Act(R.string.a_recheck, Icons.Rounded.Refresh) {
                            vm.refreshSz()
                            if (vm.szActive) { vm.rescan() } else {
                                vm.toast = Msg(when (vm.sz) { 0 -> R.string.sz_s0; 1 -> R.string.sz_s1; 2 -> R.string.sz_s2; else -> R.string.sz_s3 })
                            }
                        }
                        if (vm.sz == 3) Act(R.string.a_diag, Icons.Rounded.Info) { vm.runDiag() }
                    }
                    if (vm.sz == 3) {
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.sz_use), Modifier.weight(1f))
                            Switch(vm.szOn, { vm.changeSzOn(it); if (it) vm.rescan() })
                        }
                    }
                }
            }
        }
        item {
            Appear(2) {
                Glass {
                    Text(stringResource(R.string.set_visuals), fontWeight = FontWeight.Bold)
                    SwitchRow(R.string.set_anim, vm.anim) { vm.changeAnim(it) }
                    SwitchRow(R.string.set_bg, vm.bg) { vm.changeBg(it) }
                    Text(stringResource(R.string.set_accent), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 12.dp, bottom = 8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf(Green, Color(0xFF22D3EE), Violet, Blue).forEachIndexed { i, c ->
                            Box(
                                Modifier.size(38.dp).clip(CircleShape).background(c)
                                    .then(if (i == vm.accent) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                                    .clickable { vm.changeAccent(i) }
                            )
                        }
                    }
                }
            }
        }
        item {
            Appear(3) {
                Glass {
                    Text(stringResource(R.string.set_lock), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.set_lock_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts {
                        Act(R.string.a_set_pin, Icons.Rounded.Lock) { pinText = ""; pinDlg = true }
                        if (vm.pinSet) Act(R.string.a_remove_pin, Icons.Rounded.Delete, errC) { rmPin = true }
                    }
                }
            }
        }
        item {
            Appear(2) {
                Glass {
                    Text(stringResource(R.string.set_storage), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.set_mc), modifier = Modifier.padding(top = 10.dp), fontWeight = FontWeight.SemiBold)
                    Text(label(vm.src) ?: stringResource(R.string.not_set), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.set_mc_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts {
                        Act(R.string.a_choose, Icons.Rounded.FolderOpen) { pickSrc.launch(null) }
                        if (vm.src != null) Act(R.string.a_clear, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.setSrc(null) }
                    }
                    Text(stringResource(R.string.set_safe), modifier = Modifier.padding(top = 16.dp), fontWeight = FontWeight.SemiBold)
                    Text(label(vm.safe) ?: stringResource(R.string.not_set), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.set_safe_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts {
                        Act(R.string.a_choose, Icons.Rounded.FolderOpen) { pickSafe.launch(null) }
                        if (vm.safe != null) Act(R.string.a_clear, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.setSafe(null) }
                    }
                }
            }
        }
        item {
            Appear(3) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.set_auto), fontWeight = FontWeight.SemiBold)
                            Text(stringResource(R.string.set_auto_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(vm.auto, { vm.changeAuto(it) })
                    }
                }
            }
        }
        item { Appear(4) { Acts { Act(R.string.title_about, Icons.Rounded.Info) { nav.navigate("about") } } } }
    }
    if (pinDlg) {
        AlertDialog(
            onDismissRequest = { pinDlg = false },
            title = { Text(stringResource(R.string.pin_new)) },
            text = {
                OutlinedTextField(
                    pinText, { if (it.length <= 4 && it.all { c -> c.isDigit() }) pinText = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
            },
            confirmButton = { TextButton({ if (pinText.length == 4) { vm.setPin(pinText); pinDlg = false } }) { Text(stringResource(R.string.a_done)) } },
            dismissButton = { TextButton({ pinDlg = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
    if (rmPin) ConfirmDialog(stringResource(R.string.pin_remove_q), { vm.setPin(null); rmPin = false }, { rmPin = false })
    vm.diag?.let { d ->
        val clip = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { vm.diag = null },
            text = { Text(d, fontFamily = FontFamily.Monospace, fontSize = 11.sp, modifier = Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState())) },
            confirmButton = { TextButton({ clip.setText(AnnotatedString(d)) }) { Text(stringResource(R.string.a_copy)) } },
            dismissButton = { TextButton({ vm.diag = null }) { Text(stringResource(R.string.a_close)) } }
        )
    }
}

// ---------- About ----------
@Composable
fun AboutScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val y by rememberInfiniteTransition(label = "float").animateFloat(
        -8f, 8f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y"
    )
    val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
    Page(R.string.title_about, onBack = { nav.popBackStack() }) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_logo), null, Modifier.size(140.dp).offset(y = y.dp))
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.tagline), color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.story), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
                Text(stringResource(R.string.about_version, ver), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.about_dev), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { clip.setText(AnnotatedString("_okv")); vm.toast = Msg(R.string.copied, "_okv") }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { Text("Discord", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant); Text("_okv", fontWeight = FontWeight.SemiBold) }
                Row(
                    Modifier.fillMaxWidth().clickable {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@uv.rs"))) }
                    }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { Text("TikTok", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant); Text("uv.rs", fontWeight = FontWeight.SemiBold) }
            }
        }
        item {
            Text(
                stringResource(R.string.about_disclaimer), style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Glass {
                Text(stringResource(R.string.guide_title), fontWeight = FontWeight.Bold)
                listOf(R.string.guide_1, R.string.guide_2, R.string.guide_3, R.string.guide_4).forEach {
                    Text(stringResource(it), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}


// ---------- Shared small pieces ----------
@Composable
fun SwitchRow(@StringRes title: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(stringResource(title), Modifier.weight(1f))
        Switch(checked, onChange)
    }
}

// ---------- Activity Center ----------
@Composable
fun ActivityScreen(vm: MainVm, nav: NavController) {
    Page(R.string.title_activity, onBack = { nav.popBackStack() }) {
        if (vm.log.isEmpty()) {
            item { Glass { Text(stringResource(R.string.act_empty)) } }
        } else {
            item { Acts { Act(R.string.a_clear_log, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.clearLog() } } }
            itemsIndexed(vm.log) { i, e -> Appear(i) { Glass { LogLine(e) } } }
        }
    }
}

// ---------- Storage ----------
@Composable
fun StorageScreen(vm: MainVm, nav: NavController) {
    val total = vm.backups.sumOf { it.size }
    val free = remember(vm.backups.size) {
        runCatching { android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path).availableBytes }.getOrDefault(0L)
    }
    val byWorld = vm.rows.filter { it.backups.isNotEmpty() }.sortedByDescending { it.size }
    val maxSize = (byWorld.maxOfOrNull { it.size } ?: 1L).coerceAtLeast(1L)
    val old = vm.oldCopies(3)
    val temp = remember(vm.backups.size, vm.busy) { vm.tempSize() }
    var confirm by remember { mutableStateOf(false) }
    val err = MaterialTheme.colorScheme.error
    Page(R.string.title_storage, onBack = { nav.popBackStack() }) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat(fmtSize(total), R.string.sto_total, Modifier.weight(1f))
                Stat(fmtSize(free), R.string.sto_free, Modifier.weight(1f))
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.sto_by_world), fontWeight = FontWeight.Bold)
                if (byWorld.isEmpty()) Text(stringResource(R.string.backups_empty), modifier = Modifier.padding(top = 8.dp))
                byWorld.forEach { r ->
                    Column(Modifier.padding(top = 12.dp)) {
                        Row {
                            Text(r.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmtSize(r.size), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Box(Modifier.fillMaxWidth().padding(top = 6.dp).height(8.dp).clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = .1f))) {
                            Box(
                                Modifier.fillMaxWidth((r.size.toFloat() / maxSize).coerceIn(0.03f, 1f)).fillMaxHeight()
                                    .clip(RoundedCornerShape(4.dp)).background(Brush.horizontalGradient(listOf(Green, Blue, Violet)))
                            )
                        }
                    }
                }
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.sto_old), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.sto_old_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                if (old.isEmpty()) Text(stringResource(R.string.sto_old_none))
                else Acts { Act(stringResource(R.string.sto_old_btn, old.size), Icons.Rounded.DeleteSweep, err) { confirm = true } }
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.sto_temp), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                if (temp == 0L) Text(stringResource(R.string.sto_temp_none))
                else Acts { Act(stringResource(R.string.sto_temp_btn, fmtSize(temp)), Icons.Rounded.Delete, err) { vm.cleanTemp() } }
            }
        }
    }
    if (confirm) ConfirmDialog(stringResource(R.string.dlg_delete_old, old.size), { vm.deleteBackups(old); confirm = false }, { confirm = false })
}

// ---------- Tools ----------
@Composable
fun ToolsScreen(vm: MainVm) {
    val clip = LocalClipboardManager.current
    val numeric = KeyboardOptions(keyboardType = KeyboardType.Number)
    var cx by remember { mutableStateOf("") }
    var cz by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf(0) }
    var giveItem by remember { mutableStateOf("diamond") }
    var amount by remember { mutableStateOf("1") }
    var tx by remember { mutableStateOf("~") }
    var ty by remember { mutableStateOf("~") }
    var tz by remember { mutableStateOf("~") }
    var opt by remember { mutableStateOf(0) }
    val kinds = listOf(R.string.tcmd_give, R.string.tcmd_tp, R.string.tcmd_mode, R.string.tcmd_time, R.string.tcmd_weather)
    val modes = listOf("survival", "creative", "adventure")
    val times = listOf("day", "noon", "night", "midnight")
    val weathers = listOf("clear", "rain", "thunder")
    val command = when (kind) {
        0 -> "/give @s " + (if (giveItem.contains(':')) giveItem else "minecraft:" + giveItem) + " " + (amount.toIntOrNull() ?: 1)
        1 -> "/tp @s " + tx + " " + ty + " " + tz
        2 -> "/gamemode " + modes[opt.coerceIn(0, 2)]
        3 -> "/time set " + times[opt.coerceIn(0, 3)]
        else -> "/weather " + weathers[opt.coerceIn(0, 2)]
    }
    val liveRows = vm.rows.filter { it.live != null }
    Page(R.string.title_tools) {
        item {
            Appear(0) {
                Glass {
                    Text(stringResource(R.string.tools_coords), fontWeight = FontWeight.Bold)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(cx, { cx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") }, keyboardOptions = numeric)
                        OutlinedTextField(cz, { cz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") }, keyboardOptions = numeric)
                    }
                    val xv = cx.toDoubleOrNull()
                    val zv = cz.toDoubleOrNull()
                    if (xv != null && zv != null) {
                        Column(Modifier.padding(top = 10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(stringResource(R.string.tc_to_nether, floor(xv / 8).toLong(), floor(zv / 8).toLong()))
                            Text(stringResource(R.string.tc_to_over, (xv * 8).toLong(), (zv * 8).toLong()))
                            Text(stringResource(R.string.tc_chunk, floor(xv / 16).toLong(), floor(zv / 16).toLong()))
                        }
                    }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Text(stringResource(R.string.tools_cmd), fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        kinds.forEachIndexed { i, k ->
                            Act(k, Icons.Rounded.Build, if (i == kind) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) { kind = i; opt = 0 }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    when (kind) {
                        0 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(giveItem, { giveItem = it.trim() }, Modifier.weight(2f), singleLine = true, label = { Text(stringResource(R.string.tcmd_item)) })
                            OutlinedTextField(amount, { amount = it }, Modifier.weight(1f), singleLine = true, label = { Text(stringResource(R.string.tcmd_amount)) }, keyboardOptions = numeric)
                        }
                        1 -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(tx, { tx = it }, Modifier.weight(1f), singleLine = true, label = { Text("X") })
                            OutlinedTextField(ty, { ty = it }, Modifier.weight(1f), singleLine = true, label = { Text("Y") })
                            OutlinedTextField(tz, { tz = it }, Modifier.weight(1f), singleLine = true, label = { Text("Z") })
                        }
                        2 -> Segment(modes, opt) { opt = it }
                        3 -> Segment(times, opt) { opt = it }
                        else -> Segment(weathers, opt) { opt = it }
                    }
                    Text(command, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(vertical = 12.dp))
                    Acts { Act(R.string.a_copy, Icons.Rounded.ContentCopy) { clip.setText(AnnotatedString(command)); vm.toast = Msg(R.string.copied, command) } }
                }
            }
        }
        item {
            Appear(2) {
                Glass {
                    Text(stringResource(R.string.tools_info), fontWeight = FontWeight.Bold)
                    if (liveRows.isEmpty()) Text(stringResource(R.string.home_empty), modifier = Modifier.padding(top = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    liveRows.forEach { r ->
                        Column(Modifier.padding(top = 10.dp)) {
                            Text(r.name, fontWeight = FontWeight.SemiBold)
                            Text(
                                modeName(r.mode) + " · " + (r.live?.size?.takeIf { it > 0 }?.let { fmtSize(it) } ?: "—") + " · " + r.id,
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---------- PIN lock ----------
@Composable
fun LockScreen(vm: MainVm) {
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Color(0xFF0B0A1F)).statusBarsPadding().navigationBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ic_logo), null, Modifier.size(96.dp))
        Text(stringResource(R.string.pin_enter), color = Color.White, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(4) { i -> Box(Modifier.size(16.dp).clip(CircleShape).background(if (i < pin.length) Green else Color(0x33FFFFFF))) }
        }
        if (wrong) Text(stringResource(R.string.pin_wrong), color = Rose, modifier = Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(24.dp))
        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("", "0", "<")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                row.forEach { k ->
                    Box(
                        Modifier.size(72.dp).clip(CircleShape)
                            .background(if (k.isEmpty()) Color.Transparent else Color(0x22FFFFFF))
                            .clickable(enabled = k.isNotEmpty()) {
                                if (k == "<") {
                                    pin = pin.dropLast(1)
                                } else if (pin.length < 4) {
                                    pin += k
                                    if (pin.length == 4) {
                                        if (!vm.unlock(pin)) { wrong = true; pin = "" }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) { Text(k, color = Color.White, fontSize = 24.sp) }
                }
            }
        }
    }
}
