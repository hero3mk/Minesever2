package app.minesaver

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.text.format.Formatter
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.SelectAll
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.FileUpload
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material.icons.rounded.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.os.LocaleListCompat
import androidx.navigation.NavController
import kotlin.math.min
import kotlin.random.Random

// ---------- helpers ----------
@Composable
fun fmtDate(t: Long): String {
    val loc = LocalConfiguration.current.locales[0]
    return remember(t, loc) {
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT, loc).format(java.util.Date(t))
    }
}

@Composable
fun fmtSize(n: Long): String = Formatter.formatShortFileSize(LocalContext.current, n)

@Composable
fun modeName(m: Int) = stringResource(
    when (m) { 0 -> R.string.mode_0; 1 -> R.string.mode_1; 2 -> R.string.mode_2; else -> R.string.mode_x }
)

@Composable
fun statusOf(r: WorldRow): Pair<String, Color> = when {
    r.last == null -> stringResource(R.string.st_none) to Rose
    r.changed -> stringResource(R.string.st_changed) to Amber
    else -> stringResource(R.string.st_ok) to Green
}

@Composable
fun rememberExporter(vm: MainVm): (Backup) -> Unit {
    var pending by remember { mutableStateOf<Backup?>(null) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { u ->
        val b = pending
        if (u != null && b != null) vm.exportTo(b, u)
    }
    return { b -> pending = b; l.launch(b.file) }
}

fun shareBackup(ctx: Context, vm: MainVm, b: Backup) {
    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.file(b))
    val i = Intent(Intent.ACTION_SEND).setType("application/octet-stream")
        .putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, null))
}

fun openInMinecraft(ctx: Context, vm: MainVm, b: Backup) {
    val pkg = "com.mojang.minecraftpe"
    if (ctx.packageManager.getLaunchIntentForPackage(pkg) == null) { vm.toast = Msg(R.string.msg_no_mc); return }
    val u = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", vm.file(b))
    val i = Intent(Intent.ACTION_VIEW).setDataAndType(u, "application/octet-stream")
        .setPackage(pkg).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try { ctx.startActivity(i) } catch (e: Exception) { vm.toast = Msg(R.string.err, e.message ?: "open") }
}

@Composable
fun WorldIcon(vm: MainVm, id: String, last: Long?, dim: Dp = 64.dp) {
    val bmp = remember(id, last) {
        vm.iconFile(id).takeIf { it.exists() }?.let { BitmapFactory.decodeFile(it.path)?.asImageBitmap() }
    }
    val shape = RoundedCornerShape(18.dp)
    if (bmp != null) Image(bmp, null, Modifier.size(dim).clip(shape), contentScale = ContentScale.Crop)
    else Box(
        Modifier.size(dim).clip(shape).background(Brush.linearGradient(listOf(Green.copy(alpha = .5f), Blue.copy(alpha = .5f), Violet.copy(alpha = .5f)))),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Rounded.Public, null, tint = Color.White) }
}

// ---------- Home ----------
@Composable
fun Ring(p: Float, dim: Dp = 96.dp) {
    val track = MaterialTheme.colorScheme.onSurface.copy(alpha = .12f)
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = 12.dp.toPx()
            val tl = Offset(sw / 2, sw / 2)
            val sz = Size(size.width - sw, size.height - sw)
            drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            rotate(-90f) {
                drawArc(Brush.sweepGradient(listOf(Green, Blue, Violet, Green)), 0f, 360f * p, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
        }
        Text("${(p * 100).toInt()}%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun Constellation(rows: List<WorldRow>) {
    val pulse by rememberInfiniteTransition(label = "pulse").animateFloat(
        0.75f, 1.15f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pp"
    )
    Glass {
        Text(stringResource(R.string.home_stars), fontWeight = FontWeight.SemiBold)
        if (rows.isEmpty()) {
            Text(stringResource(R.string.home_empty), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
            return@Glass
        }
        val pts = rows.map { r -> val rnd = Random(r.id.hashCode()); Triple(r, 0.1f + 0.68f * rnd.nextFloat(), 0.1f + 0.55f * rnd.nextFloat()) }.sortedBy { it.second }
        val line = MaterialTheme.colorScheme.onSurface.copy(alpha = .18f)
        BoxWithConstraints(Modifier.fillMaxWidth().height(180.dp).padding(top = 8.dp)) {
            val mw = constraints.maxWidth
            val mh = constraints.maxHeight
            Canvas(Modifier.fillMaxSize()) {
                for (i in 0 until pts.size - 1) {
                    drawLine(line, Offset(pts[i].second * size.width, pts[i].third * size.height),
                        Offset(pts[i + 1].second * size.width, pts[i + 1].third * size.height), strokeWidth = 1.5.dp.toPx())
                }
                pts.forEach { (r, x, y) ->
                    val c = if (r.last == null) Rose else if (r.changed) Amber else Green
                    val rad = (4f + min(r.backups.size, 6) * 1.1f).dp.toPx() * (if (r.changed || r.last == null) pulse else 1f)
                    drawCircle(c.copy(alpha = .22f), rad * 2.4f, Offset(x * size.width, y * size.height))
                    drawCircle(c, rad * .7f, Offset(x * size.width, y * size.height))
                }
            }
            pts.forEach { (r, x, y) ->
                Text(
                    r.name, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.widthIn(max = 84.dp).offset { IntOffset((x * mw).toInt() - 16.dp.roundToPx(), (y * mh).toInt() + 14.dp.roundToPx()) }
                )
            }
        }
    }
}

@Composable
fun HomeScreen(vm: MainVm, nav: NavController) {
    val rows = vm.rows
    val now = System.currentTimeMillis()
    val safe = rows.count { r -> val l = r.last; l != null && now - l < 604_800_000L && !r.changed }
    val p by animateFloatAsState(if (rows.isEmpty()) 0f else safe / rows.size.toFloat(), tween(1400, easing = FastOutSlowInEasing), label = "ring")
    Page(null) {
        item {
            Appear(0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(painterResource(R.drawable.ic_logo), null, Modifier.size(76.dp))
                    Column(Modifier.padding(start = 8.dp)) {
                        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        Text(stringResource(R.string.tagline), color = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Ring(p)
                        Column {
                            Text(stringResource(R.string.home_protected), fontWeight = FontWeight.SemiBold)
                            Text(stringResource(R.string.home_of, safe, rows.size), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
        item { Appear(2) { Constellation(rows) } }
        item {
            Appear(3) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { vm.backupAll() }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)) {
                        Icon(Icons.Rounded.CloudUpload, null); Spacer(Modifier.size(8.dp)); Text(stringResource(R.string.home_backup_all))
                    }
                    Acts {
                        Act(R.string.a_restore, Icons.Rounded.Restore) { nav.navigate("restore") }
                        Act(R.string.home_scan, Icons.Rounded.Refresh) { vm.rescan() }
                        if (!vm.canWriteGame) Act(R.string.go_settings, Icons.Rounded.Settings) { nav.navigate("settings") }
                    }
                }
            }
        }
    }
}

// ---------- Worlds ----------
@Composable
fun WorldsScreen(vm: MainVm, nav: NavController) {
    val rows = vm.rows
    val export = rememberExporter(vm)
    var selecting by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var del by remember { mutableStateOf<Pair<Int, List<WorldRow>>?>(null) }
    val withBackups = rows.filter { it.backups.isNotEmpty() }
    val err = MaterialTheme.colorScheme.error
    Page(R.string.title_worlds) {
        if (rows.isNotEmpty()) item {
            Acts {
                if (!selecting) {
                    Act(R.string.a_select, Icons.Rounded.DoneAll) { selecting = true }
                } else {
                    Act(R.string.a_done, Icons.Rounded.Close) { selecting = false; sel = emptySet() }
                    Act(R.string.a_select_all, Icons.Rounded.SelectAll) { sel = rows.map { it.id }.toSet() }
                    if (sel.isNotEmpty()) {
                        Act(stringResource(R.string.a_backup_sel, sel.size), Icons.Rounded.CloudUpload) {
                            vm.backupWorlds(rows.filter { it.id in sel }.mapNotNull { it.live })
                        }
                        Act(stringResource(R.string.a_delete_sel, sel.size), Icons.Rounded.Delete, err) {
                            del = 2 to rows.filter { it.id in sel && it.backups.isNotEmpty() }
                        }
                    }
                    if (withBackups.isNotEmpty()) Act(R.string.a_delete_all, Icons.Rounded.DeleteSweep, err) { del = 3 to withBackups }
                }
            }
        }
        if (rows.isEmpty()) item { Glass { Text(stringResource(R.string.home_empty)) } }
        itemsIndexed(rows, key = { _, r -> r.id }) { i, r ->
            Appear(i) {
                Glass(if (selecting) Modifier.clickable { sel = if (r.id in sel) sel - r.id else sel + r.id } else Modifier) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (selecting) Checkbox(r.id in sel, { sel = if (it) sel + r.id else sel - r.id })
                        WorldIcon(vm, r.id, r.last)
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(r.name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val (st, col) = statusOf(r)
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { Badge(modeName(r.mode), MaterialTheme.colorScheme.secondary); Badge(st, col) }
                            Text(
                                stringResource(R.string.last_backup, r.last?.let { fmtDate(it) } ?: stringResource(R.string.never)),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                fmtSize(r.size) + " · " + stringResource(R.string.copies, r.backups.size),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    if (!selecting) {
                        Spacer(Modifier.height(10.dp))
                        Acts {
                            r.live?.let { w -> Act(R.string.a_backup, Icons.Rounded.CloudUpload) { vm.backupNow(w) } }
                            if (r.backups.isNotEmpty()) {
                                Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = r.backups.first().id; nav.navigate("restore") }
                                Act(R.string.a_export, Icons.Rounded.FileUpload) { export(r.backups.first()) }
                                Act(R.string.a_delete, Icons.Rounded.Delete, err) { del = 1 to listOf(r) }
                            }
                        }
                    }
                }
            }
        }
    }
    del?.let { d ->
        val kind = d.first
        val list = d.second
        val text = when (kind) {
            1 -> stringResource(R.string.dlg_delete_world, list.first().name)
            2 -> stringResource(R.string.dlg_delete_worlds, list.size)
            else -> stringResource(R.string.dlg_delete_allw, list.size)
        }
        ConfirmDialog(text, { vm.deleteWorlds(list.map { it.id }.toSet()); sel = emptySet(); selecting = false; del = null }, { del = null })
    }
}

// ---------- Backups ----------
@Composable
fun BackupsScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val export = rememberExporter(vm)
    var selecting by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var del by remember { mutableStateOf<Pair<Int, List<Backup>>?>(null) }
    val err = MaterialTheme.colorScheme.error
    Page(R.string.title_backups) {
        item {
            Acts {
                if (!selecting) {
                    Act(R.string.a_select, Icons.Rounded.DoneAll) { selecting = true }
                    Act(R.string.a_verify_all, Icons.Rounded.VerifiedUser) { vm.verifyAll() }
                    Act(R.string.a_backup, Icons.Rounded.CloudUpload) { vm.backupAll() }
                } else {
                    Act(R.string.a_done, Icons.Rounded.Close) { selecting = false; sel = emptySet() }
                    Act(R.string.a_select_all, Icons.Rounded.SelectAll) { sel = vm.backups.map { it.id }.toSet() }
                    if (sel.isNotEmpty()) {
                        Act(R.string.a_select_none, Icons.Rounded.Close) { sel = emptySet() }
                        Act(stringResource(R.string.a_delete_sel, sel.size), Icons.Rounded.Delete, err) {
                            del = 2 to vm.backups.filter { it.id in sel }
                        }
                    }
                    if (vm.backups.isNotEmpty()) Act(R.string.a_delete_all, Icons.Rounded.DeleteSweep, err) { del = 3 to vm.backups }
                }
            }
        }
        if (vm.backups.isEmpty()) item { Glass { Text(stringResource(R.string.backups_empty)) } }
        itemsIndexed(vm.backups.sortedByDescending { it.time }, key = { _, b -> b.id }) { i, b ->
            Appear(i) {
                Glass(if (selecting) Modifier.clickable { sel = if (b.id in sel) sel - b.id else sel + b.id } else Modifier) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (selecting) Checkbox(b.id in sel, { sel = if (it) sel + b.id else sel - b.id })
                        Column(Modifier.weight(1f)) {
                            Text(b.worldName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(
                                fmtDate(b.time) + " · " + fmtSize(b.size),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (b.id in vm.bad) Badge(stringResource(R.string.b_bad), err) else Badge(stringResource(R.string.b_ok), Green)
                        Badge("SHA-256 " + b.sha.take(8), MaterialTheme.colorScheme.tertiary)
                    }
                    if (!selecting) {
                        Acts {
                            Act(R.string.a_restore, Icons.Rounded.Restore) { vm.pick = b.id; nav.navigate("restore") }
                            Act(R.string.a_export, Icons.Rounded.FileUpload) { export(b) }
                            Act(R.string.a_share, Icons.Rounded.Share) { runCatching { shareBackup(ctx, vm, b) } }
                            Act(R.string.a_verify, Icons.Rounded.VerifiedUser) { vm.verifyOne(b) }
                            Act(R.string.a_delete, Icons.Rounded.Delete, err) { del = 1 to listOf(b) }
                        }
                    }
                }
            }
        }
    }
    del?.let { d ->
        val list = d.second
        val text = when (d.first) {
            1 -> stringResource(R.string.dlg_delete_backup)
            2 -> stringResource(R.string.dlg_delete_sel, list.size)
            else -> stringResource(R.string.dlg_delete_allb, list.size)
        }
        ConfirmDialog(text, { vm.deleteBackups(list); sel = emptySet(); selecting = false; del = null }, { del = null })
    }
}

// ---------- Restore ----------
@Composable
fun RestoreScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val list = vm.backups.sortedByDescending { it.time }
    val chosen = list.find { it.id == vm.pick }
    Page(R.string.title_restore, onBack = { nav.popBackStack() }) {
        item { Glass { Text(stringResource(R.string.restore_note), color = MaterialTheme.colorScheme.onSurfaceVariant) } }
        if (list.isEmpty()) item { Glass { Text(stringResource(R.string.restore_none)) } }
        else item { Text(stringResource(R.string.restore_pick), fontWeight = FontWeight.SemiBold) }
        itemsIndexed(list, key = { _, b -> b.id }) { i, b ->
            Appear(i) {
                val sel = b.id == vm.pick
                Glass(
                    Modifier.clickable { vm.pick = b.id }
                        .border(BorderStroke(if (sel) 2.dp else 0.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Transparent), RoundedCornerShape(24.dp))
                ) {
                    Text(b.worldName, fontWeight = FontWeight.Bold)
                    Text(fmtDate(b.time) + " · " + fmtSize(b.size), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        if (list.isNotEmpty()) item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { chosen?.let { openInMinecraft(ctx, vm, it) } }, enabled = chosen != null,
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)
                ) { Text(stringResource(R.string.restore_open)) }
                Text(stringResource(R.string.restore_open_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Button(
                    onClick = { chosen?.let { vm.restoreToGame(it) } }, enabled = chosen != null && vm.canWriteGame,
                    modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp)
                ) { Text(stringResource(R.string.restore_game)) }
                if (!vm.canWriteGame) {
                    Text(stringResource(R.string.restore_need_src), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Acts { Act(R.string.go_settings, Icons.Rounded.Settings) { nav.navigate("settings") } }
                }
            }
        }
    }
}

// ---------- Transfer ----------
@Composable
fun TransferScreen(vm: MainVm) {
    val ctx = LocalContext.current
    val export = rememberExporter(vm)
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { if (it.isNotEmpty()) vm.import(it) }
    Page(R.string.title_transfer) {
        item {
            Appear(0) {
                Glass {
                    Text(stringResource(R.string.transfer_import), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.transfer_import_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts { Act(R.string.transfer_import, Icons.Rounded.FolderOpen) { imp.launch(arrayOf("*/*")) } }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Text(stringResource(R.string.transfer_safe), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.transfer_safe_hint), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts { Act(R.string.transfer_safe, Icons.Rounded.FolderOpen) { vm.importSafe() } }
                }
            }
        }
        item { Text(stringResource(R.string.transfer_export), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        itemsIndexed(vm.rows.filter { it.backups.isNotEmpty() }, key = { _, r -> r.id }) { i, r ->
            Appear(i) {
                Glass {
                    Text(r.name, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        Act(R.string.a_export, Icons.Rounded.FileUpload) { export(r.backups.first()) }
                        Act(R.string.a_share, Icons.Rounded.Share) { runCatching { shareBackup(ctx, vm, r.backups.first()) } }
                    }
                }
            }
        }
    }
}

// ---------- Settings ----------
@Composable
fun SettingsScreen(vm: MainVm, nav: NavController) {
    val pickSrc = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { if (it != null) vm.setSrc(it) }
    val pickSafe = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { if (it != null) vm.setSafe(it) }
    val ctx = LocalContext.current
    val lang = LocalConfiguration.current.locales[0].language
    fun label(s: String?) = s?.let { Uri.decode(Uri.parse(it).lastPathSegment ?: it) }
    Page(R.string.nav_settings) {
        item {
            Appear(0) {
                Glass {
                    Text(stringResource(R.string.set_appearance), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.set_theme), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
                    Segment(listOf(stringResource(R.string.th_system), stringResource(R.string.th_light), stringResource(R.string.th_dark)), vm.theme) { vm.setTheme(it) }
                    Text(stringResource(R.string.set_lang), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
                    Segment(listOf("العربية", "English"), if (lang == "ar") 0 else 1) {
                        AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(if (it == 0) "ar" else "en"))
                    }
                }
            }
        }
        item {
            Appear(1) {
                Glass {
                    Text(stringResource(R.string.sz_title), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.sz_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Text(
                        stringResource(when (vm.sz) { 0 -> R.string.sz_s0; 1 -> R.string.sz_s1; 2 -> R.string.sz_s2; else -> R.string.sz_s3 }),
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
                    Acts {
                        if (vm.sz == 0) Act(R.string.a_get_sz, Icons.Rounded.Public) {
                            runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + Sz.PKG))) }
                        }
                        if (vm.sz == 1) Act(R.string.a_open_sz, Icons.Rounded.Settings) {
                            ctx.packageManager.getLaunchIntentForPackage(Sz.PKG)?.let { runCatching { ctx.startActivity(it) } }
                        }
                        if (vm.sz == 2) Act(R.string.a_grant, Icons.Rounded.VerifiedUser) { vm.requestSz() }
                        Act(R.string.a_recheck, Icons.Rounded.Refresh) { vm.refreshSz() }
                    }
                    if (vm.sz == 3) {
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(stringResource(R.string.sz_use), Modifier.weight(1f))
                            Switch(vm.szOn, { vm.setSzOn(it); if (it) vm.rescan() })
                        }
                    }
                }
            }
        }
        item {
            Appear(2) {
                Glass {
                    Text(stringResource(R.string.set_storage), fontWeight = FontWeight.Bold)
                    Text(stringResource(R.string.set_mc), modifier = Modifier.padding(top = 10.dp), fontWeight = FontWeight.SemiBold)
                    Text(label(vm.src) ?: stringResource(R.string.not_set), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.set_mc_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts {
                        Act(R.string.a_choose, Icons.Rounded.FolderOpen) { pickSrc.launch(null) }
                        if (vm.src != null) Act(R.string.a_clear, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.setSrc(null) }
                    }
                    Text(stringResource(R.string.set_safe), modifier = Modifier.padding(top = 16.dp), fontWeight = FontWeight.SemiBold)
                    Text(label(vm.safe) ?: stringResource(R.string.not_set), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                    Text(stringResource(R.string.set_safe_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 6.dp))
                    Acts {
                        Act(R.string.a_choose, Icons.Rounded.FolderOpen) { pickSafe.launch(null) }
                        if (vm.safe != null) Act(R.string.a_clear, Icons.Rounded.Delete, MaterialTheme.colorScheme.error) { vm.setSafe(null) }
                    }
                }
            }
        }
        item {
            Appear(3) {
                Glass {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(stringResource(R.string.set_auto), fontWeight = FontWeight.SemiBold)
                            Text(stringResource(R.string.set_auto_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(vm.auto, { vm.setAuto(it) })
                    }
                }
            }
        }
        item { Appear(4) { Acts { Act(R.string.title_about, Icons.Rounded.Info) { nav.navigate("about") } } } }
    }
}

// ---------- About ----------
@Composable
fun AboutScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val clip = LocalClipboardManager.current
    val y by rememberInfiniteTransition(label = "float").animateFloat(
        -8f, 8f, infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "y"
    )
    val ver = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }
    Page(R.string.title_about, onBack = { nav.popBackStack() }) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(painterResource(R.drawable.ic_logo), null, Modifier.size(140.dp).offset(y = y.dp))
                Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.tagline), color = MaterialTheme.colorScheme.primary)
                Text(stringResource(R.string.story), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 10.dp))
                Text(stringResource(R.string.about_version, ver), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp))
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.about_dev), fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().clickable { clip.setText(AnnotatedString("_okv")); vm.toast = Msg(R.string.copied, "_okv") }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { Text("Discord", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant); Text("_okv", fontWeight = FontWeight.SemiBold) }
                Row(
                    Modifier.fillMaxWidth().clickable {
                        runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.tiktok.com/@uv.rs"))) }
                    }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { Text("TikTok", Modifier.weight(1f), color = MaterialTheme.colorScheme.onSurfaceVariant); Text("uv.rs", fontWeight = FontWeight.SemiBold) }
            }
        }
        item {
            Glass {
                Text(stringResource(R.string.guide_title), fontWeight = FontWeight.Bold)
                listOf(R.string.guide_1, R.string.guide_2, R.string.guide_3, R.string.guide_4).forEach {
                    Text(stringResource(it), color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}
