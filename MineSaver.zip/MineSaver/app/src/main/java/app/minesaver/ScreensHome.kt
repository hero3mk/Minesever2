package app.minesaver

import android.content.Intent
import androidx.annotation.StringRes
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.Extension
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Lightbulb
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Restore
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import java.util.Calendar

private class QA(@StringRes val label: Int, val icon: ImageVector, val go: () -> Unit)

@Composable
private fun QuickAction(@StringRes label: Int, icon: ImageVector, onClick: () -> Unit) {
    val prim = MaterialTheme.colorScheme.primary
    val sec = MaterialTheme.colorScheme.secondary
    Column(Modifier.width(78.dp).clip(RoundedCornerShape(18.dp)).clickable(onClick = onClick).padding(vertical = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(prim.copy(alpha = 0.26f), sec.copy(alpha = 0.12f)))),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = prim, modifier = Modifier.size(26.dp)) }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(label), style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun OverviewCell(value: String, @StringRes label: Int, icon: ImageVector, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.055f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(12.dp))
        Column {
            Text(value, style = MaterialTheme.typography.titleLarge, maxLines = 1)
            Text(stringResource(label), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

@Composable
fun HomeScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val rows = vm.rows
    val now = System.currentTimeMillis()
    val safe = rows.count { r -> val l = r.last; l != null && now - l < 604_800_000L && !r.changed }
    val p by animateFloatAsState(if (rows.isEmpty()) 0f else safe / rows.size.toFloat(), tween(1100, easing = FastOutSlowInEasing), label = "ring")
    val total = vm.backups.sumOf { it.size }
    val lastAll = vm.backups.maxOfOrNull { it.time }
    val accessOk = vm.szActive || vm.src != null
    val worldsOk = vm.live.isNotEmpty()
    val safeOk = vm.safe != null || vm.dl
    val prim = MaterialTheme.colorScheme.primary
    val sec = MaterialTheme.colorScheme.secondary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    val recs = remember(vm.rows, vm.backups, vm.addons, vm.safe, vm.dl, vm.pinSet) { Assistant.recommendations(ctx, vm) }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val greet = if (hour < 12) R.string.hm_morning else if (hour < 18) R.string.hm_afternoon else R.string.hm_evening
    Page(null) {
        item {
            Appear(0) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(greet), color = prim, style = MaterialTheme.typography.labelLarge)
                        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineLarge)
                        Text(stringResource(R.string.tagline), color = dim, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { nav.navigate("search") }) { Icon(Icons.Rounded.Search, null, tint = prim) }
                    IconButton(onClick = { nav.navigate("settings") }) { Icon(Icons.Rounded.Settings, null, tint = prim) }
                }
            }
        }
        item {
            Appear(1) {
                val shape = RoundedCornerShape(30.dp)
                Column(
                    Modifier.fillMaxWidth().clip(shape)
                        .background(Brush.linearGradient(listOf(prim.copy(alpha = .30f), sec.copy(alpha = .12f), prim.copy(alpha = .06f))))
                        .padding(22.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        Ring(p, 104.dp)
                        Column {
                            Text(stringResource(R.string.home_protected), style = MaterialTheme.typography.titleLarge)
                            Text(stringResource(R.string.home_of, safe, rows.size), style = MaterialTheme.typography.bodyMedium, color = dim)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                stringResource(R.string.last_backup, lastAll?.let { fmtDate(it) } ?: stringResource(R.string.never)),
                                style = MaterialTheme.typography.bodySmall, color = dim
                            )
                        }
                    }
                    Spacer(Modifier.height(18.dp))
                    GradientButton(stringResource(R.string.home_backup_all), Icons.Rounded.CloudUpload) { vm.backupAll() }
                }
            }
        }
        item {
            Appear(2) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val acts: List<QA> = listOf(
                        QA(R.string.qa_worlds, Icons.Rounded.Public) { nav.navigate("worlds") },
                        QA(R.string.qa_restore, Icons.Rounded.Restore) { nav.navigate("restore") },
                        QA(R.string.qa_minecraft, Icons.Rounded.SportsEsports) {
                            ctx.packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")?.let { runCatching { ctx.startActivity(it) } } ?: nav.navigate("game")
                        },
                        QA(R.string.nav_addons, Icons.Rounded.Extension) { nav.navigate("addons") },
                        QA(R.string.nav_atlas, Icons.Rounded.Map) { nav.navigate("atlas") },
                        QA(R.string.a_storage, Icons.Rounded.Storage) { nav.navigate("storage") },
                        QA(R.string.qa_tools, Icons.Rounded.Apps) { nav.navigate("more") },
                        QA(R.string.title_help, Icons.Rounded.Lightbulb) { nav.navigate("help") }
                    )
                    items(acts) { a -> QuickAction(a.label, a.icon, a.go) }
                }
            }
        }
        item {
            Appear(3) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OverviewCell(rows.size.toString(), R.string.stat_worlds, Icons.Rounded.Public, Modifier.weight(1f))
                        OverviewCell(vm.backups.size.toString(), R.string.stat_backups, Icons.Rounded.Inventory2, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OverviewCell(fmtSize(total), R.string.stat_size, Icons.Rounded.Storage, Modifier.weight(1f))
                        OverviewCell(vm.addons.size.toString(), R.string.nav_addons, Icons.Rounded.Extension, Modifier.weight(1f))
                    }
                }
            }
        }
        if (!worldsOk) item {
            Appear(4) {
                Glass {
                    SectionTitle(stringResource(R.string.tip_title), Icons.Rounded.Info)
                    Text(stringResource(R.string.tip_body), style = MaterialTheme.typography.bodyMedium, color = dim, modifier = Modifier.padding(top = 10.dp))
                    Spacer(Modifier.height(10.dp))
                    Acts { Act(R.string.title_help, Icons.Rounded.Lightbulb) { nav.navigate("help") } }
                }
            }
        }
        if (!(accessOk && worldsOk && safeOk)) item {
            Appear(4) {
                Glass {
                    SectionTitle(stringResource(R.string.chk_title), Icons.Rounded.CheckCircle)
                    CheckRow(accessOk, R.string.chk_access) { nav.navigate("settings") }
                    CheckRow(worldsOk, R.string.chk_worlds) { vm.rescan() }
                    CheckRow(safeOk, R.string.chk_safe) { nav.navigate("settings") }
                }
            }
        }
        if (recs.isNotEmpty()) item {
            Appear(4) {
                Glass {
                    SectionTitle(stringResource(R.string.rc_title), Icons.Rounded.Lightbulb)
                    recs.take(3).forEach { rc ->
                        Row(
                            Modifier.fillMaxWidth().clickable { if (rc.route == "backup") vm.backupAll() else if (rc.route != null) nav.navigate(rc.route) }.padding(top = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) { Text(rc.text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium) }
                    }
                }
            }
        }
        if (rows.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.home_your_worlds), Icons.Rounded.Public) }
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(rows, key = { it.id }) { r -> WorldMini(vm, r) { vm.detailId = r.id; nav.navigate("world") } }
                }
            }
        }
        if (vm.log.isNotEmpty()) {
            item { SectionTitle(stringResource(R.string.home_recent_activity), Icons.Rounded.Info) }
            item {
                Column {
                    vm.log.take(4).forEach { e ->
                        Row(Modifier.padding(bottom = 12.dp), verticalAlignment = Alignment.Top) {
                            Box(Modifier.padding(top = 6.dp, end = 12.dp).size(8.dp).clip(CircleShape).background(prim))
                            LogLine(e)
                        }
                    }
                }
            }
        }
    }
}
