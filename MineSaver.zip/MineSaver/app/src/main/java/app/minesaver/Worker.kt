package app.minesaver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object Notifier {
    private const val CH = "ms_main"

    fun can(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, "android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

    fun post(ctx: Context, title: String, text: String, id: Int = 1) {
        if (!can(ctx)) return
        runCatching {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, ctx.getString(R.string.app_name), NotificationManager.IMPORTANCE_DEFAULT))
            val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(ctx, CH).setSmallIcon(R.drawable.ic_notify).setContentTitle(title).setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text)).setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(id, n)
        }
    }
}

class BackupWorker(ctx: Context, p: WorkerParameters) : CoroutineWorker(ctx, p) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val ctx = applicationContext
        val prefs = ctx.getSharedPreferences("ms", 0)
        try {
            val repo = Repo(ctx)
            repo.level = when (prefs.getInt("zlevel", 1)) { 0 -> 1; 2 -> 9; else -> 6 }
            val src = prefs.getString("src", null)
            val worlds: List<LiveWorld> = when {
                prefs.getBoolean("szOn", false) && Sz.ready() -> Sz.listWorlds()
                src != null -> repo.scan(Uri.parse(src))
                else -> emptyList()
            }
            val existing = repo.load()
            val todo = worlds.filter { w ->
                val last = existing.filter { it.worldId == w.id }.maxOfOrNull { it.time }
                last == null || w.modified > last
            }
            var ok = 0
            var fail = 0
            val safe = prefs.getString("safe", null)
            for (w in todo) {
                try {
                    val b = repo.backupLive(w)
                    ok++
                    if (safe != null) repo.mirror(b, Uri.parse(safe))
                    if (prefs.getBoolean("dl", true)) repo.mirrorDownloads(b)
                } catch (e: Exception) { fail++ }
            }
            prefs.edit().putLong("lastAutoRun", System.currentTimeMillis()).putInt("lastAutoOk", ok).putInt("lastAutoFail", fail).apply()
            if (ok > 0) {
                prefs.edit().putLong("lastBackup", System.currentTimeMillis()).apply()
                repo.logAdd(Msg(R.string.msg_backed, ok))
                val all = repo.load()
                prefs.edit().putInt("wCount", all.size).putLong("wBytes", all.sumOf { it.size }).apply()
                WidgetUpdater.refreshAll(ctx)
                if (prefs.getBoolean("notifyDone", false)) Notifier.post(ctx, ctx.getString(R.string.app_name), ctx.getString(R.string.msg_backed, ok))
            }
            if (fail > 0) repo.logAdd(Msg(R.string.msg_backed_part, ok, fail))
            if (prefs.getBoolean("notifyLow", false)) {
                val free = Assistant.freeBytes()
                val total = Assistant.totalBytes()
                if (total > 0 && free * 100 / total < 10) Notifier.post(ctx, ctx.getString(R.string.app_name), ctx.getString(R.string.rc_space), 2)
            }
            if (fail > 0 && runAttemptCount < 2) Result.retry() else Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 2) Result.retry() else Result.failure()
        }
    }
}

class QuickBackupTile : TileService() {
    override fun onStartListening() {
        qsTile?.let { it.state = Tile.STATE_INACTIVE; it.label = getString(R.string.tile_label); it.updateTile() }
    }

    override fun onClick() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("quick_backup", true)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}
