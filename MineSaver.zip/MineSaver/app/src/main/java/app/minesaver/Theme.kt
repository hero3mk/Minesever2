package app.minesaver

import androidx.annotation.StringRes
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.luminance
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material3.Typography
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

val LocalDark = compositionLocalOf { true }

val Green = Color(0xFF5EEAA8)
val Blue = Color(0xFF6AA9FF)
val Violet = Color(0xFFB79CFF)
val Amber = Color(0xFFFFC857)
val Rose = Color(0xFFFF7A9A)

data class Look(
    @StringRes val nameRes: Int,
    val dark: Boolean,
    val bg: List<Color>,
    val card: Color,
    val cardBorder: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val stars: Boolean = false
)

private fun hx(h: Long) = Color(0xFF000000 or h)

private fun mk(@StringRes n: Int, dark: Boolean, b0: Long, b1: Long, card: Long, a1: Long, a2: Long, stars: Boolean = false): Look {
    val acc = hx(a1)
    return Look(
        n, dark, listOf(hx(b0), hx(b1), hx(b0)), hx(card),
        if (dark) Color(0x14FFFFFF) else Color(0x14000000),
        if (dark) Color(0xFFEEF1FA) else Color(0xFF14181F), if (dark) Color(0xFF9AA4BA) else Color(0xFF586170),
        acc, hx(a2), if (acc.luminance() > 0.45f) Color(0xFF0A0F14) else Color.White, stars
    )
}

/** 23 dark, 10 light, 8 Minecraft-inspired. Text and button colors are derived from luminance so they stay readable. */
val Looks: List<Look> = listOf(
    mk(R.string.lk_obsidian, true, 0x0B0C0F, 0x111318, 0x181B21, 0x34D399, 0x38BDF8),
    mk(R.string.lk_navy, true, 0x050B1F, 0x0A1330, 0x0F1B3D, 0x4DA3FF, 0xB06CFF),
    mk(R.string.lk_deepspace, true, 0x04030B, 0x0B0A1F, 0x141232, 0x7C83FF, 0x5EEAD4, true),
    mk(R.string.lk_cosmic, true, 0x060514, 0x0C1030, 0x161B3F, 0x5EEAA8, 0x6AA9FF, true),
    mk(R.string.lk_royal, true, 0x0E0720, 0x180B33, 0x24134A, 0xB388FF, 0xFFD166),
    mk(R.string.lk_amethyst, true, 0x100B1C, 0x171028, 0x221A38, 0xA78BFA, 0xF472B6),
    mk(R.string.lk_emerald, true, 0x03110C, 0x072018, 0x0D2E22, 0x2EE6A6, 0xD4AF37),
    mk(R.string.lk_forest, true, 0x08140E, 0x0C1D14, 0x13281C, 0x4ADE80, 0xA3E635),
    mk(R.string.lk_arcticnight, true, 0x061321, 0x0A2036, 0x102C48, 0x7DD3FC, 0xA5B4FC),
    mk(R.string.lk_cyber, true, 0x0A0614, 0x120A24, 0x1A1033, 0xFF2EC4, 0x00F0FF),
    mk(R.string.lk_neon, true, 0x04080F, 0x08141F, 0x0C1E2C, 0x00E5FF, 0xB6FF00),
    mk(R.string.lk_matrix, true, 0x000A04, 0x03140A, 0x061F10, 0x00FF66, 0x00C2A8),
    mk(R.string.lk_crimson, true, 0x140507, 0x200A0E, 0x2E1016, 0xFF4D6D, 0xFF9E7A),
    mk(R.string.lk_nether, true, 0x140808, 0x1E0D0D, 0x2A1313, 0xFB923C, 0xF43F5E),
    mk(R.string.lk_end, true, 0x0A0712, 0x120B1E, 0x1C1230, 0xD0A9FF, 0x7DF9C4, true),
    mk(R.string.lk_ocean, true, 0x061320, 0x0A1B2C, 0x112538, 0x38BDF8, 0x818CF8),
    mk(R.string.lk_titanium, true, 0x101214, 0x181B1F, 0x22262B, 0xB8C2CC, 0x7DD3FC),
    mk(R.string.lk_graphite, true, 0x0D0E10, 0x15171A, 0x1E2024, 0xF59E0B, 0x94A3B8),
    mk(R.string.lk_aurora, true, 0x04121A, 0x08202A, 0x0E2E3A, 0x5EF2B5, 0xA78BFA),
    mk(R.string.lk_sapphire, true, 0x050A1C, 0x0A1438, 0x101F52, 0x5B8CFF, 0x22D3EE),
    mk(R.string.lk_amoled, true, 0x000000, 0x050505, 0x0E0E0E, 0x00E5A0, 0x00B8FF),
    mk(R.string.lk_sunset, true, 0x1A0B14, 0x2A1020, 0x35172A, 0xFF7A59, 0xFF4D8D),
    mk(R.string.lk_desert, true, 0x15100A, 0x1F1810, 0x2A2116, 0xF2B33D, 0xE07A3E),
    mk(R.string.lk_arcticwhite, false, 0xF3F8FC, 0xE8F1F8, 0xFFFFFF, 0x0B7FD6, 0x00A3A3),
    mk(R.string.lk_pearl, false, 0xF7F5F2, 0xEFECE8, 0xFFFFFF, 0x7C6AF2, 0xE08AB5),
    mk(R.string.lk_lavender, false, 0xF4F0FB, 0xEAE3F6, 0xFFFFFF, 0x7C4DDB, 0xC05BD4),
    mk(R.string.lk_sakura, false, 0xFFF5F8, 0xFFEEF3, 0xFFFFFF, 0xD6336C, 0x9B5DE5),
    mk(R.string.lk_sandstone, false, 0xF7F1E6, 0xEFE5D3, 0xFFFDF8, 0xB7791F, 0x2F855A),
    mk(R.string.lk_cloud, false, 0xEFF6FF, 0xE1EEFB, 0xFFFFFF, 0x2563EB, 0x0891B2),
    mk(R.string.lk_mint, false, 0xF0FBF6, 0xE0F5EB, 0xFFFFFF, 0x059669, 0x0EA5A5),
    mk(R.string.lk_silver, false, 0xF1F3F6, 0xE5E9EE, 0xFFFFFF, 0x475569, 0x2563EB),
    mk(R.string.lk_ivory, false, 0xFBF7EE, 0xF3ECDC, 0xFFFEFA, 0xC2680C, 0x8A5A2B),
    mk(R.string.lk_minimal, false, 0xFAFAFA, 0xF0F0F0, 0xFFFFFF, 0x111827, 0x10B981),
    mk(R.string.lk_mcclassic, true, 0x2B1D12, 0x3A2818, 0x4A3520, 0x7CBD3A, 0xB8AFA5),
    mk(R.string.lk_redstone, true, 0x120505, 0x1E0A0A, 0x2C1010, 0xFF2B2B, 0xFFB020),
    mk(R.string.lk_netherite, true, 0x0F0D0F, 0x181519, 0x221E24, 0xB89B7A, 0x8B6F5A),
    mk(R.string.lk_enderdragon, true, 0x07040F, 0x100820, 0x1A0F33, 0xC084FC, 0xFF4DFF, true),
    mk(R.string.lk_cherry, true, 0x1E0F17, 0x2D1623, 0x3B1E2F, 0xFF9CC2, 0x9AE6B4),
    mk(R.string.lk_ancient, true, 0x061015, 0x0B1B22, 0x11272F, 0x2DD4BF, 0x38BDF8),
    mk(R.string.lk_trial, true, 0x14100A, 0x1F1A10, 0x2B2416, 0xD97706, 0x60A5FA),
    mk(R.string.lk_overworld, true, 0x0A1A0F, 0x10281A, 0x173826, 0x65C466, 0x5AB0E8)
)

val LookGroups: List<IntRange> = listOf(0..22, 23..32, 33..Looks.lastIndex)
const val DEFAULT_CSPEC = "1|260|190|0.3|1"

/** Custom theme from "dark|primaryHue|secondaryHue|backgroundLevel|gradient". */
fun customLook(spec: String): Look {
    val p = spec.split("|")
    val dark = p.getOrNull(0) != "0"
    val h1 = (p.getOrNull(1)?.toFloatOrNull() ?: 260f).coerceIn(0f, 360f)
    val h2 = (p.getOrNull(2)?.toFloatOrNull() ?: 190f).coerceIn(0f, 360f)
    val l = (p.getOrNull(3)?.toFloatOrNull() ?: 0.3f).coerceIn(0f, 1f)
    val grad = p.getOrNull(4) != "0"
    val acc = Color.hsv(h1, if (dark) 0.62f else 0.78f, if (dark) 0.98f else 0.72f)
    val acc2 = Color.hsv(h2, if (dark) 0.62f else 0.78f, if (dark) 0.98f else 0.72f)
    val b0 = if (dark) Color.hsv(h1, 0.55f, 0.04f + 0.10f * l) else Color.hsv(h1, 0.05f, 0.98f - 0.04f * l)
    val b1 = if (!grad) b0 else if (dark) Color.hsv(h2, 0.50f, 0.09f + 0.12f * l) else Color.hsv(h2, 0.10f, 0.94f - 0.05f * l)
    val card = if (dark) Color.hsv(h1, 0.35f, 0.15f + 0.12f * l) else Color.White
    return Look(
        R.string.lk_custom, dark, listOf(b0, b1, b0), card, if (dark) Color(0x14FFFFFF) else Color(0x14000000),
        if (dark) Color(0xFFEEF1FA) else Color(0xFF14181F), if (dark) Color(0xFF9AA4BA) else Color(0xFF586170),
        acc, acc2, if (acc.luminance() > 0.45f) Color(0xFF0A0F14) else Color.White
    )
}

/** The theme the user chose (used by widgets, which run outside Compose). Index = Looks.size means the custom theme. */
fun lookFromPrefs(ctx: android.content.Context): Look {
    val p = ctx.getSharedPreferences("ms", 0)
    val i = p.getInt("look", 0)
    return if (i == Looks.size) customLook(p.getString("cspec", DEFAULT_CSPEC) ?: DEFAULT_CSPEC) else Looks[i.coerceIn(0, Looks.lastIndex)]
}

val AccentChoices = listOf(
    Color(0xFF34D399), Color(0xFF38BDF8), Color(0xFFA78BFA), Color(0xFFF472B6), Color(0xFFFB923C), Color(0xFFFACC15)
)

val LocalLook = compositionLocalOf { Looks[0] }
val LocalStyle = compositionLocalOf { 0 }
val LocalReduce = compositionLocalOf { false }

fun Look.scheme(): ColorScheme {
    val solid = if (card.alpha < 0.95f) bg[1] else card
    return if (dark) darkColorScheme(
        primary = accent, onPrimary = onAccent, secondary = accent2, onSecondary = onAccent, tertiary = accent2,
        background = bg[0], onBackground = text, surface = solid, onSurface = text, onSurfaceVariant = textDim,
        surfaceContainer = solid, surfaceContainerHigh = solid, error = Color(0xFFFF6B7A), outline = cardBorder
    ) else lightColorScheme(
        primary = accent, onPrimary = onAccent, secondary = accent2, onSecondary = onAccent, tertiary = accent2,
        background = bg[0], onBackground = text, surface = solid, onSurface = text, onSurfaceVariant = textDim,
        surfaceContainer = solid, surfaceContainerHigh = solid, error = Color(0xFFD7263D), outline = cardBorder
    )
}

val DarkScheme = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF00382A), secondary = Blue, tertiary = Violet,
    background = Color(0xFF0B0A1F), surface = Color(0xFF14123A),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFB9B6DD), error = Color(0xFFFF8A9B)
)
val LightScheme = lightColorScheme(
    primary = Color(0xFF0B8F63), onPrimary = Color.White, secondary = Color(0xFF2563EB), tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF1F4FF), surface = Color.White,
    onSurface = Color(0xFF15133A), onSurfaceVariant = Color(0xFF5B5984), error = Color(0xFFD7263D)
)

private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val k: Int)

@Composable
fun AppBackground(look: Look, animate: Boolean = true, show: Boolean = true) {
    val cosmic = look.stars && show
    var tick by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animate, cosmic) {
        while (animate && cosmic) {
            delay(80)
            tick = (tick + 0.004f) % 1f
        }
    }
    val stars = remember {
        val r = Random(7)
        List(70) { Star(r.nextFloat(), r.nextFloat(), 0.7f + r.nextFloat() * 1.5f, r.nextFloat() * 6.283f, 1 + r.nextInt(3)) }
    }
    Box(Modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(Brush.verticalGradient(look.bg))
            if (!show) return@Canvas
            fun blob(cx: Float, cy: Float, r: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
            if (look.stars) {
                blob(w * 0.2f, h * 0.16f, w * 0.8f, Color(0x558B5CF6))
                blob(w * 0.95f, h * 0.58f, w * 0.9f, Color(0x4410B981))
                blob(w * 0.1f, h * 0.92f, w * 0.9f, Color(0x443B82F6))
            } else {
                blob(w * 0.5f, 0f, w * 0.95f, look.accent.copy(alpha = if (look.dark) 0.16f else 0.11f))
                blob(w, h * 0.72f, w * 0.8f, look.accent2.copy(alpha = if (look.dark) 0.09f else 0.07f))
                blob(0f, h * 0.38f, w * 0.6f, look.accent.copy(alpha = if (look.dark) 0.06f else 0.04f))
            }
        }
        if (cosmic) Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val a = tick * 6.2832f
            stars.forEach { s ->
                val tw = 0.5f + 0.5f * sin(a * s.k + s.ph)
                drawCircle(Color.White.copy(alpha = 0.25f + 0.75f * tw), s.r * density, Offset(s.x * w, s.y * h))
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val look = LocalLook.current
    val st = LocalStyle.current
    val shape = RoundedCornerShape(if (st == 1) 16.dp else 24.dp)
    val sheen = if (look.dark) Color.White.copy(alpha = 0.05f) else Color.Transparent
    var m = modifier.fillMaxWidth().clip(shape).background(look.card)
    if (st != 1) m = m.background(Brush.verticalGradient(listOf(sheen, Color.Transparent)))
    m = when (st) {
        2 -> m.border(1.dp, Brush.linearGradient(listOf(look.accent.copy(alpha = 0.7f), look.accent2.copy(alpha = 0.25f))), shape)
        1 -> m
        else -> m.border(0.5.dp, look.text.copy(alpha = if (look.dark) 0.07f else 0.10f), shape)
    }
    Column(m.padding(if (st == 1) 16.dp else 20.dp), content = content)
}

@Composable
fun Appear(i: Int, content: @Composable () -> Unit) {
    if (i > 7 || LocalReduce.current) { content(); return }
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(i * 60L); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(350)) + slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it / 8 }) { content() }
}

@Composable
fun Page(@StringRes title: Int?, onBack: (() -> Unit)? = null, content: LazyListScope.() -> Unit) =
    PageBase(title?.let { stringResource(it) }, onBack, content)

@Composable
fun PageBase(title: String?, onBack: (() -> Unit)?, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (title != null) item {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) Box(
                        Modifier.padding(end = 10.dp).size(40.dp).clip(CircleShape)
                            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).clickable(onClick = onBack),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, Modifier.size(22.dp)) }
                    Text(title, style = MaterialTheme.typography.headlineLarge, maxLines = 2)
                }
                Spacer(Modifier.height(8.dp))
                Box(
                    Modifier.padding(start = if (onBack != null) 50.dp else 0.dp).width(44.dp).height(4.dp).clip(RoundedCornerShape(2.dp))
                        .background(Brush.horizontalGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)))
                )
            }
        }
        content()
    }
}

@Composable
fun Act(@StringRes label: Int, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) =
    Act(stringResource(label), icon, tint, onClick)

@Composable
fun Act(label: String, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.13f)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelLarge)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Acts(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
fun Badge(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(6.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(5.dp))
        Text(text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).padding(4.dp)
    ) {
        options.forEachIndexed { i, o ->
            val bg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.primary else Color.Transparent, tween(300), label = "seg")
            val fg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(300), label = "segf")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg).clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = fg, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text) },
        confirmButton = { TextButton(onYes) { Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onNo) { Text(stringResource(R.string.cancel)) } }
    )
}


val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 28.sp, lineHeight = 36.sp, fontWeight = FontWeight.ExtraBold),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun GradientButton(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.secondary
    Row(
        modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(a, b))).clickable(onClick = onClick).padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimary)
        Spacer(Modifier.width(10.dp))
        Text(label, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun SectionTitle(text: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.width(3.dp).height(20.dp).clip(RoundedCornerShape(2.dp))
                .background(Brush.verticalGradient(listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.secondary)))
        )
        Spacer(Modifier.width(10.dp))
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
}
