package app.minesaver

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.material3.Typography
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

val LocalDark = compositionLocalOf { true }

val Green = Color(0xFF5EEAA8)
val Blue = Color(0xFF6AA9FF)
val Violet = Color(0xFFB79CFF)
val Amber = Color(0xFFFFC857)
val Rose = Color(0xFFFF7A9A)

val DarkScheme = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF00382A), secondary = Blue, tertiary = Violet,
    background = Color(0xFF0B0A1F), surface = Color(0xFF14123A),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFB9B6DD), error = Color(0xFFFF8A9B)
)
val LightScheme = lightColorScheme(
    primary = Color(0xFF0B8F63), onPrimary = Color.White, secondary = Color(0xFF2563EB), tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF1F4FF), surface = Color.White,
    onSurface = Color(0xFF15133A), onSurfaceVariant = Color(0xFF5B5984), error = Color(0xFFD7263D)
)

private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val k: Int)

@Composable
fun SpaceBackground(dark: Boolean, animate: Boolean = true, show: Boolean = true) {
    var tick by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animate, show) {
        while (animate && show) {
            delay(80)
            tick = (tick + 0.004f) % 1f
        }
    }
    val stars = remember {
        val r = Random(7)
        List(70) { Star(r.nextFloat(), r.nextFloat(), 0.7f + r.nextFloat() * 1.5f, r.nextFloat() * 6.283f, 1 + r.nextInt(3)) }
    }
    Box(Modifier.fillMaxSize()) {
        // Static layer: drawn once and cached, so it costs nothing while scrolling
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(
                Brush.verticalGradient(
                    if (dark) listOf(Color(0xFF060514), Color(0xFF0C1030), Color(0xFF0A2630))
                    else listOf(Color(0xFFF1F4FF), Color(0xFFE9F0FF), Color(0xFFE4F7EF))
                )
            )
            if (!show) return@Canvas
            fun blob(cx: Float, cy: Float, r: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
            blob(w * 0.2f, h * 0.16f, w * 0.8f, if (dark) Color(0x558B5CF6) else Color(0x33A78BFA))
            blob(w * 0.95f, h * 0.58f, w * 0.9f, if (dark) Color(0x4410B981) else Color(0x3334D399))
            blob(w * 0.1f, h * 0.92f, w * 0.9f, if (dark) Color(0x443B82F6) else Color(0x3360A5FA))
        }
        // Light animated layer: only a few dots, redrawn about 12 times a second
        if (show) Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val a = tick * 6.2832f
            val c = if (dark) Color.White else Color(0xFF6D5BD0)
            stars.forEach { s ->
                val tw = 0.5f + 0.5f * sin(a * s.k + s.ph)
                val alpha = if (dark) 0.25f + 0.75f * tw else 0.08f + 0.3f * tw
                drawCircle(c.copy(alpha = alpha), s.r * density, Offset(s.x * w, s.y * h))
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val dark = LocalDark.current
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(if (dark) listOf(Color(0x2EFFFFFF), Color(0x0FFFFFFF)) else listOf(Color(0xF2FFFFFF), Color(0xCCFFFFFF))))
            .border(
                1.dp,
                Brush.linearGradient(if (dark) listOf(Color(0x66FFFFFF), Color(0x14FFFFFF)) else listOf(Color(0xCCFFFFFF), Color(0x26000000))),
                shape
            )
            .padding(18.dp),
        content = content
    )
}

@Composable
fun Appear(i: Int, content: @Composable () -> Unit) {
    if (i > 7) { content(); return }
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(i * 60L); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(350)) + slideInVertically(tween(350, easing = FastOutSlowInEasing)) { it / 8 }) { content() }
}

@Composable
fun Page(@StringRes title: Int?, onBack: (() -> Unit)? = null, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (title != null) item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                Text(stringResource(title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            }
        }
        content()
    }
}

@Composable
fun Act(@StringRes label: Int, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) =
    Act(stringResource(label), icon, tint, onClick)

@Composable
fun Act(label: String, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(tint.copy(alpha = 0.16f))
            .border(1.dp, tint.copy(alpha = 0.35f), RoundedCornerShape(50)).clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelLarge)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Acts(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
fun Badge(text: String, color: Color) {
    Text(
        text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun Segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).padding(4.dp)
    ) {
        options.forEachIndexed { i, o ->
            val bg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.primary else Color.Transparent, tween(300), label = "seg")
            val fg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(300), label = "segf")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg).clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = fg, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text) },
        confirmButton = { TextButton(onYes) { Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onNo) { Text(stringResource(R.string.cancel)) } }
    )
}


val AppTypography = Typography(
    headlineLarge = TextStyle(fontSize = 30.sp, lineHeight = 38.sp, fontWeight = FontWeight.Bold),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 21.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 17.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodySmall = TextStyle(fontSize = 13.sp, lineHeight = 19.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun GradientButton(label: String, icon: ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val a = MaterialTheme.colorScheme.primary
    val b = MaterialTheme.colorScheme.secondary
    Row(
        modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(22.dp))
            .background(Brush.horizontalGradient(listOf(a, b))).clickable(onClick = onClick).padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimary)
        Spacer(Modifier.width(10.dp))
        Text(label, color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
fun SectionTitle(text: String, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(32.dp).clip(RoundedCornerShape(10.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = .18f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp)) }
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.titleMedium)
    }
}
