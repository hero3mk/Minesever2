package app.minesaver

import androidx.annotation.StringRes
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

val LocalDark = compositionLocalOf { true }

val Green = Color(0xFF5EEAA8)
val Blue = Color(0xFF6AA9FF)
val Violet = Color(0xFFB79CFF)
val Amber = Color(0xFFFFC857)
val Rose = Color(0xFFFF7A9A)

val DarkScheme = darkColorScheme(
    primary = Green, onPrimary = Color(0xFF00382A), secondary = Blue, tertiary = Violet,
    background = Color(0xFF0B0A1F), surface = Color(0xFF14123A),
    onSurface = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFB9B6DD), error = Color(0xFFFF8A9B)
)
val LightScheme = lightColorScheme(
    primary = Color(0xFF0B8F63), onPrimary = Color.White, secondary = Color(0xFF2563EB), tertiary = Color(0xFF7C3AED),
    background = Color(0xFFF1F4FF), surface = Color.White,
    onSurface = Color(0xFF15133A), onSurfaceVariant = Color(0xFF5B5984), error = Color(0xFFD7263D)
)

private class Star(val x: Float, val y: Float, val r: Float, val ph: Float, val k: Int)

@Composable
fun SpaceBackground(dark: Boolean, animate: Boolean = true, show: Boolean = true) {
    val tState: State<Float> = if (animate) {
        rememberInfiniteTransition(label = "space").animateFloat(0f, 1f, infiniteRepeatable(tween(40000, easing = LinearEasing)), label = "t")
    } else remember { mutableStateOf(0f) }
    val stars = remember {
        val r = Random(7)
        List(120) { Star(r.nextFloat(), r.nextFloat(), 0.6f + r.nextFloat() * 1.6f, r.nextFloat() * 6.283f, 1 + r.nextInt(4)) }
    }
    Crossfade(dark, animationSpec = tween(700), label = "bg") { d ->
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val t = tState.value
            val a = t * 6.2832f
            drawRect(
                Brush.verticalGradient(
                    if (d) listOf(Color(0xFF070514), Color(0xFF0E1236), Color(0xFF0B2A2F))
                    else listOf(Color(0xFFF1F4FF), Color(0xFFE9F0FF), Color(0xFFE4F7EF))
                )
            )
            if (!show) return@Canvas
            fun blob(cx: Float, cy: Float, r: Float, c: Color) =
                drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), center = Offset(cx, cy), radius = r), r, Offset(cx, cy))
            blob(w * (0.2f + 0.05f * sin(a)), h * 0.18f, w * 0.75f, if (d) Color(0x558B5CF6) else Color(0x33A78BFA))
            blob(w * 0.95f, h * (0.55f + 0.04f * sin(a + 1f)), w * 0.85f, if (d) Color(0x4410B981) else Color(0x3334D399))
            blob(w * 0.1f, h * 0.92f, w * 0.85f, if (d) Color(0x443B82F6) else Color(0x3360A5FA))
            val starColor = if (d) Color.White else Color(0xFF6D5BD0)
            stars.forEach { s ->
                val tw = 0.5f + 0.5f * sin(a * s.k + s.ph)
                val alpha = if (d) 0.2f + 0.8f * tw else 0.08f + 0.3f * tw
                drawCircle(starColor.copy(alpha = alpha), s.r * density, Offset(s.x * w, s.y * h + sin(a * s.k + s.ph) * 4.dp.toPx()))
            }
            if (d) {
                val p = (t * 3f) % 1f
                if (p < 0.3f) {
                    val q = p / 0.3f
                    val x = w * (1.1f - 0.9f * q)
                    val y = h * (0.05f + 0.25f * q)
                    drawLine(
                        Brush.linearGradient(listOf(Color.White, Color.Transparent), start = Offset(x, y), end = Offset(x + 140f, y - 70f)),
                        Offset(x, y), Offset(x + 140f, y - 70f), strokeWidth = 3f, cap = StrokeCap.Round
                    )
                }
            }
        }
    }
}

@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val dark = LocalDark.current
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(if (dark) Color(0x1FFFFFFF) else Color(0xB8FFFFFF))
            .border(
                1.dp,
                Brush.linearGradient(if (dark) listOf(Color(0x55FFFFFF), Color(0x11FFFFFF)) else listOf(Color(0x99FFFFFF), Color(0x22000000))),
                shape
            )
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Appear(i: Int, content: @Composable () -> Unit) {
    var v by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(min(i, 6) * 70L); v = true }
    AnimatedVisibility(v, enter = fadeIn(tween(450)) + slideInVertically(tween(450, easing = FastOutSlowInEasing)) { it / 6 }) { content() }
}

@Composable
fun Page(@StringRes title: Int?, onBack: (() -> Unit)? = null, content: LazyListScope.() -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(20.dp, 12.dp, 20.dp, 120.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (title != null) item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                Text(stringResource(title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            }
        }
        content()
    }
}

@Composable
fun Act(@StringRes label: Int, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) =
    Act(stringResource(label), icon, tint, onClick)

@Composable
fun Act(label: String, icon: ImageVector, tint: Color = MaterialTheme.colorScheme.primary, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(14.dp)).background(tint.copy(alpha = 0.14f)).clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = tint, style = MaterialTheme.typography.labelLarge)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Acts(content: @Composable () -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
}

@Composable
fun Badge(text: String, color: Color) {
    Text(
        text, color = color, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.16f)).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun Segment(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)).padding(4.dp)
    ) {
        options.forEachIndexed { i, o ->
            val bg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.primary else Color.Transparent, tween(300), label = "seg")
            val fg by animateColorAsState(if (i == selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, tween(300), label = "segf")
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).background(bg).clickable { onSelect(i) }.padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) { Text(o, color = fg, fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun ConfirmDialog(text: String, onYes: () -> Unit, onNo: () -> Unit) {
    AlertDialog(
        onDismissRequest = onNo,
        text = { Text(text) },
        confirmButton = { TextButton(onYes) { Text(stringResource(R.string.confirm), color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onNo) { Text(stringResource(R.string.cancel)) } }
    )
}
