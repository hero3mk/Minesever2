package app.minesaver

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.core.view.WindowCompat
import androidx.navigation.NavBackStackEntry
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class MainActivity : AppCompatActivity() {
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { App(vm) }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onStart() {
        super.onStart()
        vm.refreshSz()
        vm.appStarted()
    }

    /** Files sent/opened with MineSaver (e.g. Minecraft "Export World" -> share). */
    private fun handle(i: Intent?) {
        if (i == null) return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_VIEW -> listOfNotNull(i.data)
            Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList<Uri>()
            else -> emptyList()
        }
        if (uris.isNotEmpty()) vm.import(uris)
    }
}

private val tabs = listOf("home", "worlds", "backups", "tools", "settings")

private fun idx(r: String?) = when (r) {
    "home" -> 0; "worlds" -> 1; "backups" -> 2; "tools" -> 3; "settings" -> 4; "restore" -> 5; "transfer" -> 6; "activity" -> 7; "storage" -> 8; else -> 9
}

private val enterT: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = {
    val fwd = idx(targetState.destination.route) >= idx(initialState.destination.route)
    slideIntoContainer(
        if (fwd) AnimatedContentTransitionScope.SlideDirection.Start else AnimatedContentTransitionScope.SlideDirection.End,
        tween<IntOffset>(320, easing = FastOutSlowInEasing), initialOffset = { it / 6 }
    ) + fadeIn(tween(320))
}

private val exitT: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = {
    val fwd = idx(targetState.destination.route) >= idx(initialState.destination.route)
    slideOutOfContainer(
        if (fwd) AnimatedContentTransitionScope.SlideDirection.Start else AnimatedContentTransitionScope.SlideDirection.End,
        tween<IntOffset>(320, easing = FastOutSlowInEasing), targetOffset = { it / 6 }
    ) + fadeOut(tween(220))
}

@Composable
fun App(vm: MainVm) {
    val sys = isSystemInDarkTheme()
    val dark = when (vm.theme) { 1 -> false; 2 -> true; else -> sys }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    val accD = when (vm.accent) { 1 -> Color(0xFF22D3EE); 2 -> Violet; 3 -> Blue; else -> Green }
    val accL = when (vm.accent) { 1 -> Color(0xFF0891B2); 2 -> Color(0xFF7C3AED); 3 -> Color(0xFF2563EB); else -> Color(0xFF0B8F63) }
    CompositionLocalProvider(LocalDark provides dark) {
        MaterialTheme(colorScheme = if (dark) DarkScheme.copy(primary = accD, onPrimary = Color(0xFF00201A)) else LightScheme.copy(primary = accL), typography = AppTypography) {
            val nav = rememberNavController()
            val snack = remember { SnackbarHostState() }
            val entry by nav.currentBackStackEntryAsState()
            val route = entry?.destination?.route ?: "home"

            vm.toast?.let { m ->
                val text = stringResource(m.res, *m.args)
                LaunchedEffect(m) { snack.showSnackbar(text); vm.toast = null }
            }

            Box(Modifier.fillMaxSize()) {
                SpaceBackground(dark, vm.anim, vm.bg)
                Scaffold(
                    containerColor = Color.Transparent,
                    contentWindowInsets = WindowInsets(0),
                    snackbarHost = { SnackbarHost(snack, Modifier.navigationBarsPadding().padding(bottom = 84.dp)) }
                ) {
                    NavHost(
                        nav, "home", Modifier.fillMaxSize(),
                        enterTransition = enterT, exitTransition = exitT, popEnterTransition = enterT, popExitTransition = exitT
                    ) {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("worlds") { WorldsScreen(vm, nav) }
                        composable("backups") { BackupsScreen(vm, nav) }
                        composable("transfer") { TransferScreen(vm, nav) }
                        composable("tools") { ToolsScreen(vm) }
                        composable("activity") { ActivityScreen(vm, nav) }
                        composable("storage") { StorageScreen(vm, nav) }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("restore") { RestoreScreen(vm, nav) }
                        composable("about") { AboutScreen(vm, nav) }
                    }
                }
                AnimatedVisibility(
                    route in tabs, Modifier.align(Alignment.BottomCenter),
                    enter = slideInVertically(tween(400)) { it } + fadeIn(tween(400)),
                    exit = slideOutVertically(tween(300)) { it } + fadeOut(tween(300))
                ) {
                    BottomBar(route) { r ->
                        nav.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                    }
                }
                if (vm.locked) LockScreen(vm)
                AnimatedVisibility(
                    vm.busy != null, Modifier.align(Alignment.TopCenter),
                    enter = slideInVertically(tween(300)) { -it } + fadeIn(), exit = slideOutVertically(tween(300)) { -it } + fadeOut()
                ) {
                    vm.busy?.let { m ->
                        Row(
                            Modifier.statusBarsPadding().padding(top = 8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xE6101030)).padding(14.dp, 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Green)
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(m.res), color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

private class Tab(val route: String, val icon: ImageVector, val label: Int)

@Composable
fun BottomBar(route: String, onGo: (String) -> Unit) {
    val dark = LocalDark.current
    val items = listOf(
        Tab("home", Icons.Rounded.Home, R.string.nav_home),
        Tab("worlds", Icons.Rounded.Public, R.string.nav_worlds),
        Tab("backups", Icons.Rounded.Inventory2, R.string.nav_backups),
        Tab("tools", Icons.Rounded.Build, R.string.nav_tools),
        Tab("settings", Icons.Rounded.Settings, R.string.nav_settings)
    )
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.navigationBarsPadding().padding(12.dp, 0.dp, 12.dp, 12.dp).fillMaxWidth().clip(shape)
            .background(if (dark) Color(0xE6141240) else Color(0xE6FFFFFF))
            .border(1.dp, if (dark) Color(0x33FFFFFF) else Color(0x22000000), shape).padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { t ->
            val sel = t.route == route
            val bg by animateColorAsState(if (sel) MaterialTheme.colorScheme.primary.copy(alpha = .22f) else Color.Transparent, tween(300), label = "tab")
            Row(
                Modifier.clip(RoundedCornerShape(24.dp)).background(bg)
                    .then(if (sel) Modifier.border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = .45f), RoundedCornerShape(24.dp)) else Modifier)
                    .clickable { onGo(t.route) }
                    .padding(horizontal = 14.dp, vertical = 12.dp).animateContentSize(tween(300)),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(t.icon, null, tint = if (sel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                AnimatedVisibility(sel) {
                    Text(
                        stringResource(t.label), Modifier.padding(start = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge
                    )
                }
            }
        }
    }
}
