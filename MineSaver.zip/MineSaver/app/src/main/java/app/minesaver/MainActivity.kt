package app.minesaver

import android.app.Activity
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.animation.core.animateDpAsState
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Apps
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.content.IntentCompat
import androidx.core.view.WindowCompat
import androidx.navigation.NavBackStackEntry
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController

class MainActivity : AppCompatActivity() {
    private val vm: MainVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent { App(vm) { promptBiometric() } }
        if (savedInstanceState == null) handle(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onStart() {
        super.onStart()
        vm.relockIfNeeded()
        vm.refreshSz()
        vm.appStarted()
    }

    override fun onStop() {
        super.onStop()
        vm.markBackground()
    }

    private fun promptBiometric() {
        val bm = BiometricManager.from(this)
        if (bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) return
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                vm.unlockBio()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.app_name))
            .setNegativeButtonText(getString(R.string.cancel))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }

    /** Files sent/opened with MineSaver (e.g. Minecraft "Export World" -> share). */
    private fun handle(i: Intent?) {
        if (i == null) return
        val uris: List<Uri> = when (i.action) {
            Intent.ACTION_VIEW -> listOfNotNull(i.data)
            Intent.ACTION_SEND -> listOfNotNull(IntentCompat.getParcelableExtra(i, Intent.EXTRA_STREAM, Uri::class.java))
            Intent.ACTION_SEND_MULTIPLE -> IntentCompat.getParcelableArrayListExtra(i, Intent.EXTRA_STREAM, Uri::class.java) ?: emptyList<Uri>()
            else -> emptyList()
        }
        if (uris.isNotEmpty()) vm.import(uris)
        i.getStringExtra("route")?.let { vm.pendingRoute = it }
        if (i.getBooleanExtra("quick_backup", false)) { i.removeExtra("quick_backup"); vm.backupAll() }
    }
}

private val tabs = listOf("home", "worlds", "backups", "atlas", "more")

private fun idx(r: String?) = when (r) {
    "home" -> 0; "worlds" -> 1; "backups" -> 2; "atlas" -> 3; "more" -> 4; "settings" -> 5; "tools" -> 6; "restore" -> 7; "transfer" -> 8; "activity" -> 9; "storage" -> 10; else -> 11
}

private val enterT: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = {
    val fwd = idx(targetState.destination.route) >= idx(initialState.destination.route)
    slideIntoContainer(
        if (fwd) AnimatedContentTransitionScope.SlideDirection.Start else AnimatedContentTransitionScope.SlideDirection.End,
        tween<IntOffset>(320, easing = FastOutSlowInEasing), initialOffset = { it / 6 }
    ) + fadeIn(tween(320))
}

private val enterF: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = { fadeIn(tween(120)) }
private val exitF: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = { fadeOut(tween(80)) }

private val exitT: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = {
    val fwd = idx(targetState.destination.route) >= idx(initialState.destination.route)
    slideOutOfContainer(
        if (fwd) AnimatedContentTransitionScope.SlideDirection.Start else AnimatedContentTransitionScope.SlideDirection.End,
        tween<IntOffset>(320, easing = FastOutSlowInEasing), targetOffset = { it / 6 }
    ) + fadeOut(tween(220))
}

@Composable
fun App(vm: MainVm, onBio: () -> Unit) {
    var splash by rememberSaveable { mutableStateOf(true) }
    val l = if (vm.look == Looks.size) vm.customTheme else Looks[vm.look.coerceIn(0, Looks.lastIndex)]
    Box(Modifier.fillMaxSize()) {
        AppMain(vm, onBio)
        AnimatedVisibility(splash, exit = fadeOut(tween(380))) { Splash(vm.reduce, l) { splash = false } }
    }
}

@Composable
private fun Splash(reduce: Boolean, look: Look, onDone: () -> Unit) {
    val scale = remember { Animatable(if (reduce) 1f else 0.72f) }
    val alpha = remember { Animatable(if (reduce) 1f else 0f) }
    LaunchedEffect(Unit) {
        if (reduce) delay(250) else {
            launch { scale.animateTo(1f, tween(700, easing = FastOutSlowInEasing)) }
            alpha.animateTo(1f, tween(520))
            delay(420)
        }
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(look.bg)), contentAlignment = Alignment.Center) {
        Column(Modifier.graphicsLayer { scaleX = scale.value; scaleY = scale.value; this.alpha = alpha.value }, horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_logo), null, Modifier.size(112.dp))
            Spacer(Modifier.height(18.dp))
            Text(stringResource(R.string.app_name), style = AppTypography.headlineLarge, color = look.text)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.tagline), style = AppTypography.bodySmall, color = look.accent)
        }
    }
}

@Composable
private fun AppMain(vm: MainVm, onBio: () -> Unit) {
    val sys = isSystemInDarkTheme()
    val base = if (vm.look == Looks.size) vm.customTheme else Looks[vm.look.coerceIn(0, Looks.lastIndex)]
    val chosen = when {
        vm.follow && !sys -> Looks.first { !it.dark }
        vm.follow && sys && !base.dark -> Looks[0]
        else -> base
    }
    val accent = if (vm.accent in 1..AccentChoices.size) AccentChoices[vm.accent - 1] else chosen.accent
    val look = chosen.copy(accent = accent)
    val dark = look.dark
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window
        if (w != null) {
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    val baseDensity = LocalDensity.current
    val fs = when (vm.fontScale) { 0 -> 0.9f; 2 -> 1.15f; else -> 1f }
    CompositionLocalProvider(
        LocalLook provides look,
        LocalStyle provides vm.style,
        LocalReduce provides vm.reduce,
        LocalDark provides dark,
        LocalContentColor provides look.text,
        LocalDensity provides Density(baseDensity.density, baseDensity.fontScale * fs)
    ) {
        MaterialTheme(colorScheme = look.scheme(), typography = AppTypography) {
            val nav = rememberNavController()
            val snack = remember { SnackbarHostState() }
            val entry by nav.currentBackStackEntryAsState()
            val route = entry?.destination?.route ?: "home"
            LaunchedEffect(vm.pendingRoute) {
                val r = vm.pendingRoute
                if (r != null) {
                    vm.pendingRoute = null
                    if (r in setOf("home", "worlds", "backups", "atlas", "more", "settings", "tools", "search", "game")) nav.navigate(r) { launchSingleTop = true }
                }
            }

            vm.toast?.let { m ->
                val text = stringResource(m.res, *m.args)
                LaunchedEffect(m) { snack.showSnackbar(text); vm.toast = null }
            }

            Box(Modifier.fillMaxSize()) {
                AppBackground(look, vm.anim && !vm.reduce, vm.bg)
                Scaffold(
                    containerColor = Color.Transparent,
                    contentColor = look.text,
                    contentWindowInsets = WindowInsets(0),
                    snackbarHost = { SnackbarHost(snack, Modifier.navigationBarsPadding().padding(bottom = 84.dp)) }
                ) {
                    NavHost(
                        nav, "home", Modifier.fillMaxSize(),
                        enterTransition = if (vm.reduce) enterF else enterT, exitTransition = if (vm.reduce) exitF else exitT,
                        popEnterTransition = if (vm.reduce) enterF else enterT, popExitTransition = if (vm.reduce) exitF else exitT
                    ) {
                        composable("home") { HomeScreen(vm, nav) }
                        composable("worlds") { WorldsScreen(vm, nav) }
                        composable("backups") { BackupsScreen(vm, nav) }
                        composable("transfer") { TransferScreen(vm, nav) }
                        composable("tools") { ToolsScreen(vm, nav) }
                        composable("activity") { ActivityScreen(vm, nav) }
                        composable("storage") { StorageScreen(vm, nav) }
                        composable("settings") { SettingsScreen(vm, nav) }
                        composable("restore") { RestoreScreen(vm, nav) }
                        composable("about") { AboutScreen(vm, nav) }
                        composable("world") { WorldDetailScreen(vm, nav) }
                        composable("compare") { CompareScreen(vm, nav) }
                        composable("seeds") { SeedsScreen(vm, nav) }
                        composable("places") { PlacesScreen(vm, nav) }
                        composable("help") { HelpScreen(vm, nav) }
                        composable("more") { MoreScreen(vm, nav) }
                        composable("atlas") { AtlasScreen(vm, nav) }
                        composable("map") { MapScreen(vm, nav) }
                        composable("addons") { AddonsScreen(vm, nav) }
                        composable("addon") { AddonDetailScreen(vm, nav) }
                        composable("addon_check") { AddonCheckScreen(vm, nav) }
                        composable("dna") { DnaScreen(vm, nav) }
                        composable("privacy") { PrivacyScreen(vm, nav) }
                        composable("recovery") { RecoveryScreen(vm, nav) }
                        composable("studio") { StudioScreen(vm, nav) }
                        composable("manifest") { ManifestBuilderScreen(vm, nav) }
                        composable("inspect") { InspectScreen(vm, nav) }
                        composable("assistant") { AssistantScreen(vm, nav) }
                        composable("servers") { ServersScreen(vm, nav) }
                        composable("trash") { TrashScreen(vm, nav) }
                        composable("themestudio") { ThemeStudioScreen(vm, nav) }
                        composable("unwritten") { UnwrittenScreen(vm, nav) }
                        composable("cmpb") { CompareBackupsScreen(vm, nav) }
                        composable("explorer") { ExplorerScreen(vm, nav) }
                        composable("dataprot") { DataProtectionScreen(vm, nav) }
                        composable("automation") { AutomationScreen(vm, nav) }
                        composable("encrypt") { EncryptScreen(vm, nav) }
                        composable("migration") { MigrationScreen(vm, nav) }
                        composable("search") { SearchScreen(vm, nav) }
                        composable("command") { CommandScreen(vm, nav) }
                        composable("game") { GameScreen(vm, nav) }
                        composable("devtools") { DevToolsScreen(vm, nav) }
                        composable("builds") { BuildsScreen(vm, nav) }
                        composable("build") { BuildDetailScreen(vm, nav) }
                        composable("journal") { JournalScreen(vm, nav) }
                        composable("repair") { RepairScreen(vm, nav) }
                        composable("status") { FeatureStatusScreen(vm, nav) }
                        composable("changelog") { ChangelogScreen(vm, nav) }
                    }
                }
                AnimatedVisibility(
                    route in tabs, Modifier.align(Alignment.BottomCenter),
                    enter = slideInVertically(tween(300)) { it } + fadeIn(tween(300)),
                    exit = slideOutVertically(tween(220)) { it } + fadeOut(tween(220))
                ) {
                    BottomBar(route) { r ->
                        nav.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                    }
                }
                if (vm.welcome && !vm.locked) WelcomeDialog(vm, nav)
                if (vm.locked) LockScreen(vm, onBio)
                AnimatedVisibility(
                    vm.busy != null, Modifier.align(Alignment.TopCenter),
                    enter = slideInVertically(tween(300)) { -it } + fadeIn(), exit = slideOutVertically(tween(300)) { -it } + fadeOut()
                ) {
                    vm.busy?.let { m ->
                        Row(
                            Modifier.statusBarsPadding().padding(top = 8.dp).clip(RoundedCornerShape(20.dp)).background(Color(0xF0111827)).padding(14.dp, 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(m.res), color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

private class Tab(val route: String, val icon: ImageVector, val label: Int)

@Composable
fun BottomBar(route: String, onGo: (String) -> Unit) {
    val look = LocalLook.current
    val items = listOf(
        Tab("home", Icons.Rounded.Home, R.string.nav_home),
        Tab("worlds", Icons.Rounded.Public, R.string.nav_worlds),
        Tab("backups", Icons.Rounded.Inventory2, R.string.nav_backups),
        Tab("atlas", Icons.Rounded.Map, R.string.nav_atlas),
        Tab("more", Icons.Rounded.Apps, R.string.nav_more)
    )
    val shape = RoundedCornerShape(30.dp)
    val prim = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant
    Row(
        Modifier.navigationBarsPadding().padding(14.dp, 0.dp, 14.dp, 12.dp).fillMaxWidth().clip(shape)
            .background(if (look.card.alpha < 0.95f) look.bg[1] else look.card)
            .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = if (look.dark) 0.06f else 0f), Color.Transparent)))
            .border(0.5.dp, look.text.copy(alpha = 0.10f), shape).padding(horizontal = 6.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { t ->
            val sel = t.route == route
            val w by animateDpAsState(if (sel) 60.dp else 40.dp, tween(280), label = "tabw")
            val bg by animateColorAsState(if (sel) prim.copy(alpha = .20f) else Color.Transparent, tween(280), label = "tab")
            Column(
                Modifier.weight(1f).clickable(indication = null, interactionSource = remember { MutableInteractionSource() }) { onGo(t.route) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.width(w).height(30.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
                    Icon(t.icon, null, tint = if (sel) prim else dim, modifier = Modifier.size(22.dp))
                }
                Text(
                    stringResource(t.label), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelSmall,
                    color = if (sel) prim else dim, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal
                )
            }
        }
    }
}
