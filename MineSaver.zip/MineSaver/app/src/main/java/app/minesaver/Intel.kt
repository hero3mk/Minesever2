package app.minesaver

data class ServerProfile(val id: String, val name: String, val host: String, val port: String, val version: String, val notes: String)
data class SavedSeed(val id: String, val name: String, val seed: String, val note: String)
data class SavedPlace(val id: String, val name: String, val type: Int, val x: String, val y: String, val z: String, val world: String)

data class WorldInfo(
    val name: String?, val seed: Long?, val gameType: Int?, val difficulty: Int?, val hardcore: Boolean?,
    val lastPlayed: Long?, val ticks: Long?, val spawn: String?, val version: String?, val cheats: Boolean?, val generator: Int?
)

/** Minimal reader for Bedrock's little-endian NBT (level.dat). */
object Nbt {
    private class R(val b: ByteArray, var p: Int) {
        fun u8(): Int = b[p++].toInt() and 255
        fun i16(): Int { val lo = u8(); val hi = u8(); return (lo or (hi shl 8)).toShort().toInt() }
        fun i32(): Int {
            val v = (b[p].toInt() and 255) or ((b[p + 1].toInt() and 255) shl 8) or
                ((b[p + 2].toInt() and 255) shl 16) or ((b[p + 3].toInt() and 255) shl 24)
            p += 4
            return v
        }
        fun i64(): Long {
            var v = 0L
            for (i in 0 until 8) v = v or ((b[p + i].toLong() and 255L) shl (8 * i))
            p += 8
            return v
        }
        fun str(): String {
            val n = i16() and 0xFFFF
            val s = String(b, p, n, Charsets.UTF_8)
            p += n
            return s
        }
    }

    fun parse(bytes: ByteArray, skip: Int = 8): Map<String, Any>? {
        return try {
            val r = R(bytes, skip)
            if (r.u8() != 10) return null
            r.str()
            read(r, 10) as Map<String, Any>
        } catch (e: Exception) {
            null
        }
    }

    private fun read(r: R, t: Int): Any {
        when (t) {
            1 -> return r.u8().toByte()
            2 -> return r.i16().toShort()
            3 -> return r.i32()
            4 -> return r.i64()
            5 -> return Float.fromBits(r.i32())
            6 -> return Double.fromBits(r.i64())
            7 -> {
                val n = r.i32()
                val a = r.b.copyOfRange(r.p, r.p + n)
                r.p += n
                return a
            }
            8 -> return r.str()
            9 -> {
                val et = r.u8()
                val n = r.i32()
                val l = ArrayList<Any>()
                for (i in 0 until n) l.add(read(r, et))
                return l
            }
            10 -> {
                val m = LinkedHashMap<String, Any>()
                while (true) {
                    val tt = r.u8()
                    if (tt == 0) break
                    val name = r.str()
                    m[name] = read(r, tt)
                }
                return m
            }
            11 -> { val n = r.i32(); return IntArray(n) { r.i32() } }
            12 -> { val n = r.i32(); return LongArray(n) { r.i64() } }
            else -> throw IllegalStateException("bad tag $t")
        }
    }
}

fun worldInfo(bytes: ByteArray): WorldInfo? {
    val m = Nbt.parse(bytes) ?: return null
    fun num(k: String): Long? = (m[k] as? Number)?.toLong()
    fun flag(k: String): Boolean? = num(k)?.let { it != 0L }
    val ver = (m["lastOpenedWithVersion"] as? List<*>)?.mapNotNull { (it as? Number)?.toInt() }?.take(3)?.joinToString(".")
    val sx = num("SpawnX")
    val sy = num("SpawnY")
    val sz = num("SpawnZ")
    return WorldInfo(
        name = m["LevelName"] as? String,
        seed = num("RandomSeed"),
        gameType = num("GameType")?.toInt(),
        difficulty = num("Difficulty")?.toInt(),
        hardcore = flag("IsHardcore") ?: flag("hardcore"),
        lastPlayed = num("LastPlayed")?.let { it * 1000L },
        ticks = num("Time") ?: num("currentTick"),
        spawn = if (sx != null && sy != null && sz != null) "$sx, $sy, $sz" else null,
        version = ver?.takeIf { it.isNotEmpty() },
        cheats = flag("commandsEnabled") ?: flag("cheatsEnabled"),
        generator = num("Generator")?.toInt()
    )
}
