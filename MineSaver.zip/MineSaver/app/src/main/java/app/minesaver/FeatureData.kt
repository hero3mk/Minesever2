package app.minesaver

/** Single source of truth for the in-app Feature Status page (generated, mirrors docs/FEATURES.md). Codes: F full, P partial, N not implemented, A blocked by Android, B needs backend, E needs external engine. */
val FEATURE_DATA = """
World Vault|Manual backup|F
World Vault|One-tap backup (all worlds)|F
World Vault|Automatic backup of changed worlds (on app open)|F
World Vault|Scheduled backup (WorkManager, subject to Android limits)|P
World Vault|Backup history and timeline|F
World Vault|Backup verification (SHA-256 + archive check)|F
World Vault|Corrupted backup detection|F
World Vault|Backup health / recovery readiness score|P
World Vault|Safe restore (never overwrites, new folder)|F
World Vault|Emergency backup before restore|F
World Vault|Restore preview and confirmation|F
World Vault|Restore into the game folder (Shizuku or folder access)|P
World Vault|Open backup in Minecraft|P
World Vault|MCWORLD import and export|F
World Vault|Backup import/export/share|F
World Vault|Compression level setting|F
World Vault|Optional password encryption (.mse export/import)|P
World Vault|Backup names and notes|F
World Vault|Backup comparison (files and metadata)|F
World Vault|File-level restore (extract selected files to a folder)|P
World Vault|Recently deleted (undo) for backups|F
World Vault|Retention and expiry review (never silent deletion)|P
World Vault|Multiple storage locations (app, Downloads, safe folder)|F
World Vault|Backup migration between devices (share + checksums)|P
World Vault|Backup failure recovery (rebuild index, clean temp files)|P
World Vault|Operation logs|F
World Vault|Incremental backup|N
World Vault|Pause and resume operations|N
World Vault|Backup progress percentage|N
World Library|World profile (name, icon, seed, version, mode, difficulty, cheats, size)|F
World Library|Java edition worlds|N
World Library|Search, sort, filters, favorites, tags, notes|F
World Library|Worlds without backup / needing review|F
World Library|Open the world folder|A
World Library|World comparison|F
Seed Intelligence|Seed library with edition, version, category, favorites|F
Seed Intelligence|Seed verification against a world|F
Seed Intelligence|Seed comparison and text import/export|F
Seed Intelligence|Coordinates book with dimensions, export, sharing, distances|F
Seed Intelligence|Slime chunk finder and map layer (Bedrock, community algorithm)|P
Seed Intelligence|Seed map (biomes and terrain from a seed)|E
Seed Intelligence|Structure finder|E
Seed Intelligence|Biome finder|E
Seed Intelligence|Seed finder / recommendations / difficulty|E
Seed Intelligence|Map export to image|N
World Analyzer|Read level.dat (seed, version, mode, difficulty, spawn)|F
World Analyzer|Explored chunk map from the world database (LevelDB)|P
World Analyzer|Exploration tracker and inspector|P
World Analyzer|Health check (archive, database files, version, packs)|F
World Analyzer|Statistics, age, sessions (observed)|P
World Analyzer|Size evolution chart and metadata history|P
World Analyzer|Route planner (straight line)|F
World Analyzer|Game rules viewer|N
World Analyzer|World information export|P
World Analyzer|Storage forecast (linear estimate)|P
Add-on Intelligence|Library for mcpack/mcaddon/zip|F
Add-on Intelligence|Manifest analysis, UUID and duplicate detection|F
Add-on Intelligence|Dependency checks and map|F
Add-on Intelligence|Engine version comparison|P
Add-on Intelligence|Safety scan (paths, executables, size, duplicates)|P
Add-on Intelligence|Pack repair (JSON comments, trailing commas, BOM)|P
Add-on Intelligence|Collections|F
Add-on Intelligence|Add-ons used by each world|F
Add-on Intelligence|File path conflict detection between packs|N
Add-on Intelligence|Load order manager|N
Add-on Intelligence|Script API compatibility checks|N
Add-on Intelligence|Update tracker and notifications|B
Add-on Intelligence|Compatibility database|N
File Manager|ZIP explorer with search, preview, integrity check|F
File Manager|Extract selected files with path-safety checks|F
File Manager|Hash tool, signature inspector, hex viewer|F
File Manager|Minecraft folder explorer (Shizuku)|N
File Manager|Move and delete files in the game folder|A
File Manager|Folder comparison and synchronization|N
Content Center|Content library (worlds, add-ons, screenshots in their own pages)|P
Content Center|Unified content center page|N
Minecraft Companion|Encyclopedia, crafting and mob databases|N
Build Studio|Projects, status, coordinates, materials, size calculator, before/after photos|P
Play Journal|Manual sessions, playtime statistics, challenges|P
Play Journal|World journal, goals and screenshots|P
Play Journal|Automatic session logging|A
Smart Automation|Scheduled backups with charging and storage rules|P
Smart Automation|Notifications for completed operations and low storage|P
Smart Automation|Retry on failure|P
Smart Automation|Custom automation rules builder|N
Cloud and Community|Cloud sync, accounts, multi-device|B
Cloud and Community|Community sharing, reviews, profiles|B
Experience|41 themes in three groups with live previews and accent colors|F
Experience|Theme Studio (custom theme, copy/paste code, live preview)|P
Experience|Animated splash, new dashboard and floating navigation bar|P
Experience|Reduced motion|F
Experience|Arabic and English with RTL|F
Experience|Global search with history|F
Experience|Command center|F
Experience|Quick Settings tile|P
Experience|Home screen widgets 2x2, 4x2, 4x4 (theme aware, rotating panels, refresh after operations)|P
Experience|Fingerprint unlock and auto-lock|F
Experience|Dashboard customization and drag and drop|N
Experience|Custom app icons|N
Experience|Game status and launcher|F
Data Protection|Integrity check and database rebuild|F
Data Protection|Permission and storage access monitor|F
Data Protection|Diagnostics report export|F
Data Protection|Configuration export and import|F
Data Protection|Crash reports|N
Data Protection|Privacy center with real permission list|F
Developer Tools|JSON validate, format, minify, clean, compare|F
Developer Tools|UUID generator and validator|F
Developer Tools|Manifest builder|F
Developer Tools|File inspector|F
Developer Tools|Permission tester|F
Developer Tools|Minecraft version database|N
Technical Systems|Local-first storage (JSON files and preferences, no SQL database)|P
Technical Systems|Background tasks (WorkManager)|P
Technical Systems|Encryption engine (AES-256-GCM)|P
Technical Systems|Unit tests included (not run by the author)|P
Technical Systems|Search index|N
Technical Systems|Feature flags and update system|N
"""
