package app.minesaver

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

private val ChapterViolet = Color(0xFFB69CFF)
private val ChapterSilver = Color(0xFFD7DAF0)

/** The app logo in Settings. Seven quick taps reveal a symbol; holding it for three seconds opens the private section. No hint is shown anywhere. */
@Composable
fun SecretLogo(onOpen: () -> Unit) {
    var taps by remember { mutableStateOf(0) }
    var last by remember { mutableStateOf(0L) }
    var armed by remember { mutableStateOf(false) }
    LaunchedEffect(armed) { if (armed) { delay(12_000); armed = false; taps = 0 } }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painterResource(R.drawable.ic_logo), null,
            Modifier.size(60.dp).clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                val now = System.currentTimeMillis()
                taps = if (now - last > 1500) 1 else taps + 1
                last = now
                if (taps >= 7) armed = true
            }
        )
        if (armed) {
            val a by rememberInfiniteTransition(label = "sym").animateFloat(0.55f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "a")
            Text(
                "✦", color = ChapterViolet.copy(alpha = a), fontSize = 26.sp,
                modifier = Modifier.padding(top = 4.dp).pointerInput(Unit) {
                    awaitEachGesture {
                        awaitFirstDown()
                        val up = withTimeoutOrNull(3000) { waitForUpOrCancellation() }
                        if (up == null) { armed = false; taps = 0; onOpen() }
                    }
                }
            )
        }
    }
}

@Composable
private fun Stars(reduce: Boolean) {
    val stars = remember { val r = java.util.Random(7); List(70) { Triple(r.nextFloat(), r.nextFloat(), 0.8f + r.nextFloat() * 1.8f) } }
    val phase = if (reduce) 0f else rememberInfiniteTransition(label = "stars").animateFloat(0f, 6.2831f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "p").value
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF050B1F), Color(0xFF0A1330), Color(0xFF120A2A))))
        drawCircle(Brush.radialGradient(listOf(Color(0x442E1A6B), Color.Transparent), Offset(size.width * 0.75f, size.height * 0.25f), size.width * 0.7f), size.width * 0.7f, Offset(size.width * 0.75f, size.height * 0.25f))
        drawCircle(Brush.radialGradient(listOf(Color(0x33124A7A), Color.Transparent), Offset(size.width * 0.15f, size.height * 0.8f), size.width * 0.6f), size.width * 0.6f, Offset(size.width * 0.15f, size.height * 0.8f))
        stars.forEachIndexed { i, s ->
            val al = 0.45f + 0.45f * Math.sin((phase + i).toDouble()).toFloat()
            drawCircle(Color.White.copy(alpha = al.coerceIn(0.1f, 1f)), s.third, Offset(s.first * size.width, s.second * size.height))
        }
    }
}

@Composable
private fun Emblem() {
    Canvas(Modifier.size(96.dp)) {
        val c = Offset(size.width / 2, size.height / 2)
        drawCircle(Brush.radialGradient(listOf(Color(0x66B69CFF), Color.Transparent), c, size.width / 2), size.width / 2, c)
        drawOval(ChapterSilver.copy(alpha = 0.7f), Offset(c.x - size.width * 0.46f, c.y - size.height * 0.14f), Size(size.width * 0.92f, size.height * 0.28f), style = Stroke(2.5f))
        drawCircle(ChapterViolet, 9f, c)
        drawCircle(Color.White, 4f, c)
    }
}

@Composable
fun UnwrittenScreen(vm: MainVm, nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val typo = MaterialTheme.typography
    var data by remember { mutableStateOf<ChapterData?>(null) }
    var section by remember { mutableStateOf(-1) }
    var wipe by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { data = withContext(Dispatchers.IO) { ChapterStore.load(ctx) } }
    val latest = rememberUpdatedState(data)
    LaunchedEffect(data) { val d = data; if (d != null) { delay(500); withContext(Dispatchers.IO) { ChapterStore.save(ctx, d) } } }
    DisposableEffect(Unit) { onDispose { latest.value?.let { runCatching { ChapterStore.save(ctx, it) } } } }
    BackHandler { if (section != -1) section = -1 else nav.popBackStack() }
    val scheme = darkColorScheme(primary = ChapterViolet, secondary = Color(0xFF7FB4FF), background = Color(0xFF050B1F), surface = Color(0xFF0F1B3D), onSurface = Color(0xFFEDEBFF), onBackground = Color(0xFFEDEBFF), onSurfaceVariant = Color(0xFFB9B6DD), error = Color(0xFFFF8A8A))
    CompositionLocalProvider(LocalLook provides Looks[0], LocalReduce provides vm.reduce) {
        MaterialTheme(colorScheme = scheme, typography = typo) {
            Box(Modifier.fillMaxSize()) {
                Stars(vm.reduce)
                val d = data
                if (d == null) return@Box
                fun upd(n: ChapterData) { data = n }
                if (section == -1) ChapterHome(onOpen = { section = it }, onWipe = { wipe = true }, onClose = { nav.popBackStack() })
                else PageBase(stringResource(listOf(R.string.uc_story, R.string.uc_dreams, R.string.uc_future, R.string.uc_notes, R.string.uc_message)[section]), { section = -1 }) {
                    when (section) {
                        0 -> item { Glass { Text(stringResource(R.string.uc_story_hint), color = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.height(10.dp)); OutlinedTextField(d.story, { upd(d.copy(story = it)) }, Modifier.fillMaxWidth(), minLines = 10) } }
                        1 -> dreamsSection(d, ::upd)
                        2 -> futureSection(d, ::upd)
                        3 -> notesSection(d, ::upd)
                        else -> messageSection(d, ::upd)
                    }
                }
            }
        }
    }
    if (wipe) ConfirmDialog(stringResource(R.string.uc_wipe_q), {
        wipe = false
        scope.launch { withContext(Dispatchers.IO) { ChapterStore.wipe(ctx) }; data = ChapterData(); section = -1; vm.toast = Msg(R.string.uc_wiped) }
    }, { wipe = false })
}

@Composable
private fun ChapterHome(onOpen: (Int) -> Unit, onWipe: () -> Unit, onClose: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Emblem()
        Spacer(Modifier.height(16.dp))
        Text(stringResource(R.string.uc_title), color = ChapterSilver, fontSize = 22.sp, fontWeight = FontWeight.Light, letterSpacing = 3.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.uc_tagline), color = ChapterViolet, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(28.dp))
        listOf(R.string.uc_story, R.string.uc_dreams, R.string.uc_future, R.string.uc_notes, R.string.uc_message).forEachIndexed { i, r ->
            OutlinedButton({ onOpen(i) }, Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(stringResource(r), color = ChapterSilver) }
        }
        Spacer(Modifier.height(18.dp))
        Row {
            TextButton(onClose) { Text(stringResource(R.string.a_close), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            TextButton(onWipe) { Text(stringResource(R.string.uc_wipe), color = MaterialTheme.colorScheme.error) }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.dreamsSection(d: ChapterData, upd: (ChapterData) -> Unit) {
    item { DreamsUi(d, upd) }
}

@Composable
private fun DreamsUi(d: ChapterData, upd: (ChapterData) -> Unit) {
    var title by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf<Dream?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass {
            OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.uc_new_goal)) })
            Spacer(Modifier.height(8.dp))
            Acts { Act(R.string.uc_add, Icons.Rounded.Add) { if (title.isNotBlank()) { upd(d.copy(dreams = listOf(Dream(UUID.randomUUID().toString(), title.trim(), "", "", false, false)) + d.dreams)); title = "" } } }
        }
        Acts { listOf(R.string.uc_active, R.string.uc_completed, R.string.uc_archived).forEachIndexed { i, r -> TagChip(stringResource(r), filter == i) { filter = i } } }
        val shown = d.dreams.filter { when (filter) { 0 -> !it.done && !it.archived; 1 -> it.done && !it.archived; else -> it.archived } }
        if (shown.isEmpty()) Text(stringResource(R.string.uc_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
        shown.forEach { g ->
            Glass(Modifier.clickable { edit = g }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(g.done, { upd(d.copy(dreams = d.dreams.map { x -> if (x.id == g.id) x.copy(done = it) else x })) })
                    Column(Modifier.weight(1f)) {
                        Text(g.title, style = MaterialTheme.typography.titleMedium)
                        if (g.date.isNotBlank()) Text(g.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (g.note.isNotBlank()) Text(g.note, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
    edit?.let { g ->
        var t by remember(g.id) { mutableStateOf(g.title) }
        var n by remember(g.id) { mutableStateOf(g.note) }
        var dt by remember(g.id) { mutableStateOf(g.date) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(stringResource(R.string.uc_edit)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(t, { t = it }, singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                    OutlinedTextField(dt, { dt = it }, singleLine = true, label = { Text(stringResource(R.string.uc_date)) })
                    OutlinedTextField(n, { n = it }, minLines = 2, label = { Text(stringResource(R.string.sd_note)) })
                    Row {
                        TextButton({ upd(d.copy(dreams = d.dreams.map { x -> if (x.id == g.id) x.copy(archived = !x.archived) else x })); edit = null }) { Text(stringResource(if (g.archived) R.string.uc_unarchive else R.string.uc_archive)) }
                        TextButton({ upd(d.copy(dreams = d.dreams.filter { it.id != g.id })); edit = null }) { Text(stringResource(R.string.a_delete), color = MaterialTheme.colorScheme.error) }
                    }
                }
            },
            confirmButton = { TextButton({ upd(d.copy(dreams = d.dreams.map { x -> if (x.id == g.id) x.copy(title = t.ifBlank { g.title }, note = n, date = dt) else x })); edit = null }) { Text(stringResource(R.string.a_done)) } },
            dismissButton = { TextButton({ edit = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.futureSection(d: ChapterData, upd: (ChapterData) -> Unit) {
    item { FutureUi(d, upd) }
}

@Composable
private fun FutureUi(d: ChapterData, upd: (ChapterData) -> Unit) {
    var tl by remember { mutableStateOf("") }
    var td by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass {
            OutlinedTextField(d.plans, { upd(d.copy(plans = it)) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text(stringResource(R.string.uc_plans)) })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(d.goals, { upd(d.copy(goals = it)) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text(stringResource(R.string.uc_goals)) })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(d.learn, { upd(d.copy(learn = it)) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text(stringResource(R.string.uc_learn)) })
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(d.achieve, { upd(d.copy(achieve = it)) }, Modifier.fillMaxWidth(), minLines = 2, label = { Text(stringResource(R.string.uc_achieve)) })
        }
        Glass {
            Text(stringResource(R.string.uc_timeline), fontWeight = FontWeight.Bold)
            d.timeline.forEach { m ->
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.text)
                        if (m.date.isNotBlank()) Text(m.date, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    TextButton({ upd(d.copy(timeline = d.timeline.filter { it.id != m.id })) }) { Text(stringResource(R.string.a_delete), color = MaterialTheme.colorScheme.error) }
                }
            }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(tl, { tl = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.uc_milestone)) })
            Spacer(Modifier.height(6.dp))
            OutlinedTextField(td, { td = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text(stringResource(R.string.uc_date)) })
            Spacer(Modifier.height(8.dp))
            Acts { Act(R.string.uc_add, Icons.Rounded.Add) { if (tl.isNotBlank()) { upd(d.copy(timeline = d.timeline + Milestone(UUID.randomUUID().toString(), td.trim(), tl.trim()))); tl = ""; td = "" } } }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.notesSection(d: ChapterData, upd: (ChapterData) -> Unit) {
    item { NotesUi(d, upd) }
}

@Composable
private fun NotesUi(d: ChapterData, upd: (ChapterData) -> Unit) {
    var cat by remember { mutableStateOf<String?>(null) }
    var edit by remember { mutableStateOf<PNote?>(null) }
    val cats = d.notes.map { it.cat }.filter { it.isNotBlank() }.distinct()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Acts {
            Act(R.string.uc_new_note, Icons.Rounded.Add) { edit = PNote("", cat ?: "", "", "", System.currentTimeMillis()) }
            if (cats.isNotEmpty()) {
                TagChip(stringResource(R.string.tag_all), cat == null) { cat = null }
                cats.forEach { c -> TagChip(c, cat == c) { cat = if (cat == c) null else c } }
            }
        }
        val shown = d.notes.filter { cat == null || it.cat == cat }.sortedByDescending { it.at }
        if (shown.isEmpty()) Text(stringResource(R.string.uc_empty), color = MaterialTheme.colorScheme.onSurfaceVariant)
        shown.forEach { n ->
            Glass(Modifier.clickable { edit = n }) {
                Text(n.title.ifBlank { n.text.take(40) }, style = MaterialTheme.typography.titleMedium)
                if (n.cat.isNotBlank()) Text(n.cat, style = MaterialTheme.typography.labelSmall, color = ChapterViolet)
                Text(n.text, style = MaterialTheme.typography.bodySmall, maxLines = 3, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
    edit?.let { n ->
        var t by remember(n.id, n.at) { mutableStateOf(n.title) }
        var x by remember(n.id, n.at) { mutableStateOf(n.text) }
        var c by remember(n.id, n.at) { mutableStateOf(n.cat) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(stringResource(R.string.uc_note)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(t, { t = it }, singleLine = true, label = { Text(stringResource(R.string.sd_name)) })
                    OutlinedTextField(c, { c = it }, singleLine = true, label = { Text(stringResource(R.string.uc_category)) })
                    OutlinedTextField(x, { x = it }, minLines = 5, label = { Text(stringResource(R.string.uc_note)) })
                    if (n.id.isNotEmpty()) TextButton({ upd(d.copy(notes = d.notes.filter { it.id != n.id })); edit = null }) { Text(stringResource(R.string.a_delete), color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton({
                    if (t.isNotBlank() || x.isNotBlank()) {
                        val saved = PNote(n.id.ifEmpty { UUID.randomUUID().toString() }, c.trim(), t.trim(), x, if (n.id.isEmpty()) n.at else System.currentTimeMillis())
                        upd(d.copy(notes = if (n.id.isEmpty()) d.notes + saved else d.notes.map { if (it.id == n.id) saved else it }))
                    }
                    edit = null
                }) { Text(stringResource(R.string.a_done)) }
            },
            dismissButton = { TextButton({ edit = null }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.messageSection(d: ChapterData, upd: (ChapterData) -> Unit) {
    item { MessageUi(d, upd) }
}

@Composable
private fun MessageUi(d: ChapterData, upd: (ChapterData) -> Unit) {
    var editing by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    val original = stringResource(R.string.uc_msg_body)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Glass {
            Text(stringResource(R.string.uc_msg_title), style = MaterialTheme.typography.titleMedium, color = ChapterViolet)
            Spacer(Modifier.height(12.dp))
            Text(d.msg ?: original, style = MaterialTheme.typography.bodyLarge, lineHeight = 26.sp)
        }
        Acts {
            Act(R.string.uc_edit, Icons.Rounded.Edit) { text = d.msg ?: original; editing = true }
            if (d.msg != null) Act(R.string.uc_restore, Icons.Rounded.Refresh) { upd(d.copy(msg = null)) }
        }
    }
    if (editing) {
        AlertDialog(
            onDismissRequest = { editing = false },
            title = { Text(stringResource(R.string.uc_edit)) },
            text = { OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), minLines = 8) },
            confirmButton = { TextButton({ upd(d.copy(msg = text.ifBlank { null })); editing = false }) { Text(stringResource(R.string.a_done)) } },
            dismissButton = { TextButton({ editing = false }) { Text(stringResource(R.string.cancel)) } }
        )
    }
}
