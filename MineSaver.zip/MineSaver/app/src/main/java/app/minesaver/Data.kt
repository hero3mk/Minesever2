package app.minesaver

import android.content.Context
import android.net.Uri
import androidx.annotation.StringRes
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class Msg(@StringRes val res: Int, vararg val args: Any)

/** kind: 0 ok, 1 warning, 2 error */
data class LogEntry(val time: Long, val res: String, val args: List<Any>, val kind: Int)

data class Backup(
    val id: String, val worldId: String, val worldName: String, val mode: Int,
    val time: Long, val size: Long, val sha: String, val file: String
)

data class LiveWorld(val id: String, val name: String, val mode: Int, val modified: Long, val doc: DocumentFile?, val path: String?, val size: Long = 0L)

data class WorldRow(val id: String, val name: String, val mode: Int, val live: LiveWorld?, val backups: List<Backup>) {
    val last: Long? get() = backups.maxOfOrNull { it.time }
    val size: Long get() = backups.sumOf { it.size }
    val changed: Boolean
        get() { val l = last; val w = live; return w != null && (l == null || w.modified > l) }
}

fun safeName(s: String) = s.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').ifEmpty { "world" }

fun sha256(f: File): String {
    val md = MessageDigest.getInstance("SHA-256")
    f.inputStream().use { i -> val b = ByteArray(65536); while (true) { val n = i.read(b); if (n < 0) break; md.update(b, 0, n) } }
    return md.digest().joinToString("") { "%02x".format(it) }
}

/** Reads Bedrock level.dat "GameType" int tag. 0 survival, 1 creative, 2 adventure, -1 unknown. */
fun gameMode(b: ByteArray): Int {
    val key = byteArrayOf(3, 8, 0) + "GameType".toByteArray()
    outer@ for (i in 0..(b.size - key.size - 4)) {
        for (j in key.indices) if (b[i + j] != key[j]) continue@outer
        val v = b[i + key.size].toInt() and 255
        return if (v in 0..2) v else -1
    }
    return -1
}

class Repo(private val ctx: Context) {
    val dir = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "backups").apply { mkdirs() }
    private val icons = File(dir.parentFile, "icons").apply { mkdirs() }
    private val index = File(dir, "index.json")
    private val cr = ctx.contentResolver

    private val logFile = File(dir.parentFile, "activity.json")

    fun logLoad(): List<LogEntry> = try {
        val a = JSONArray(logFile.readText())
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val ar = o.getJSONArray("a")
            LogEntry(o.getLong("t"), o.getString("r"), (0 until ar.length()).map { ar.get(it) }, o.getInt("k"))
        }
    } catch (e: Exception) { emptyList() }

    fun logAdd(m: Msg) {
        val name = runCatching { ctx.resources.getResourceEntryName(m.res) }.getOrNull() ?: return
        if (name == "msg_scanned" || name == "busy_wait") return
        val kind = when (name) {
            "err", "msg_sz_fail", "msg_verify_bad" -> 2
            "msg_mirror_fail", "msg_backed_part" -> 1
            else -> 0
        }
        val all = (listOf(LogEntry(System.currentTimeMillis(), name, m.args.toList(), kind)) + logLoad()).take(200)
        val a = JSONArray()
        all.forEach { a.put(JSONObject().put("t", it.time).put("r", it.res).put("k", it.kind).put("a", JSONArray(it.args))) }
        runCatching { logFile.writeText(a.toString()) }
    }

    fun logClear() { logFile.delete() }

    fun tempFiles(): List<File> = dir.listFiles()?.filter { it.name.endsWith(".part") || it.name.endsWith(".tmp") } ?: emptyList()

    private fun sizeOf(d: DocumentFile): Long {
        var s = 0L
        for (f in d.listFiles()) s += if (f.isDirectory) sizeOf(f) else f.length()
        return s
    }

    fun file(b: Backup) = File(dir, b.file)
    fun icon(worldId: String) = File(icons, safeName(worldId) + ".jpg")

    fun load(): List<Backup> {
        if (!index.exists()) return emptyList()
        return try {
            val a = JSONArray(index.readText())
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Backup(o.getString("id"), o.getString("worldId"), o.getString("worldName"), o.getInt("mode"),
                    o.getLong("time"), o.getLong("size"), o.getString("sha"), o.getString("file"))
            }
        } catch (e: Exception) {
            runCatching { index.copyTo(File(dir, "index.bad"), true) }
            emptyList()
        }
    }

    private fun save(list: List<Backup>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("worldId", it.worldId).put("worldName", it.worldName)
                .put("mode", it.mode).put("time", it.time).put("size", it.size).put("sha", it.sha).put("file", it.file))
        }
        val t = File(dir, "index.tmp")
        t.writeText(a.toString())
        if (!t.renameTo(index)) throw IOException("Could not save backup index")
    }

    private fun bytes(u: Uri) = cr.openInputStream(u)?.use { it.readBytes() } ?: ByteArray(0)

    // ---------- Minecraft folder (SAF) ----------
    fun worldsRoot(tree: Uri): DocumentFile {
        val r = DocumentFile.fromTreeUri(ctx, tree) ?: throw IOException("Folder unavailable")
        return r.findFile("minecraftWorlds")
            ?: r.findFile("com.mojang")?.findFile("minecraftWorlds")
            ?: r.findFile("games")?.findFile("com.mojang")?.findFile("minecraftWorlds")
            ?: r
    }

    fun scan(tree: Uri): List<LiveWorld> = worldsRoot(tree).listFiles().filter { it.isDirectory }.mapNotNull { d ->
        val id = d.name ?: return@mapNotNull null
        val lvl = d.findFile("level.dat") ?: return@mapNotNull null
        val nm = d.findFile("levelname.txt")?.let { String(bytes(it.uri)).trim() }?.takeIf { it.isNotEmpty() } ?: id
        LiveWorld(id, nm, gameMode(bytes(lvl.uri)), lvl.lastModified(), d, null, sizeOf(d))
    }

    // ---------- Backup ----------
    fun backupLive(w: LiveWorld): Backup {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val name = "${safeName(w.name).take(40)}_$stamp.mcworld"
        val part = File(dir, "$name.part")
        try {
            var n = 0
            var hasLevel = false
            ZipOutputStream(BufferedOutputStream(FileOutputStream(part))).use { z ->
                val doc = w.doc
                if (doc != null) {
                    fun walk(d: DocumentFile, prefix: String) {
                        for (c in d.listFiles()) {
                            val nm = c.name ?: continue
                            if (c.isDirectory) walk(c, "$prefix$nm/") else {
                                z.putNextEntry(ZipEntry(prefix + nm))
                                (cr.openInputStream(c.uri) ?: throw IOException("Cannot read $nm")).use { it.copyTo(z) }
                                z.closeEntry()
                                n++
                                if (prefix + nm == "level.dat") hasLevel = true
                            }
                        }
                    }
                    walk(doc, "")
                } else {
                    val (c, lv) = Sz.tarToZip(w.path ?: throw IOException("No path"), z)
                    n = c
                    hasLevel = lv
                }
            }
            if (!hasLevel) throw IOException("level.dat is missing")
            checkZip(part, n)
            return finish(part, name, w.id, w.name, w.mode)
        } catch (e: Exception) {
            part.delete()
            throw e
        }
    }

    /** Re-opens the zip and reads every byte (CRC is checked). Throws if anything is wrong. */
    fun checkZip(f: File, expected: Int? = null) {
        ZipFile(f).use { z ->
            val es = z.entries().asSequence().filter { !it.isDirectory }.toList()
            if (es.none { it.name == "level.dat" }) throw IOException("Not a Minecraft world (level.dat missing)")
            if (expected != null && es.size != expected) throw IOException("File count mismatch")
            val buf = ByteArray(65536)
            es.forEach { e -> z.getInputStream(e).use { while (it.read(buf) >= 0) { } } }
        }
    }

    private fun finish(part: File, name: String, worldId: String, worldName: String, mode: Int): Backup {
        val out = File(dir, name)
        if (!part.renameTo(out)) throw IOException("Could not finalize backup file")
        runCatching {
            ZipFile(out).use { z ->
                z.getEntry("world_icon.jpeg")?.let { e -> z.getInputStream(e).use { i -> icon(worldId).outputStream().use { o -> i.copyTo(o) } } }
            }
        }
        val b = Backup(UUID.randomUUID().toString(), worldId, worldName, mode, System.currentTimeMillis(), out.length(), sha256(out), name)
        save(load() + b)
        return b
    }

    // ---------- Import ----------
    /** Returns the backup and whether it is new (false = identical file already stored). */
    fun importMcworld(uri: Uri): Pair<Backup, Boolean> {
        val tmp = File(dir, "import_${System.nanoTime()}.part")
        try {
            (cr.openInputStream(uri) ?: throw IOException("Cannot read file")).use { i -> tmp.outputStream().use { i.copyTo(it) } }
            checkZip(tmp)
            val s = sha256(tmp)
            load().find { it.sha == s }?.let { tmp.delete(); return it to false }
            val (name, mode) = ZipFile(tmp).use { z ->
                val n = z.getEntry("levelname.txt")?.let { e -> z.getInputStream(e).use { String(it.readBytes()).trim() } }
                    ?.takeIf { it.isNotEmpty() } ?: "World"
                val m = gameMode(z.getInputStream(z.getEntry("level.dat")).use { it.readBytes() })
                n to m
            }
            val wid = load().find { it.worldName == name }?.worldId ?: ("imp_" + s.take(8))
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            return finish(tmp, "${safeName(name).take(40)}_${stamp}_${s.take(4)}.mcworld", wid, name, mode) to true
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }

    fun listMcworlds(tree: Uri): List<Uri> =
        DocumentFile.fromTreeUri(ctx, tree)?.listFiles()
            ?.filter { it.isFile && (it.name ?: "").endsWith(".mcworld", true) }?.map { it.uri } ?: emptyList()

    // ---------- Safe folder mirror ----------
    fun mirror(b: Backup, tree: Uri): Boolean = runCatching {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: error("no folder")
        if (!root.canWrite()) error("read-only")
        val ex = root.findFile(b.file)
        if (ex != null && ex.length() == b.size) return@runCatching true
        ex?.delete()
        val d = root.createFile("application/octet-stream", b.file) ?: error("create failed")
        (cr.openOutputStream(d.uri) ?: error("open failed")).use { o -> file(b).inputStream().use { it.copyTo(o) } }
        d.length() == b.size
    }.getOrDefault(false)

    // ---------- Restore (never overwrites) ----------
    fun restoreToTree(b: Backup, tree: Uri): String {
        val f = file(b)
        checkZip(f)
        if (sha256(f) != b.sha) throw IOException("Backup is damaged (checksum mismatch)")
        val root = worldsRoot(tree)
        if (!root.canWrite()) throw IOException("Minecraft folder is read-only or permission was lost")
        val base = if (b.worldId.startsWith("imp_")) safeName(b.worldName) else b.worldId
        var name = base
        var k = 1
        while (root.findFile(name) != null) name = "${base}_restored_${k++}"
        val dest = root.createDirectory(name) ?: throw IOException("Cannot create world folder")
        try {
            val dirs = HashMap<String, DocumentFile>()
            var written = 0
            var total = 0
            ZipFile(f).use { z ->
                for (e in z.entries().asSequence().filter { !it.isDirectory }) {
                    total++
                    val parts = e.name.split('/')
                    var cur = dest
                    var path = ""
                    for (p in parts.dropLast(1)) {
                        path += "$p/"
                        val parent = cur
                        cur = dirs.getOrPut(path) { parent.findFile(p) ?: parent.createDirectory(p) ?: throw IOException("Cannot create $p") }
                    }
                    val out = cur.createFile("application/octet-stream", parts.last()) ?: throw IOException("Cannot create ${parts.last()}")
                    (cr.openOutputStream(out.uri) ?: throw IOException("Cannot write ${parts.last()}")).use { o -> z.getInputStream(e).use { it.copyTo(o) } }
                    written++
                }
            }
            if (written != total || dest.findFile("level.dat") == null) throw IOException("Restore incomplete")
            return name
        } catch (e: Exception) {
            dest.delete()
            throw e
        }
    }

    fun restoreViaShizuku(b: Backup): String {
        val f = file(b)
        checkZip(f)
        if (sha256(f) != b.sha) throw IOException("Backup is damaged (checksum mismatch)")
        val base = if (b.worldId.startsWith("imp_")) safeName(b.worldName) else b.worldId
        return Sz.restore(f, base)
    }

    fun exportTo(b: Backup, out: Uri) {
        (cr.openOutputStream(out) ?: throw IOException("Cannot write destination")).use { o -> file(b).inputStream().use { it.copyTo(o) } }
    }

    fun verify(b: Backup): Boolean = runCatching { checkZip(file(b)); sha256(file(b)) == b.sha }.getOrDefault(false)

    fun delete(list: List<Backup>) {
        list.forEach { file(it).delete() }
        val ids = list.map { it.id }.toSet()
        save(load().filter { it.id !in ids })
    }
}
