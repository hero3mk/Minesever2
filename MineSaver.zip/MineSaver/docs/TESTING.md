# Testing

Status: NOT TESTED ON A DEVICE. This code was written without a compiler or a phone available to the author, so every feature is "not yet tested" until the owner confirms it.

Unit tests (`app/src/test/java/app/minesaver/CoreTest.kt`) cover path safety, hex dump, hashing, signature detection, the slime function's determinism and the encryption round trip. They were written but have **not been run**. Run them with `gradle testDebugUnitTest` (a build step can be added to the workflow).

Manual checklist for the owner: build, install, open every tab, take one backup, verify it, restore into a new folder, try Recently deleted, compare two backups, open the ZIP explorer, export an encrypted copy and import it back, run Data protection and Feature status.
