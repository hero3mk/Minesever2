# MineSaver feature status (4.0.0)

No feature has been tested on a physical device by the author of this code; everything below is "Not yet tested" until the owner confirms it. Unit tests exist in `app/src/test` but have not been run.

Summary: Fully implemented: 53, Partially implemented: 34, Not implemented: 21, Blocked by Android limitations: 3, Requires an external engine: 4, Requires a backend: 3


## World Vault

| Feature | Status |
|---|---|
| Manual backup | Fully implemented |
| One-tap backup (all worlds) | Fully implemented |
| Automatic backup of changed worlds (on app open) | Fully implemented |
| Scheduled backup (WorkManager, subject to Android limits) | Partially implemented |
| Backup history and timeline | Fully implemented |
| Backup verification (SHA-256 + archive check) | Fully implemented |
| Corrupted backup detection | Fully implemented |
| Backup health / recovery readiness score | Partially implemented |
| Safe restore (never overwrites, new folder) | Fully implemented |
| Emergency backup before restore | Fully implemented |
| Restore preview and confirmation | Fully implemented |
| Restore into the game folder (Shizuku or folder access) | Partially implemented |
| Open backup in Minecraft | Partially implemented |
| MCWORLD import and export | Fully implemented |
| Backup import/export/share | Fully implemented |
| Compression level setting | Fully implemented |
| Optional password encryption (.mse export/import) | Partially implemented |
| Backup names and notes | Fully implemented |
| Backup comparison (files and metadata) | Fully implemented |
| File-level restore (extract selected files to a folder) | Partially implemented |
| Recently deleted (undo) for backups | Fully implemented |
| Retention and expiry review (never silent deletion) | Partially implemented |
| Multiple storage locations (app, Downloads, safe folder) | Fully implemented |
| Backup migration between devices (share + checksums) | Partially implemented |
| Backup failure recovery (rebuild index, clean temp files) | Partially implemented |
| Operation logs | Fully implemented |
| Incremental backup | Not implemented |
| Pause and resume operations | Not implemented |
| Backup progress percentage | Not implemented |

## World Library

| Feature | Status |
|---|---|
| World profile (name, icon, seed, version, mode, difficulty, cheats, size) | Fully implemented |
| Java edition worlds | Not implemented |
| Search, sort, filters, favorites, tags, notes | Fully implemented |
| Worlds without backup / needing review | Fully implemented |
| Open the world folder | Blocked by Android limitations |
| World comparison | Fully implemented |

## Seed Intelligence

| Feature | Status |
|---|---|
| Seed library with edition, version, category, favorites | Fully implemented |
| Seed verification against a world | Fully implemented |
| Seed comparison and text import/export | Fully implemented |
| Coordinates book with dimensions, export, sharing, distances | Fully implemented |
| Slime chunk finder and map layer (Bedrock, community algorithm) | Partially implemented |
| Seed map (biomes and terrain from a seed) | Requires an external engine |
| Structure finder | Requires an external engine |
| Biome finder | Requires an external engine |
| Seed finder / recommendations / difficulty | Requires an external engine |
| Map export to image | Not implemented |

## World Analyzer

| Feature | Status |
|---|---|
| Read level.dat (seed, version, mode, difficulty, spawn) | Fully implemented |
| Explored chunk map from the world database (LevelDB) | Partially implemented |
| Exploration tracker and inspector | Partially implemented |
| Health check (archive, database files, version, packs) | Fully implemented |
| Statistics, age, sessions (observed) | Partially implemented |
| Size evolution chart and metadata history | Partially implemented |
| Route planner (straight line) | Fully implemented |
| Game rules viewer | Not implemented |
| World information export | Partially implemented |
| Storage forecast (linear estimate) | Partially implemented |

## Add-on Intelligence

| Feature | Status |
|---|---|
| Library for mcpack/mcaddon/zip | Fully implemented |
| Manifest analysis, UUID and duplicate detection | Fully implemented |
| Dependency checks and map | Fully implemented |
| Engine version comparison | Partially implemented |
| Safety scan (paths, executables, size, duplicates) | Partially implemented |
| Pack repair (JSON comments, trailing commas, BOM) | Partially implemented |
| Collections | Fully implemented |
| Add-ons used by each world | Fully implemented |
| File path conflict detection between packs | Not implemented |
| Load order manager | Not implemented |
| Script API compatibility checks | Not implemented |
| Update tracker and notifications | Requires a backend |
| Compatibility database | Not implemented |

## File Manager

| Feature | Status |
|---|---|
| ZIP explorer with search, preview, integrity check | Fully implemented |
| Extract selected files with path-safety checks | Fully implemented |
| Hash tool, signature inspector, hex viewer | Fully implemented |
| Minecraft folder explorer (Shizuku) | Not implemented |
| Move and delete files in the game folder | Blocked by Android limitations |
| Folder comparison and synchronization | Not implemented |

## Content Center

| Feature | Status |
|---|---|
| Content library (worlds, add-ons, screenshots in their own pages) | Partially implemented |
| Unified content center page | Not implemented |

## Minecraft Companion

| Feature | Status |
|---|---|
| Encyclopedia, crafting and mob databases | Not implemented |

## Build Studio

| Feature | Status |
|---|---|
| Projects, status, coordinates, materials, size calculator, before/after photos | Partially implemented |

## Play Journal

| Feature | Status |
|---|---|
| Manual sessions, playtime statistics, challenges | Partially implemented |
| World journal, goals and screenshots | Partially implemented |
| Automatic session logging | Blocked by Android limitations |

## Smart Automation

| Feature | Status |
|---|---|
| Scheduled backups with charging and storage rules | Partially implemented |
| Notifications for completed operations and low storage | Partially implemented |
| Retry on failure | Partially implemented |
| Custom automation rules builder | Not implemented |

## Cloud and Community

| Feature | Status |
|---|---|
| Cloud sync, accounts, multi-device | Requires a backend |
| Community sharing, reviews, profiles | Requires a backend |

## Experience

| Feature | Status |
|---|---|
| 41 themes in three groups with live previews and accent colors | Fully implemented |
| Theme Studio (custom theme, copy/paste code, live preview) | Partially implemented |
| Animated splash, new dashboard and floating navigation bar | Partially implemented |
| Reduced motion | Fully implemented |
| Arabic and English with RTL | Fully implemented |
| Global search with history | Fully implemented |
| Command center | Fully implemented |
| Quick Settings tile | Partially implemented |
| Home screen widgets 2x2, 4x2, 4x4 (theme aware, rotating panels, refresh after operations) | Partially implemented |
| Fingerprint unlock and auto-lock | Fully implemented |
| Dashboard customization and drag and drop | Not implemented |
| Custom app icons | Not implemented |
| Game status and launcher | Fully implemented |

## Data Protection

| Feature | Status |
|---|---|
| Integrity check and database rebuild | Fully implemented |
| Permission and storage access monitor | Fully implemented |
| Diagnostics report export | Fully implemented |
| Configuration export and import | Fully implemented |
| Crash reports | Not implemented |
| Privacy center with real permission list | Fully implemented |

## Developer Tools

| Feature | Status |
|---|---|
| JSON validate, format, minify, clean, compare | Fully implemented |
| UUID generator and validator | Fully implemented |
| Manifest builder | Fully implemented |
| File inspector | Fully implemented |
| Permission tester | Fully implemented |
| Minecraft version database | Not implemented |

## Technical Systems

| Feature | Status |
|---|---|
| Local-first storage (JSON files and preferences, no SQL database) | Partially implemented |
| Background tasks (WorkManager) | Partially implemented |
| Encryption engine (AES-256-GCM) | Partially implemented |
| Unit tests included (not run by the author) | Partially implemented |
| Search index | Not implemented |
| Feature flags and update system | Not implemented |
