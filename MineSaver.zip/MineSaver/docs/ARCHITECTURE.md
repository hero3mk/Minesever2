# Architecture

Single-module Kotlin + Jetpack Compose app. `MainVm` holds all UI state; `Repo` (Data.kt) owns backups and the trash on disk (JSON index + `.mcworld` zips); `Sz` talks to Shizuku; `LevelDb.kt` is a read-only LevelDB reader; `Addons.kt` handles packs; `Core2.kt` holds crypto, slime, comparison and helpers; `Worker.kt` has the WorkManager job, tile and widget. Storage is local JSON files plus SharedPreferences; there is no SQL database. There is no network code and no INTERNET permission.
