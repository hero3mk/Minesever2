# Security and privacy

No INTERNET permission; nothing leaves the device unless you share it. Backups are never overwritten; restores go to a new folder name. Deleting a backup moves it to Recently deleted. ZIP extraction rejects `..` and absolute paths and limits size. Encrypted exports use AES-256-GCM in 1 MB authenticated chunks with a PBKDF2-SHA256 key (120,000 iterations); a lost password cannot be recovered. The PIN is stored hashed and is not included in configuration exports. Shizuku access is used read-only except for restoring a world you choose.
