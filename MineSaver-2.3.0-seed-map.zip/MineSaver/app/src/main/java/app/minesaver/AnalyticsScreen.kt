package app.minesaver

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WorldLabScreen(vm: MainVm, nav: NavController) {
    val context= LocalContext.current
    val scope= rememberCoroutineScope()
    var selectedWorld by remember { mutableStateOf(vm.rows.firstOrNull()?.id) }
    var selectedBackup by remember { mutableStateOf<String?>(null) }
    var dna by remember { mutableStateOf<WorldDna?>(null) }
    var dnaCompare by remember { mutableStateOf<String?>(null) }
    var packs by remember { mutableStateOf<List<AddonPack>>(emptyList()) }
    var conflicts by remember { mutableStateOf<List<AddonConflict>>(emptyList()) }
    var status by remember { mutableStateOf("Choose a world and run an analysis.") }
    var busy by remember { mutableStateOf(false) }
    val pickAddons= rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if(uris.isNotEmpty()) scope.launch {
            busy=true; status="Reading add-on manifests…"
            val parsed=withContext(Dispatchers.IO) { uris.mapNotNull { u -> runCatching { WorldAnalytics.addon(u,context) }.getOrElse { AddonPack(u.lastPathSegment ?: "Package","Package",null,null, emptyList(),listOf(it.message ?: "Read error")) } } }
            packs=parsed; conflicts=WorldAnalytics.conflicts(parsed); busy=false
            status="Compared ${parsed.size} selected packages."
        }
    }
    val row=vm.rows.find { it.id==selectedWorld }
    val backups=row?.backups ?: emptyList()
    val currentBackup=backups.find { it.id==selectedBackup } ?: backups.firstOrNull()
    val places=vm.places.filter { it.world.isBlank() || it.world==row?.name || it.world==row?.id }

    @Composable fun Panel(title:String, icon: androidx.compose.ui.graphics.vector.ImageVector, content:@Composable ColumnScope.()->Unit) {
        Card(Modifier.fillMaxWidth(), shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp), content=content) {
                Row(verticalAlignment=Alignment.CenterVertically) { Icon(icon,null,tint=MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text(title,style=MaterialTheme.typography.titleLarge) }
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(horizontal=16.dp), verticalArrangement=Arrangement.spacedBy(12.dp), contentPadding=PaddingValues(top=14.dp,bottom=110.dp)) {
        item {
            Row(verticalAlignment=Alignment.CenterVertically) {
                IconButton(onClick={nav.popBackStack()}) { Icon(Icons.Rounded.ArrowBack,null) }
                Text("World Intelligence Lab",style=MaterialTheme.typography.headlineSmall)
            }
        }
        item {
            Panel("World selection",Icons.Rounded.Public) {
                if(vm.rows.isEmpty()) Text("No worlds or backups found. Select your Minecraft worlds folder and scan first.")
                else vm.rows.forEach { w ->
                    FilterChip(selected=selectedWorld==w.id,onClick={selectedWorld=w.id;selectedBackup=w.backups.firstOrNull()?.id;dna=null},label={Text(w.name)})
                }
                if(backups.isNotEmpty()) {
                    Text("Backup snapshot",style=MaterialTheme.typography.labelLarge)
                    backups.forEach { b -> FilterChip(selected=(selectedBackup ?: backups.firstOrNull()?.id)==b.id,onClick={selectedBackup=b.id;dna=null},label={Text(SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(Date(b.time))+" · "+b.file)}) }
                }
            }
        }
        item {
            Panel("World DNA — content fingerprint",Icons.Rounded.Fingerprint) {
                Text("Hashes every file inside the selected .mcworld archive and builds a canonical fingerprint from paths, sizes and content hashes.")
                Button(enabled=currentBackup!=null && !busy,onClick={
                    val b=currentBackup ?: return@Button
                    busy=true;status="Analyzing archive contents…"
                    scope.launch {
                        val result=withContext(Dispatchers.IO) { WorldAnalytics.dna(vm.file(b)) }
                        dna=result;busy=false;status="World DNA generated."
                    }
                }) { Icon(Icons.Rounded.Analytics,null);Spacer(Modifier.width(8.dp));Text("Analyze world contents") }
                dna?.let { d ->
                    Text("DNA SHA-256",style=MaterialTheme.typography.labelLarge)
                    SelectionContainer { Text(d.fingerprint,style=MaterialTheme.typography.bodySmall) }
                    Text("${d.files.size} files · ${fmtSize(d.totalBytes)} · ${d.databaseFiles} database files")
                    Text("${d.behaviorFiles} behavior-pack files · ${d.resourceFiles} resource-pack files")
                    d.level?.let { info -> Text("Seed: ${info.seed ?: "unknown"} · Spawn: ${info.spawn ?: "unknown"} · Version: ${info.version ?: "unknown"}") }
                    Button(onClick={
                        val previous=backups.filter { it.id!=currentBackup?.id && it.time < (currentBackup?.time ?: Long.MAX_VALUE) }.maxByOrNull { it.time }
                        if(previous==null) { status="No older backup is available for comparison."; return@Button }
                        busy=true
                        scope.launch {
                            val old=withContext(Dispatchers.IO) { WorldAnalytics.dna(vm.file(previous)) }
                            val a=d.files.associateBy { it.path }; val b=old.files.associateBy { it.path }
                            val added=a.keys-b.keys; val removed=b.keys-a.keys
                            val changed=(a.keys intersect b.keys).filter { a[it]?.sha256!=b[it]?.sha256 }
                            dnaCompare="Compared with ${previous.file}\nAdded: ${added.size}\nRemoved: ${removed.size}\nChanged: ${changed.size}\n\n"+(added.take(30).joinToString("\n") { "+ $it" })+"\n"+removed.take(30).joinToString("\n") { "- $it" }+"\n"+changed.take(30).joinToString("\n") { "~ $it" }
                            busy=false
                        }
                    }) { Text("Compare with previous backup") }
                    dnaCompare?.let { SelectionContainer { Text(it,style=MaterialTheme.typography.bodySmall) } }
                }
            }
        }
        item {
            Panel("World Explorer — coordinate map",Icons.Rounded.Map) {
                Text("This plots verified coordinates from level.dat spawn metadata and your saved places. It does not fabricate village or structure locations.")
                val spawn=dna?.level?.spawn
                val points=places.mapNotNull { p -> runCatching { Triple(p.name,p.x.toDouble(),p.z.toDouble()) }.getOrNull() }
                val spawnPair=spawn?.split(",")?.takeIf { it.size==3 }?.let { runCatching { it[0].trim().toDouble() to it[2].trim().toDouble() }.getOrNull() }
                Canvas(Modifier.fillMaxWidth().height(180.dp).background(MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(16.dp))) {
                    val all=points.map { it.second to it.third }+(spawnPair?.let { listOf(it) } ?: emptyList())
                    if(all.isNotEmpty()) {
                        val minX=all.minOf { it.first }; val maxX=all.maxOf { it.first }; val minZ=all.minOf { it.second }; val maxZ=all.maxOf { it.second }
                        all.forEachIndexed { i,p ->
                            val x= if(maxX==minX) size.width/2 else 18.dp.toPx()+(p.first-minX)/(maxX-minX)*(size.width-36.dp.toPx())
                            val y= if(maxZ==minZ) size.height/2 else 18.dp.toPx()+(p.second-minZ)/(maxZ-minZ)*(size.height-36.dp.toPx())
                            drawCircle(if(i==all.lastIndex && spawnPair!=null) Color(0xFFFFB74D) else Color(0xFF42A5F5),8.dp.toPx(),Offset(x,y))
                        }
                    }
                }
                Text("Blue: saved coordinates · Amber: world spawn")
                places.forEach { Text("${it.name}  X:${it.x} Y:${it.y} Z:${it.z}") }
                dna?.regions?.takeIf { it.isNotEmpty() }?.let { Text("Java MCA region coverage: ${it.size} region files") }
                Text("Village / structure discovery in Bedrock requires decoding LevelDB chunk and structure records; this build reports them as unavailable rather than guessing.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Panel("Add-on Lab — multi-pack conflict analysis",Icons.Rounded.Extension) {
                Text("Select multiple .mcpack, .mcaddon, ZIP or manifest.json files. The analyzer checks duplicate header UUIDs, missing manifests/modules and unresolved declared dependencies.")
                Button(enabled=!busy,onClick={pickAddons.launch(arrayOf("*/*"))}) { Icon(Icons.Rounded.FolderOpen,null);Spacer(Modifier.width(8.dp));Text("Select add-on packages") }
                if(packs.isNotEmpty()) Text("${packs.size} packages selected")
                conflicts.forEach { c ->
                    val color=when(c.severity) { "ERROR"->MaterialTheme.colorScheme.error; "WARNING"->Color(0xFFFFA726); else->MaterialTheme.colorScheme.primary }
                    Text("${c.severity}: ${c.title}",color=color,style=MaterialTheme.typography.titleSmall)
                    Text(c.detail,style=MaterialTheme.typography.bodySmall)
                }
                Text("This checks selected manifests, not in-game script/API behavior or load-order compatibility.",style=MaterialTheme.typography.bodySmall,color=MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Panel("World Timeline — backup change history",Icons.Rounded.Timeline) {
                Text("Backups are immutable checkpoints. Select two snapshots above, or generate World DNA and compare against the previous checkpoint to see file-level changes.")
                vm.backups.filter { it.worldId==row?.id }.sortedByDescending { it.time }.forEach { b ->
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Circle,null,tint=MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.getDefault()).format(Date(b.time)))
                            Text("${b.file} · ${fmtSize(b.size)}",style=MaterialTheme.typography.bodySmall)
                        }
                        Text("SHA ${b.sha.take(10)}…",style=MaterialTheme.typography.labelSmall)
                    }
                }
                vm.log.filter { it.res.contains("backup") || it.res.contains("restore") || it.res.contains("verify") }.take(20).forEach { e ->
                    Text("${SimpleDateFormat("MM-dd HH:mm",Locale.getDefault()).format(Date(e.time))} · ${e.res}",style=MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text(status,color=MaterialTheme.colorScheme.secondary); if(busy) LinearProgressIndicator(Modifier.fillMaxWidth()) }
    }
}
