package app.minesaver

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun SeedMapScreen(vm: MainVm, nav: NavController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedWorld by remember { mutableStateOf(vm.rows.firstOrNull()?.id) }
    var seed by remember { mutableStateOf("") }
    var version by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Choose a world to import its seed, or enter a seed manually.") }
    var loading by remember { mutableStateOf(false) }

    val row = vm.rows.firstOrNull { it.id == selectedWorld }

    LaunchedEffect(selectedWorld, vm.rows.size) {
        val selected = row ?: vm.rows.firstOrNull()
        if (selected != null) {
            if (selectedWorld == null) selectedWorld = selected.id
            loading = true
            val info = withContext(Dispatchers.IO) { vm.readWorldInfo(selected) }
            if (info?.seed != null) {
                seed = info.seed.toString()
                version = info.version
                status = "Seed imported from ${selected.name}."
            } else {
                status = "Could not read a seed from this world. You can enter it manually."
            }
            loading = false
        }
    }

    fun openSeedMap() {
        val clean = seed.trim()
        if (clean.isEmpty()) {
            status = "Enter a seed first."
            return
        }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Minecraft seed", clean))
        status = "Seed copied. Paste it into the Seed field on the map, then choose the exact edition and version."
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.chunkbase.com/apps/seed-map")))
        }.onFailure {
            status = "Seed copied, but no browser could open the map."
        }
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 110.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Rounded.ArrowBack, null) }
                Text("Seed Map", style = MaterialTheme.typography.headlineSmall)
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Public, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Import from your world", style = MaterialTheme.typography.titleLarge)
                    }
                    if (vm.rows.isEmpty()) {
                        Text("No scanned worlds yet. You can still enter a seed below.")
                    } else {
                        vm.rows.forEach { world ->
                            FilterChip(
                                selected = selectedWorld == world.id,
                                onClick = { selectedWorld = world.id },
                                label = { Text(world.name) },
                                leadingIcon = if (selectedWorld == world.id) ({ Icon(Icons.Rounded.Explore, null) }) else null
                            )
                        }
                    }
                    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                    version?.let { Text("World version recorded in save: $it", style = MaterialTheme.typography.bodySmall) }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Map, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("Map seed", style = MaterialTheme.typography.titleLarge)
                    }
                    OutlinedTextField(
                        value = seed,
                        onValueChange = { seed = it; status = "Seed ready." },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("World seed") },
                        placeholder = { Text("Enter a numeric seed") }
                    )
                    Button(onClick = { openSeedMap() }, enabled = seed.isNotBlank() && !loading, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Rounded.ContentCopy, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Copy seed and open Chunkbase")
                    }
                    Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Important", style = MaterialTheme.typography.titleMedium)
                    Text("Chunkbase displays the interactive biome and structure map. After it opens, paste the copied seed and select the same Minecraft edition, world-generation version, and dimension used by your world.")
                    Text("MineSaver currently imports the seed from Bedrock level.dat. The map itself is provided by Chunkbase; its results are predictions and may not match every structure exactly.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}
