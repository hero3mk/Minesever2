package app.minesaver

import android.net.Uri
import android.content.Context
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipEntry
import java.io.ByteArrayInputStream

data class DnaFile(val path: String, val size: Long, val sha256: String)
data class WorldDna(
    val fingerprint: String, val files: List<DnaFile>, val totalBytes: Long,
    val databaseFiles: Int, val resourceFiles: Int, val behaviorFiles: Int,
    val level: WorldInfo?, val regions: List<Pair<Int, Int>>
)
data class AddonPack(val source: String, val name: String, val uuid: String?, val version: String?, val dependencies: List<Pair<String,String>>, val errors: List<String>)
data class AddonConflict(val severity: String, val title: String, val detail: String)

object WorldAnalytics {
    private fun hash(bytes: ByteArray) = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    private fun hash(file: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        file.inputStream().use { input -> val b=ByteArray(65536); while(true) { val n=input.read(b); if(n<0) break; md.update(b,0,n) } }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /** Deep archive inventory: hash each entry's bytes, not merely the outer .mcworld ZIP. */
    fun dna(backup: File): WorldDna = ZipFile(backup).use { zip ->
        val entries = zip.entries().asSequence().filter { !it.isDirectory }.toList()
        val files = entries.map { e ->
            val md=MessageDigest.getInstance("SHA-256")
            var count=0L
            zip.getInputStream(e).use { input ->
                val buffer=ByteArray(64*1024)
                while(true) { val n=input.read(buffer); if(n<0) break; md.update(buffer,0,n); count+=n }
            }
            DnaFile(e.name,count,md.digest().joinToString("") { "%02x".format(it) })
        }.sortedBy { it.path }
        val levelBytes = entries.firstOrNull { it.name.substringAfterLast('/') == "level.dat" }?.let { zip.getInputStream(it).use { x -> x.readBytes() } }
        val regions = files.mapNotNull { f ->
            // Some Java-world exports contain MCA region files; Bedrock LevelDB stores chunk data differently.
            Regex("""r\.(-?\d+)\.(-?\d+)\.mca$""", RegexOption.IGNORE_CASE).find(f.path)?.let { it.groupValues[1].toInt() to it.groupValues[2].toInt() }
        }.distinct()
        val canonical = files.joinToString("\n") { "${it.path}\u0000${it.size}\u0000${it.sha256}" }.toByteArray()
        WorldDna(hash(canonical), files, files.sumOf { it.size },
            files.count { it.path.startsWith("db/") || it.path.contains("/db/") },
            files.count { it.path.startsWith("resource_packs/") || it.path.contains("/resource_packs/") },
            files.count { it.path.startsWith("behavior_packs/") || it.path.contains("/behavior_packs/") },
            levelBytes?.let { worldInfo(it) }, regions)
    }

    fun addon(uri: Uri, context: Context): AddonPack {
        val name = DocumentFile.fromSingleUri(context, uri)?.name ?: uri.lastPathSegment ?: "Add-on"
        val raw = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cannot read $name")
        val manifestBytes = when {
            name.endsWith(".json", true) -> raw
            name.endsWith(".mcpack", true) || name.endsWith(".mcaddon", true) || name.endsWith(".zip", true) ->
                ZipInputStream(ByteArrayInputStream(raw)).use { zis ->
                    var found: ByteArray? = null
                    while(true) { val e=zis.nextEntry ?: break; if(e.name.substringAfterLast('/')=="manifest.json") { found=zis.readBytes(); break } }
                    found
                }
            else -> null
        }
        if (manifestBytes == null) return AddonPack(name,name,null,null, emptyList(), listOf("No manifest.json found; this may be a world export or unsupported package."))
        val j = JSONObject(String(manifestBytes, Charsets.UTF_8))
        val header=j.optJSONObject("header") ?: JSONObject()
        val modules=j.optJSONArray("modules")
        val errors= mutableListOf<String>()
        if (header.optString("uuid").isBlank()) errors += "Missing header UUID"
        if (header.optJSONArray("version") == null) errors += "Missing header version"
        if (modules == null || modules.length()==0) errors += "No modules declared"
        val deps= mutableListOf<Pair<String,String>>()
        val arr=j.optJSONArray("dependencies")
        if(arr!=null) for(i in 0 until arr.length()) { val d=arr.optJSONObject(i) ?: continue; deps += d.optString("uuid") to (d.optJSONArray("version")?.let { "${it.optInt(0)}.${it.optInt(1)}.${it.optInt(2)}" } ?: d.optString("version")) }
        val version=header.optJSONArray("version")?.let { "${it.optInt(0)}.${it.optInt(1)}.${it.optInt(2)}" }
        AddonPack(name,header.optString("name",name),header.optString("uuid").takeIf { it.isNotBlank() },version,deps,errors)
    }

    fun conflicts(packs: List<AddonPack>): List<AddonConflict> {
        val out= mutableListOf<AddonConflict>()
        packs.filter { it.uuid != null }.groupBy { it.uuid!!.lowercase() }.filterValues { it.size>1 }.forEach { (id, ps) ->
            out += AddonConflict("ERROR","Duplicate pack UUID","${ps.joinToString { it.name }} share UUID $id")
        }
        packs.forEach { p ->
            p.errors.forEach { out += AddonConflict("WARNING",p.name,it) }
            p.dependencies.forEach { (uuid,ver) ->
                if(packs.none { it.uuid.equals(uuid,true) }) out += AddonConflict("WARNING","Missing dependency","${p.name} requires $uuid ($ver), but it was not among the selected packs")
            }
        }
        if(out.isEmpty()) out += AddonConflict("OK","No selected-pack conflicts found","Only the selected packages were compared; this does not validate runtime compatibility or load order.")
        return out
    }

    /** Extract coordinates only from known sources; do not invent village/structure positions. */
    fun mapSummary(dna: WorldDna, savedPlaces: List<SavedPlace>): String {
        val lines= mutableListOf<String>()
        dna.level?.spawn?.let { lines += "World spawn: $it" }
        savedPlaces.forEach { lines += "${it.name}: ${it.x}, ${it.y}, ${it.z}" }
        if(dna.regions.isNotEmpty()) lines += "Java region files: ${dna.regions.size}"
        else lines += "No MCA region map available. Bedrock LevelDB chunk/structure records require a Bedrock LevelDB decoder; village and structure locations are not inferred from filenames."
        if(lines.isEmpty()) lines += "No coordinate metadata found in this backup."
        return lines.joinToString("\n")
    }
}
